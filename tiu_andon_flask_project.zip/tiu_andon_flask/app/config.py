import os
from dotenv import load_dotenv
load_dotenv()

DB_DRIVER=os.getenv("DB_DRIVER","{SQL Server}")
DB_SERVER=os.getenv("DB_SERVER","10.105.17.60")
DB_DATABASE=os.getenv("DB_DATABASE","apriso")
DB_UID=os.getenv("DB_UID","FlxReader")
DB_PWD=os.getenv("DB_PWD","")
DB_ENCRYPT=os.getenv("DB_ENCRYPT","no")
SHIFT_START_UTC=os.getenv("SHIFT_START_UTC","01:00:00")
SHIFT_START_IST=os.getenv("SHIFT_START_IST","06:30:00")
IDEAL_TIME_SECONDS=int(os.getenv("IDEAL_TIME_SECONDS","33"))
REFRESH_SECONDS=int(os.getenv("REFRESH_SECONDS","30"))

rework_queries = {

    "UC01_IP": """
    SELECT ISNULL(SUM(PartQuantity),0)
    FROM AT_Ultrasonic1process
    WHERE CreatedOn BETWEEN ? AND GETDATE()
      AND OutputScan = 1
      AND WipOrderNo LIKE '%R00%'
      AND Parts = 'M4ACN0111M00'
    """,

    "SPFL_IP": """
    SELECT ISNULL(SUM(PartQuantity),0)
    FROM AT_SprayFluxingProcess
    WHERE CreatedOn BETWEEN ? AND GETDATE()
      AND OutputScan = 1
      AND WipOrderNo LIKE '%R00%'
      AND Parts = 'M4ACN0111M00'
    """,

    "LW01": """
    SELECT ISNULL(COUNT(*),0)
    FROM AT_LaserWeldingPLCData
    WHERE CreatedOn BETWEEN ? AND GETDATE()
      AND WipOrderNo LIKE '%R00%'
    """,

    "LW02": """
    SELECT ISNULL(COUNT(*),0)
    FROM AT_LaserWeldingPLCData
    WHERE CreatedOn BETWEEN ? AND GETDATE()
      AND WipOrderNo LIKE '%R00%'
    """,

    "LW03": """
    SELECT ISNULL(COUNT(*),0)
    FROM AT_LaserWeldingPLCData
    WHERE CreatedOn BETWEEN ? AND GETDATE()
      AND WipOrderNo LIKE '%R00%'
    """,

    "CLNC": """
    SELECT ISNULL(SUM(PartQuantity),0)
    FROM AT_Clinchingprocess
    WHERE CreatedOn BETWEEN ? AND GETDATE()
      AND OutputScan = 1
      AND Active = 1
      AND WipOrderNo LIKE '%R00%'
    """,

    "RSHP": """
    SELECT ISNULL(SUM(PartQuantity),0)
    FROM AT_Reshapingprocess
    WHERE CreatedOn BETWEEN ? AND GETDATE()
      AND OutputScan = 1
      AND WipOrderNo LIKE '%R00%'
    """,

    "SHBL": """
    SELECT ISNULL(SUM(PartQuantity),0)
    FROM AT_ShotBlastingprocess
    WHERE CreatedOn BETWEEN ? AND GETDATE()
      AND OutputScan = 1
      AND WipOrderNo LIKE '%R00%'
    """,

    "ALT1_01": """
    SELECT ISNULL(SUM(PartQuantity),0)
    FROM AT_ALT1_Process
    WHERE CreatedOn BETWEEN ? AND GETDATE()
      AND OutputScan = 1
      AND IsRejected = 0
      AND Active = 1
      AND WipOrderNo LIKE '%R00%'
    """,

    "BRZN_FX": """
    SELECT ISNULL(SUM(PartQuantity),0)
    FROM AT_BrazingProcess
    WHERE CreatedOn BETWEEN ? AND GETDATE()
      AND OutputScan = 1
      AND Active = 1
      AND WipOrderNo LIKE '%R00%'
    """,

    "QALT": """
    SELECT ISNULL(COUNT(*),0)
    FROM AT_QUALITY_SAMPLE
    WHERE WorkCenter LIKE 'ALT1%'
      AND Status = 'Rework'
      AND CreatedOn BETWEEN ? AND GETDATE()
    """
}

scrap_queries = {
    "QALT": """
    SELECT ISNULL(COUNT(*),0)
    FROM AT_QUALITY_SAMPLE
    WHERE WorkCenter LIKE 'ALT1%'
      AND Status = 'Scrap'
      AND CreatedOn BETWEEN ? AND GETDATE()
    """
}

hourly_nok_queries = {

    "QALT": """
    SELECT
        DATEPART(HOUR, cp.CreatedOn) AS Hr,
        ISNULL(COUNT(cp.Quantity),0) AS Qty
    FROM AT_QUALITY_SAMPLE cp
    WHERE WorkCenter LIKE 'ALT1%'
      AND Status IN ('Scrap','Rework')
      AND cp.CreatedOn BETWEEN ? AND GETDATE()
    GROUP BY DATEPART(HOUR, cp.CreatedOn)
    ORDER BY Hr
    """
}

hourly_queries = {

    "UC01_IP": """
        SELECT
            DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn)) AS Hr,
            ISNULL(SUM(PartQuantity),0) AS Qty
        FROM AT_Ultrasonic1process
        WHERE CreatedOn BETWEEN ? AND GETDATE()
          AND OutputScan = 1
          AND Parts = 'M4ACN0111M00'
        GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn))
        ORDER BY Hr
    """,

    "SPFL_IP": """
        SELECT
            DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn)) AS Hr,
            ISNULL(SUM(PartQuantity),0) AS Qty
        FROM AT_SprayFluxingProcess
        WHERE CreatedOn BETWEEN ? AND GETDATE()
          AND OutputScan = 1
          AND UndoFlag = 0
          AND Parts = 'M4ACN0111M00'
        GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn))
        ORDER BY Hr
    """,

    "LW01": """
        ;WITH EquipMap AS (
            SELECT W.WorkCenter,
                   UC.Attribute_ AS EquipmentName
            FROM WORK_CENTER W
            JOIN UNIT_CHARACTERISTIC UC
                ON UC.UnitID = W.UnitID
               AND UC.Characteristic = 'OutputStation'
            WHERE W.WorkCenter IN ('LW01')
        )

        SELECT
            DATEPART(HOUR, DATEADD(MINUTE,330,cp.CreatedOn)) AS Hr,
            ISNULL(SUM(1),0) AS Qty
        FROM AT_LaserWeldingPLCData cp
        JOIN EQUIPMENT E
            ON E.ID = cp.EquipmentID
        JOIN EquipMap em
            ON em.WorkCenter = 'LW01'
           AND E.Equipment = em.EquipmentName
        WHERE cp.CreatedOn BETWEEN ? AND GETDATE()
        GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,cp.CreatedOn))
        ORDER BY Hr
    """,
    "QLW01": """
;WITH EquipMap AS (
    SELECT W.WorkCenter,
           UC.Attribute_ AS EquipmentName
    FROM WORK_CENTER W
    JOIN UNIT_CHARACTERISTIC UC
        ON UC.UnitID = W.UnitID
       AND UC.Characteristic = 'OutputStation'
    WHERE W.WorkCenter = 'LW01'
)
SELECT
    DATEPART(HOUR, DATEADD(MINUTE,330,cp.CreatedOn)) AS Hr,
    COUNT(*) AS Qty
FROM AT_LaserWeldingPLCData cp
JOIN EQUIPMENT E
    ON E.ID = cp.EquipmentID
JOIN EquipMap em
    ON em.WorkCenter = 'LW01'
   AND E.Equipment = em.EquipmentName
WHERE cp.CreatedOn BETWEEN ? AND GETDATE()
GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,cp.CreatedOn))
ORDER BY Hr
""",


    "LW02": """
        ;WITH EquipMap AS (
            SELECT W.WorkCenter,
                   UC.Attribute_ AS EquipmentName
            FROM WORK_CENTER W
            JOIN UNIT_CHARACTERISTIC UC
                ON UC.UnitID = W.UnitID
               AND UC.Characteristic = 'OutputStation'
            WHERE W.WorkCenter IN ('LW02')
        )

        SELECT
            DATEPART(HOUR, DATEADD(MINUTE,330,cp.CreatedOn)) AS Hr,
            ISNULL(SUM(1),0) AS Qty
        FROM AT_LaserWeldingPLCData cp
        JOIN EQUIPMENT E
            ON E.ID = cp.EquipmentID
        JOIN EquipMap em
            ON em.WorkCenter = 'LW02'
           AND E.Equipment = em.EquipmentName
        WHERE cp.CreatedOn BETWEEN ? AND GETDATE()
        GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,cp.CreatedOn))
        ORDER BY Hr
    """,
    "QLW02": """
;WITH EquipMap AS (
    SELECT W.WorkCenter,
           UC.Attribute_ AS EquipmentName
    FROM WORK_CENTER W
    JOIN UNIT_CHARACTERISTIC UC
        ON UC.UnitID = W.UnitID
       AND UC.Characteristic = 'OutputStation'
    WHERE W.WorkCenter = 'LW02'
)
SELECT
    DATEPART(HOUR, DATEADD(MINUTE,330,cp.CreatedOn)) AS Hr,
    COUNT(*) AS Qty
FROM AT_LaserWeldingPLCData cp
JOIN EQUIPMENT E
    ON E.ID = cp.EquipmentID
JOIN EquipMap em
    ON em.WorkCenter = 'LW02'
   AND E.Equipment = em.EquipmentName
WHERE cp.CreatedOn BETWEEN ? AND GETDATE()
GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,cp.CreatedOn))
ORDER BY Hr
""",

    

    "LW03": """
        ;WITH EquipMap AS (
            SELECT W.WorkCenter,
                   UC.Attribute_ AS EquipmentName
            FROM WORK_CENTER W
            JOIN UNIT_CHARACTERISTIC UC
                ON UC.UnitID = W.UnitID
               AND UC.Characteristic = 'OutputStation'
            WHERE W.WorkCenter IN ('LW03')
        )

        SELECT
            DATEPART(HOUR, DATEADD(MINUTE,330,cp.CreatedOn)) AS Hr,
            ISNULL(SUM(1),0) AS Qty
        FROM AT_LaserWeldingPLCData cp
        JOIN EQUIPMENT E
            ON E.ID = cp.EquipmentID
        JOIN EquipMap em
            ON em.WorkCenter = 'LW03'
           AND E.Equipment = em.EquipmentName
        WHERE cp.CreatedOn BETWEEN ? AND GETDATE()
        GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,cp.CreatedOn))
        ORDER BY Hr
    """,

    "QLW03": """
SELECT
DATEPART(HOUR, DATEADD(MINUTE,330,D.CreatedOn)) AS Hr,
ISNULL(SUM(D.Quantity),0) AS Qty
FROM DISPOSITION D
WHERE D.OprSequenceNo = 15
AND D.Status IN (14,4)
AND D.CreatedOn BETWEEN ? AND GETDATE()
GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,D.CreatedOn))
ORDER BY Hr
""",
    "CLNC": """
        SELECT
            DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn)) AS Hr,
            ISNULL(SUM(PartQuantity),0) AS Qty
        FROM AT_Clinchingprocess
        WHERE CreatedOn BETWEEN ? AND GETDATE()
          AND OutputScan = 1
          AND Active = 1
        GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn))
        ORDER BY Hr
    """,

    "RSHP": """
        SELECT
            DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn)) AS Hr,
            ISNULL(SUM(PartQuantity),0) AS Qty
        FROM AT_Reshapingprocess
        WHERE CreatedOn BETWEEN ? AND GETDATE()
          AND OutputScan = 1
        GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn))
        ORDER BY Hr
    """,

    "SHBL": """
        SELECT
            DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn)) AS Hr,
            ISNULL(SUM(PartQuantity),0) AS Qty
        FROM AT_ShotBlastingprocess
        WHERE CreatedOn BETWEEN ? AND GETDATE()
          AND OutputScan = 1
        GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn))
        ORDER BY Hr
    """,

    "ALT1_01": """
        SELECT
            DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn)) AS Hr,
            ISNULL(SUM(PartQuantity),0) AS Qty
        FROM AT_ALT1_Process
        WHERE CreatedOn BETWEEN ? AND GETDATE()
          AND OutputScan = 1
          AND IsRejected = 0
          AND Active = 1
        GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn))
        ORDER BY Hr
    """,

    "BRZN_FX": """
        SELECT
            DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn)) AS Hr,
            ISNULL(SUM(PartQuantity),0) AS Qty
        FROM AT_BrazingProcess
        WHERE CreatedOn BETWEEN ? AND GETDATE()
          AND OutputScan = 1
          AND Active = 1
        GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn))
        ORDER BY Hr
    """,
    
    "QALT": """
SELECT
    DATEPART(HOUR, DATEADD(MINUTE,330,cp.CreatedOn)) AS Hr,
    ISNULL(COUNT(cp.Quantity),0) AS Qty
FROM AT_QUALITY_SAMPLE cp
WHERE WorkCenter LIKE 'ALT1%'
  AND Status = 'QAOK'
  AND cp.CreatedOn BETWEEN ? AND GETDATE()
GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,cp.CreatedOn))
ORDER BY Hr
"""
}

machine_display = {
    "UC01_IP": "Ultrasonic Cleaning 01",
    "SPFL_IP": "Spray Fluxing",
    "LW01": "Laser Welding 01",
    "QLW01": "LW01 Q-Gate",
    "CLNC": "Clinching",
    "LW02": "Laser Welding 02",
    "QLW02": "LW02 Q-Gate",
    "LW03": "Laser Welding 03",
    "QLW03": "LW03 Q-Gate",
    "BRZN_FX": "Brazing",
    "SHBL": "Shot Blasting",
    "RSHP": "Restriking",
    "ALT1_01": "Air Leak Testing 01",
    "QALT": "Q-Gate ALT1"

}

machining_display = {

    **{
        f"OP_10_{i:02d}": f"OP-10_{i:02d}"
        for i in range(2, 7)
    },

    **{
        f"OP_20_{i:02d}": f"OP-20_{i:02d}"
        for i in range(2, 7)
    },

    **{
        f"OP_30_{i:02d}": f"OP-30_{i:02d}"
        for i in range(1, 18)
    },

    **{
        f"OP_40_{i:02d}": f"OP-40_{i:02d}"
        for i in range(1, 18)
    },

    **{
        f"OP_50_{i:02d}": f"OP-50_{i:02d}"
        for i in range(1, 4)
    }
    
}

post_machining_queries = {

    "SG": """
    SELECT ISNULL(COUNT(cp.PartQuantity),0)
    FROM AT_ColdPlateLoadingProcess cp
    WHERE cp.Active = 1
      AND cp.OutputScan = 1
      AND LEN(ISNULL(cp.SerialNo,'')) > 0
      AND ISNULL(cp.IsRejected,0) <> 1
      AND cp.CreatedOn BETWEEN ? AND GETDATE()
    """,

    "UC2": """
    SELECT ISNULL(COUNT(cp.PartQuantity),0)
    FROM AT_Ultrasonic2process cp
    WHERE cp.Active = 1
      AND LEN(ISNULL(cp.SerialNo,'')) > 0
      AND ISNULL(cp.IsRejected,0) <> 1
      AND cp.CreatedOn BETWEEN ? AND GETDATE()
    """,

    "EOL": """
    SELECT ISNULL(COUNT(DISTINCT(cp.SerialNumber)),0)
    FROM AT_TestingLineProcess cp
    WHERE cp.Active = 1
      AND LEN(ISNULL(cp.SerialNumber,'')) > 0
      AND LEN(ISNULL(cp.LM2SerialNumber,'')) > 0
      AND LEN(ISNULL(cp.WipOrderNo,'')) > 0
      AND cp.CreatedOn BETWEEN ? AND GETDATE()
    """,

    "PACK": """
    SELECT ISNULL(COUNT(cp.ID),0)
    FROM AT_PackagingProcess cp
    WHERE cp.SerialLabelStatus = 1
      AND cp.Active = 1
      AND cp.CreatedOn BETWEEN ? AND GETDATE()
    """
}

post_machining_nok_queries = {

    "SG": """
    SELECT ISNULL(COUNT(*),0)
    FROM AT_ColdPlateLoadingProcess
    WHERE Active = 1
      AND OutputScan = 1
      AND IsRejected = 1
      AND CreatedOn BETWEEN ? AND GETDATE()
    """,

    "UC2": """
    SELECT ISNULL(COUNT(*),0)
    FROM AT_Ultrasonic2Process
    WHERE Active = 1
      AND IsRejected = 1
      AND CreatedOn BETWEEN ? AND GETDATE()
    """,

    "EOL": """
    SELECT ISNULL(COUNT(*),0)
    FROM AT_TestingLineProcess
    WHERE Active = 1
      AND IsRejection = 1
      AND CreatedOn BETWEEN ? AND GETDATE()
    """,

    "PACK": """
    SELECT ISNULL(COUNT(*),0)
    FROM AT_PackagingProcess
    WHERE Active = 1
      AND IsRejection = 1
      AND CreatedOn BETWEEN ? AND GETDATE()
    """
}

post_machining_wc = {
    "SG": "SG",
    "UC2": "UC02",
    "EOL": "EOL",
    "PACK": "PACK"
}

post_machining_rework_queries = {

    "SG": """
    SELECT ISNULL(COUNT(cp.PartQuantity),0)
    FROM AT_ColdPlateLoadingProcess cp
    WHERE cp.Active = 1
      AND cp.OutputScan = 1
      AND LEN(ISNULL(cp.SerialNo,'')) > 0
      AND cp.WipOrderNo LIKE '%R00%'
      AND cp.CreatedOn BETWEEN ? AND GETDATE()
    """,

    "UC2": """
    SELECT ISNULL(COUNT(cp.PartQuantity),0)
    FROM AT_Ultrasonic2process cp
    WHERE cp.Active = 1
      AND LEN(ISNULL(cp.SerialNo,'')) > 0
      AND cp.WipOrderNo LIKE '%R00%'
      AND cp.CreatedOn BETWEEN ? AND GETDATE()
    """,

    "EOL": """
    SELECT ISNULL(COUNT(DISTINCT(cp.SerialNumber)),0)
    FROM AT_TestingLineProcess cp
    WHERE cp.Active = 1
      AND LEN(ISNULL(cp.SerialNumber,'')) > 0
      AND LEN(ISNULL(cp.LM2SerialNumber,'')) > 0
      AND LEN(ISNULL(cp.WipOrderNo,'')) > 0
      AND cp.WipOrderNo LIKE '%R00%'
      AND cp.CreatedOn BETWEEN ? AND GETDATE()
    """,

    "PACK": """
    SELECT ISNULL(COUNT(cp.ID),0)
    FROM AT_PackagingProcess cp
    WHERE cp.SerialLabelStatus = 1
      AND cp.Active = 1
      AND cp.WipOrderNo LIKE '%R00%'
      AND cp.CreatedOn BETWEEN ? AND GETDATE()
    """
}

post_machining_display = {
    "SG": "Soldering and Glueing",
    "UC2": "Ultrasonic Cleaning 02",
    "EOL": "End of Line Testing",
    "PACK": "Packaging"
}

targets = {
    "UC01_IP": 100,
    "SPFL_IP": 100,
    "LW01": 100,
    "CLNC": 100,
    "LW02": 100,
    "LW03": 100,
    "SHBL": 100,
    "RSHP": 100,
    "ALT1_01":100,
    "BRZN_FX":100,
    "QLW01": 100,
    "QLW02": 100,
    "QLW03": 100,
    "QALT": 100
    
    }

post_targets = {
    "SG": 100,
    "UC2": 100,
    "EOL": 100,
    "PACK": 100
}

graph_labels = {
    "UC01_IP": "UC1",
    "SPFL_IP": "SF",
    "LW01": "LW1",
    "CLNC": "CLNC",
    "LW02": "LW2",
    "LW03": "LW3",
    "SHBL": "SB",
    "RSHP": "REST",
    "ALT1_01": "ALT1",
    "BRZN_FX": "BRAZ",
    "QLW01": "QLW1",
    "QLW02": "QLW2",
    "QLW03": "QLW3",
    "QALT": "QALT"
}

machine_queries = {

    "UC01_IP": """
        SELECT ISNULL(SUM(PartQuantity),0)
        FROM AT_Ultrasonic1process
        WHERE CreatedOn BETWEEN ? AND GETDATE()
          AND OutputScan = 1
          AND Parts = 'M4ACN0111M00'
    """,

    "SPFL_IP": """
        SELECT ISNULL(SUM(PartQuantity),0)
        FROM AT_SprayFluxingProcess
        WHERE CreatedOn BETWEEN ? AND GETDATE()
          AND OutputScan = 1
          AND UndoFlag = 0
          AND Parts = 'M4ACN0111M00'
    """,

    "LW01": """
        ;WITH EquipMap AS (
SELECT W.WorkCenter, UC.Attribute_ AS EquipmentName
FROM WORK_CENTER W
JOIN UNIT_CHARACTERISTIC UC
ON UC.UnitID = W.UnitID
AND UC.Characteristic = 'OutputStation'
WHERE W.WorkCenter IN ('LW01')
)

SELECT  isnull(sum(1),0)
FROM AT_LaserWeldingPLCData cp
JOIN EQUIPMENT E ON E.ID = cp.EquipmentID
JOIN EquipMap em ON em.WorkCenter = 'LW01' AND E.Equipment = em.EquipmentName
WHERE cp.CreatedOn BETWEEN ? AND GETDATE()
    """,
    
    "RSHP": """
        SELECT ISNULL(SUM(PartQuantity),0)
            FROM AT_Reshapingprocess
            WHERE CreatedOn BETWEEN ? AND GETDATE()
            AND OutputScan = 1
    """,
    
    "CLNC":"""
        select ISNULL(sum(PartQuantity),0)
            from AT_Clinchingprocess
            where CreatedOn between ? and GETDATE()
            And outputscan = 1 and active = 1
    """,

    "LW03":"""
        ;WITH EquipMap AS (
SELECT W.WorkCenter, UC.Attribute_ AS EquipmentName
FROM WORK_CENTER W
JOIN UNIT_CHARACTERISTIC UC
ON UC.UnitID = W.UnitID
AND UC.Characteristic = 'OutputStation'
WHERE W.WorkCenter IN ('LW03')
)

SELECT  isnull(sum(1),0)
FROM AT_LaserWeldingPLCData cp
JOIN EQUIPMENT E ON E.ID = cp.EquipmentID
JOIN EquipMap em ON em.WorkCenter = 'LW03' AND E.Equipment = em.EquipmentName
WHERE cp.CreatedOn BETWEEN ? AND GETDATE()
    
    """,

    "LW02":"""
        ;WITH EquipMap AS (
SELECT W.WorkCenter, UC.Attribute_ AS EquipmentName
FROM WORK_CENTER W
JOIN UNIT_CHARACTERISTIC UC
ON UC.UnitID = W.UnitID
AND UC.Characteristic = 'OutputStation'
WHERE W.WorkCenter IN ('LW02')
)

SELECT  isnull(sum(1),0)
FROM AT_LaserWeldingPLCData cp
JOIN EQUIPMENT E ON E.ID = cp.EquipmentID
JOIN EquipMap em ON em.WorkCenter = 'LW02' AND E.Equipment = em.EquipmentName
WHERE cp.CreatedOn BETWEEN ? AND GETDATE()
    """,

    "SHBL":"""
        select isnull(sum(partQuantity),0) from AT_ShotBlastingprocess where createdon between ? and GETDATE() and OutputScan = 1
    """,

    "ALT1_01":"""
        select isnull(sum(partQuantity),0) from AT_ALT1_Process where createdon between ? and GETDATE() and OutputScan = 1 and IsRejected = 0 and Active = 1

    """,
    "BRZN_FX":"""
    select isnull(sum(PartQuantity),0) from AT_BrazingProcess where createdon between ? and GETDATE() and OutputScan = 1 and Active = 1
    """,
    
    "QLW01": """
;WITH EquipMap AS (
    SELECT W.WorkCenter,
           UC.Attribute_ AS EquipmentName
    FROM WORK_CENTER W
    JOIN UNIT_CHARACTERISTIC UC
        ON UC.UnitID = W.UnitID
       AND UC.Characteristic = 'OutputStation'
    WHERE W.WorkCenter = 'LW01'
)
SELECT ISNULL((
    SELECT COUNT(*)
    FROM AT_LaserWeldingPLCData cp
    JOIN EQUIPMENT E
        ON E.ID = cp.EquipmentID
    JOIN EquipMap em
        ON em.WorkCenter = 'LW01'
       AND E.Equipment = em.EquipmentName
    WHERE cp.CreatedOn BETWEEN ? AND GETDATE()
),0)
""",
    
    "QLW02": """
    ;WITH EquipMap AS (
        SELECT W.WorkCenter,
               UC.Attribute_ AS EquipmentName
        FROM WORK_CENTER W
        JOIN UNIT_CHARACTERISTIC UC
            ON UC.UnitID = W.UnitID
           AND UC.Characteristic = 'OutputStation'
        WHERE W.WorkCenter = 'LW02'
    )
    SELECT ISNULL((
        SELECT COUNT(*)
        FROM AT_LaserWeldingPLCData cp
        JOIN EQUIPMENT E
            ON E.ID = cp.EquipmentID
        JOIN EquipMap em
            ON em.WorkCenter = 'LW02'
           AND E.Equipment = em.EquipmentName
        WHERE cp.CreatedOn BETWEEN ? AND GETDATE()
    ),0)
    """,
    
    "QLW03": """
    SELECT SUM(D.Quantity)
    FROM DISPOSITION D
    WHERE D.OprSequenceNo = 15
    AND D.Status IN (14,4)
    AND D.CreatedOn BETWEEN ? AND GETDATE()
    """,

    "QALT": """
    SELECT ISNULL(COUNT(cp.Quantity),0)
    FROM AT_QUALITY_SAMPLE cp
    WHERE WorkCenter LIKE 'ALT1%'
      AND Status = 'QAOK'
      AND cp.CreatedOn BETWEEN ? AND GETDATE()
    """

}

USERS = {
    "Premachining": {
        "password": "123",
        "role": "L1"
    },
    "Machining": {
        "password": "123",
        "role": "L1"
    },
    "Postmachining": {
        "password": "123",
        "role": "L1"
    },
    "Shubham": {
        "password": "123",
        "role": "L2"
    }
}

