from flask import Blueprint,jsonify,request,session
from .config import REFRESH_SECONDS
from .services.dashboard_service import get_machines,saved
api_bp=Blueprint('api',__name__)
@api_bp.get('/dashboard')
def dashboard():
 if not session.get('logged_in'):return jsonify(ok=False,error='Not authenticated'),401
 section=request.args.get('section') or session.get('plant_section');machines=get_machines(section) if section else []
 for m in machines:
  r,a=saved(m['machine']);m['reason_alarm']=r or m.get('reason_alarm','-');m['ack_by']=a or m.get('ack_by','-')
 return jsonify(ok=True,section=section,machines=machines,refresh_seconds=REFRESH_SECONDS)
