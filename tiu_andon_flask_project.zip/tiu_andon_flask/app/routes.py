from flask import Blueprint,render_template,redirect,url_for,request,session,flash
from functools import wraps
from .config import USERS
from .services.dashboard_service import save_reason
main_bp=Blueprint('main',__name__)
def login_required(f):
 @wraps(f)
 def w(*a,**k): return f(*a,**k) if session.get('logged_in') else redirect(url_for('main.login'))
 return w
@main_bp.route('/')
def index():
 if not session.get('logged_in'):return redirect(url_for('main.login'))
 return render_template('index.html',section=session.get('plant_section'),machining_page=session.get('machining_page'),machining_view=session.get('machining_view','OP30'),username=session.get('username'),role=session.get('role'))
@main_bp.route('/login',methods=['GET','POST'])
def login():
 if request.method=='POST':
  u=request.form.get('username','').strip();p=request.form.get('password','');x=USERS.get(u)
  if x and x['password']==p:
   session.update(logged_in=True,username=u,role=x['role'],plant_section=None,machining_page=None,machining_view='OP30');return redirect(url_for('main.index'))
  flash('Invalid Username or Password','error')
 return render_template('login.html')
@main_bp.route('/logout')
def logout():session.clear();return redirect(url_for('main.login'))
@main_bp.route('/section/<section>')
@login_required
def section(section):
 if section not in {'PRE_MACHINING','MACHINING','POST_MACHINING'}:return redirect(url_for('main.index'))
 session['plant_section']=section;session['machining_page']=None;return redirect(url_for('main.index'))
@main_bp.route('/main-menu')
@login_required
def menu():session['plant_section']=None;session['machining_page']=None;return redirect(url_for('main.index'))
@main_bp.route('/machining/<page>')
@login_required
def machining(page):
 if page not in {'VMC1','VMC2'}:return redirect(url_for('main.index'))
 session['plant_section']='MACHINING';session['machining_page']=page;return redirect(url_for('main.index'))
@main_bp.route('/machining/operation/<op>')
@login_required
def operation(op):
 session['plant_section']='MACHINING';session['machining_page']='VMC2';session['machining_view']=op if op in {'OP30','OP40','OP50'} else 'OP30';return redirect(url_for('main.index'))
@main_bp.route('/acknowledge',methods=['POST'])
@login_required
def acknowledge():
 if session.get('role')!='L2':flash('Only L2 users can acknowledge Andon events.','error');return redirect(url_for('main.index'))
 save_reason(request.form.get('machine',''),request.form.get('status',''),request.form.get('reason_code',''),session['username']);flash('Acknowledged','success');return redirect(url_for('main.index'))
