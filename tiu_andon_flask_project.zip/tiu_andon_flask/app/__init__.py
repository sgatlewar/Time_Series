import os
from flask import Flask
from dotenv import load_dotenv
load_dotenv()
def create_app():
    app=Flask(__name__)
    app.config["SECRET_KEY"]=os.getenv("SECRET_KEY","change-me")
    from .routes import main_bp
    from .api import api_bp
    app.register_blueprint(main_bp)
    app.register_blueprint(api_bp,url_prefix="/api")
    return app
