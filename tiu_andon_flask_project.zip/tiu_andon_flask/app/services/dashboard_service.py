from datetime import datetime
import os,pandas as pd
from .db import get_connection
from .oee import *
from .. import config
from ..config import machine_display,machining_display,post_machining_display,machine_queries,rework_queries,scrap_queries,post_machining_queries,post_machining_nok_queries,post_machining_rework_queries,targets,post_targets,hourly_queries,hourly_nok_queries,graph_labels
HIDDEN_TILES={"QLW01","QLW02","QLW03","QALT"}
def format_status(s):
    s=str(s).strip().upper()
    if "OPERATIONAL_BREAKDOWN" in s:return "Operational Breakdown"
    if "BREAKDOWN" in s:return "Breakdown"
    if "MES BYPASS" in s:return "MES Bypass"
    return "Operational"
def status_details(s):
    s=str(s).upper()
    if "OPERATIONAL BREAKDOWN" in s:return "#FF8C00","🟠"
    if "BREAKDOWN" in s:return "#D50000","🔴"
    if "MES BYPASS" in s:return "#7B1FA2","🟣"
    return "#138A36","🟢"
def downtime_df():
    c=get_connection();cur=c.cursor();cur.execute("SELECT WorkCenter,DATEADD(MINUTE,330,DowntimeStartTime) DowntimeStartTime_ist,DATEADD(MINUTE,330,DowntimeEndTime) DowntimeEndTime_ist,DATEADD(MINUTE,330,LastUpdateOn) LastUpdateOn_ist,Type FROM AT_DowntimeData WHERE DowntimeStartTime>=?",parse_today_time(config.SHIFT_START_UTC)); rows=cur.fetchall(); cols=[x[0] for x in cur.description];cur.close();c.close();return pd.DataFrame.from_records(rows,columns=cols)
def val(cur,q,start):
    cur.execute(q,start);r=cur.fetchone();return int(r[0]) if r and r[0] is not None else 0
def load_machine_data(df=None):
    if df is None:df=downtime_df()
    c=get_connection();cur=c.cursor();out=[]; shift=parse_today_time(config.SHIFT_START_IST); start=parse_today_time(config.SHIFT_START_UTC)
    for m in machine_display:
        cur.execute("SELECT TOP 1 DATEADD(MINUTE,330,StartTime) StartTime_IST,DATEADD(MINUTE,330,EndTime) EndTime_IST,* FROM AT_MESBypassData WHERE WorkCenter=? ORDER BY ID DESC",m);mes=cur.fetchone(); row=None
        if not df.empty:
            x=df[df.WorkCenter.astype(str).str.contains(m,na=False)]
            if not x.empty:row=x.sort_values('DowntimeStartTime_ist',ascending=False).iloc[0]
        status='Operational';since=shift.strftime('%d-%b-%y %H:%M:%S');runtime=elapsed_time(shift)
        if mes and mes.StartTime_IST is not None and mes.EndTime_IST is None:status='MES BYPASS';since=mes.StartTime_IST.strftime('%d-%b-%y %H:%M:%S');runtime=elapsed_time(mes.StartTime_IST)
        elif row is not None:
            if pd.isna(row['DowntimeEndTime_ist']): status='OPERATIONAL_BREAKDOWN' if str(row['Type']).upper()=='OPERATIONAL_BREAKDOWN' else 'BREAKDOWN'; since=row['DowntimeStartTime_ist'].strftime('%d-%b-%y %H:%M:%S');runtime=elapsed_time(row['DowntimeStartTime_ist'])
            else: since=row['DowntimeEndTime_ist'].strftime('%d-%b-%y %H:%M:%S');runtime=elapsed_time(row['DowntimeEndTime_ist'])
        if m=='BRZN_FX': since=shift.strftime('%d-%b-%Y %I:%M:%S %p');runtime=elapsed_time(shift)
        ok=val(cur,machine_queries[m],start) if m in machine_queries else 0; rw=val(cur,rework_queries[m],start) if m in rework_queries else 0; scrap=val(cur,scrap_queries[m],start) if m in scrap_queries else 0
        target=int(targets.get(m,0)*((datetime.now()-shift).total_seconds()/3600)); pc='#D50000' if target>ok else '#138A36'; arrow='▼' if target>ok else '▲'; a,icon=status_details(status); o=get_oee(m,ok,rw,scrap,c)
        out.append(dict(machine=m,display_name=machine_display[m],status=format_status(status),status_color=a,status_icon=icon,since=since,runtime=runtime,prod_count=ok,rework_count=rw,rw_count=rw,scrap_count=scrap,nok_count=0,target_label=target,part_count_color=pc,arrow=arrow,reason_alarm='-',ack_by='-',**o,matrix_value=100))
    c.close();return out
def machining_table(m):
    w=m.replace('OP_','OP-');return 'AT_VMC1Process' if w.startswith(('OP-10','OP-20')) else 'AT_VMC2Process' if w.startswith(('OP-30','OP-40','OP-50')) else None
def machining_counts(m,cur):
    w=m.replace('OP_','OP-');t=machining_table(m);s=parse_today_time(config.SHIFT_START_UTC); base=f"FROM {t} WHERE CreatedOn BETWEEN ? AND GETDATE() AND WorkCenter LIKE '%{w}%' AND OutputScan=1 AND Active=1"; ok=val(cur,f"SELECT COUNT(*) {base} AND IsRejected=0",s);rw=val(cur,f"SELECT COUNT(*) {base} AND IsRejected=1 AND WipOrderNo LIKE '%R00%'",s);nok=val(cur,f"SELECT COUNT(*) {base} AND IsRejected=1",s);return ok,rw,nok
def load_machining_data():
    c=get_connection();cur=c.cursor();out=[];shift=parse_today_time(config.SHIFT_START_IST)
    for m,name in machining_display.items():
        ok,rw,nok=machining_counts(m,cur);elapsed=(datetime.now()-shift).total_seconds()/3600;t=get_machining_target(m);target=int(t*elapsed);pc='#D50000' if ok<target else '#138A36';arrow='▼' if ok<target else '▲';o=get_machining_oee(m,ok,rw,nok,c);out.append(dict(machine=m,display_name=name,prod_count=ok,rework_count=rw,rw_count=rw,scrap_count=nok,nok_count=nok,status='Operational',status_color='#138A36',status_icon='🟢',since=datetime.now().strftime('%d-%b-%y 06:30:00'),runtime=elapsed_time(shift),reason_alarm='-',target_label=target,part_count_color=pc,ack_by='-',arrow=arrow,**o,matrix_value=t))
    c.close();return out
def load_post_machining_data(df=None):
    if df is None:df=downtime_df()
    c=get_connection();cur=c.cursor();out=[];shift=parse_today_time(config.SHIFT_START_IST);s=parse_today_time(config.SHIFT_START_UTC)
    for m,name in post_machining_display.items():
        ok=val(cur,post_machining_queries[m],s);nok=val(cur,post_machining_nok_queries[m],s);rw=val(cur,post_machining_rework_queries[m],s);status='Operational';since=shift.strftime('%d-%b-%y %H:%M:%S');runtime=elapsed_time(shift);x=df[df.WorkCenter.astype(str).str.contains(m,na=False)] if not df.empty else pd.DataFrame()
        if not x.empty:
            r=x[x.Type.astype(str).str.upper()=='BREAKDOWNTIME'].sort_values('DowntimeStartTime_ist',ascending=False).iloc[0] if not x[x.Type.astype(str).str.upper()=='BREAKDOWNTIME'].empty else None
            if r is not None:
                if pd.isna(r['DowntimeEndTime_ist']):status='BREAKDOWN';since=r['DowntimeStartTime_ist'].strftime('%d-%b-%y %H:%M:%S');runtime=elapsed_time(r['DowntimeStartTime_ist'])
                else:since=r['DowntimeEndTime_ist'].strftime('%d-%b-%y %H:%M:%S');runtime=elapsed_time(r['DowntimeEndTime_ist'])
        target=int(post_targets.get(m,0)*((datetime.now()-shift).total_seconds()/3600));pc='#D50000' if ok<target else '#138A36';arrow='▼' if ok<target else '▲';o=get_oee(m,ok,rw,nok,c);a,icon=status_details(status);out.append(dict(machine=m,display_name=name,status=format_status(status),status_color=a,status_icon=icon,since=since,runtime=runtime,prod_count=ok,rw_count=rw,rework_count=rw,scrap_count=nok,nok_count=nok,reason_alarm='-',target_label=target,part_count_color=pc,ack_by='-',arrow=arrow,**o,matrix_value=100))
    c.close();return out
def get_machines(section):return load_machine_data() if section=='PRE_MACHINING' else load_machining_data() if section=='MACHINING' else load_post_machining_data() if section=='POST_MACHINING' else []
def saved(machine):
    if not os.path.exists('andon_ack.csv'):return None,None
    d=pd.read_csv('andon_ack.csv');r=d[d.Machine==machine]
    if r.empty:return None,None
    x=r.iloc[-1];return x.ReasonCode,x.AcknowledgedBy
def save_reason(machine,status,reason,user):
    n=pd.DataFrame([{'Machine':machine,'Status':status,'ReasonCode':reason,'AcknowledgedBy':user,'AcknowledgedOn':datetime.now()}]);
    if os.path.exists('andon_ack.csv'):
        d=pd.read_csv('andon_ack.csv');d=d[d.Machine!=machine];n=pd.concat([d,n],ignore_index=True)
    n.to_csv('andon_ack.csv',index=False)
