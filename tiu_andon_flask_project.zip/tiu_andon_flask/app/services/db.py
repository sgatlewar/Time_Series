import pyodbc
from .. import config
def get_connection():
    cs=(f"DRIVER={config.DB_DRIVER};SERVER={config.DB_SERVER};DATABASE={config.DB_DATABASE};UID={config.DB_UID};PWD={config.DB_PWD};Encrypt={config.DB_ENCRYPT};")
    return pyodbc.connect(cs,autocommit=True)
