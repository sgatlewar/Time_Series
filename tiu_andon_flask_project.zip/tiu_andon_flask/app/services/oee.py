from datetime import datetime
from .. import config
def parse_today_time(t): return datetime.strptime(datetime.now().strftime("%Y-%m-%d")+" "+t,"%Y-%m-%d %H:%M:%S")
def elapsed_time(start):
    if start is None:return "00:00:00"
    s=max(int((datetime.now()-start).total_seconds()),0); return f"{s//3600:02}:{(s%3600)//60:02}:{s%60:02}"
def calculate_availability(machine,conn):
    u=parse_today_time(config.SHIFT_START_UTC); i=parse_today_time(config.SHIFT_START_IST); planned=(datetime.now()-i).total_seconds()/60
    if planned<=0:return 0.0,0.0
    q="""SELECT DATEADD(MINUTE,330,DowntimeStartTime) AS StartTime, DATEADD(MINUTE,330,ISNULL(DowntimeEndTime,GETDATE())) AS EndTime FROM AT_DowntimeData WHERE WorkCenter LIKE ? AND type='BreakDownTime' AND DowntimeStartTime>=?"""
    c=conn.cursor(); c.execute(q,f"%{machine}%",u); down=sum((r.EndTime-r.StartTime).total_seconds()/60 for r in c.fetchall()); runtime=max(planned-down,0); return runtime/planned,runtime
def calculate_productivity(ok,runtime,ideal=None):
    ideal=config.IDEAL_TIME_SECONDS if ideal is None else ideal; sec=runtime*60
    return 0.0 if sec<=0 else round((ok*ideal)/sec,4)
def calculate_quality(ok,rw,scrap):
    total=ok+rw+scrap; return 0.0 if total==0 else round(ok/total,4)
def get_oee(machine,ok,rw,scrap,conn):
    a,r=calculate_availability(machine,conn); p=calculate_productivity(ok,r); q=calculate_quality(ok,rw,scrap); o=a*p*q
    return {"availability":round(a*100,2),"productivity":round(p*100,2),"quality":round(q*100,2),"oee":round(o*100,2)}
def get_machining_target(machine):
    w=machine.replace("OP_","OP-")
    if w.startswith(("OP-10","OP-20")):return 20
    if w.startswith("OP-30") or w.startswith("OP-40"):return 4
    if w.startswith("OP-50"):return 30
    return 0
def calculate_machining_productivity(machine,ok,runtime):
    if runtime<=0:return 0
    target=get_machining_target(machine)*(runtime/60)
    return 0 if target<=0 else round(min(ok/target,1.0),4)
def calculate_machining_quality(ok,rw,nok):
    total=ok+rw+nok; return 0 if total==0 else round(ok/total,4)
def get_machining_oee(machine,ok,rw,nok,conn):
    a,r=calculate_availability(machine,conn); p=calculate_machining_productivity(machine,ok,r); q=calculate_machining_quality(ok,rw,nok); o=a*p*q
    return {"availability":round(a*100,2),"productivity":round(p*100,2),"quality":round(q*100,2),"oee":round(o*100,2)}
