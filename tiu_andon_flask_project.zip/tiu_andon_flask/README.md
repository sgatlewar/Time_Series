# TIU Andon Flask Conversion

Converted from the supplied Streamlit source to Flask + Jinja + JavaScript + pyodbc. Existing machine/query dictionaries and OEE formulas are retained in `app/config.py` and `app/services/`.

The supplied source references `templates/index2.html`, but that separate file was not present in the provided source. An equivalent native Jinja machine card is included.

## Run
1. Copy `.env.example` to `.env` and set the SQL password.
2. `python -m venv .venv`
3. `.\.venv\Scripts\activate`
4. `pip install -r requirements.txt`
5. `python run.py`
6. Open `http://localhost:8501`

Production: `waitress-serve --listen=0.0.0.0:8501 run:app`

Demo users from the current app are retained for compatibility; replace them with hashed SQL-backed users before production.
