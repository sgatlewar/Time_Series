function updateClock() {
  const el = document.getElementById("clock");
  if (!el) return;
  const now = new Date();
  const day = String(now.getDate()).padStart(2, "0");
  const month = now.toLocaleString("en-US", {month:"short"});
  const year = now.getFullYear();
  let hours = now.getHours();
  const ampm = hours >= 12 ? "PM" : "AM";
  hours = hours % 12 || 12;
  el.textContent = `${day}-${month}-${year} ${String(hours).padStart(2,"0")}:${String(now.getMinutes()).padStart(2,"0")} ${ampm}`;
}
setInterval(updateClock, 1000);
document.addEventListener("DOMContentLoaded", () => {
  updateClock();
  loadMachines();
  setInterval(loadMachines, 30000);
});

async function loadMachines() {
  const grid = document.getElementById("machine-grid");
  if (!grid) return;
  const section = grid.dataset.section;
  const page = grid.dataset.machiningPage;
  const view = grid.dataset.machiningView;
  try {
    const response = await fetch(`/api/machines/${encodeURIComponent(section)}`, {cache:"no-store"});
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const payload = await response.json();
    let machines = payload.machines || [];

    if (section === "MACHINING") {
      if (page === "VMC1") machines = machines.filter(m => m.machine.startsWith("OP_10") || m.machine.startsWith("OP_20"));
      if (page === "VMC2") {
        const prefix = view === "OP40" ? "OP_40" : view === "OP50" ? "OP_50" : "OP_30";
        machines = machines.filter(m => m.machine.startsWith(prefix));
      }
    } else {
      machines = machines.filter(m => !["QLW01","QLW02","QLW03","QALT"].includes(m.machine));
    }

    grid.innerHTML = machines.map(renderCard).join("");
  } catch (err) {
    grid.innerHTML = `<div class="error-box">Unable to load machine data: ${escapeHtml(err.message)}</div>`;
  }
}

function renderCard(m) {
  const statusColor = m.status === "Breakdown" ? "#D50000" :
                      m.status === "Operational Breakdown" ? "#FF8C00" :
                      m.status === "MES Bypass" ? "#7B1FA2" : "#138A36";
  const icon = m.status === "Breakdown" ? "🔴" :
               m.status === "Operational Breakdown" ? "🟠" :
               m.status === "MES Bypass" ? "🟣" : "🟢";
  return `
  <div class="andon-card" onclick="location.href='/machine/${encodeURIComponent(m.machine_section || document.getElementById('machine-grid').dataset.section)}/${encodeURIComponent(m.machine)}'">
    <div class="card-header">
      <div class="machine-name">${escapeHtml(m.display_name)}</div>
      <div class="status" style="color:${statusColor}">${icon} ${escapeHtml(m.status)}</div>
      <div class="since">Since: ${escapeHtml(m.since)}</div>
    </div>
    <div class="runtime">${escapeHtml(m.runtime)}</div>
    <div class="count-row">
      <div><span>OK COUNT</span><strong style="color:${m.part_count_color}">${m.prod_count}</strong></div>
      <div><span>REWORK</span><strong class="rw">${m.rw_count}</strong></div>
      <div><span>NOK</span><strong class="nok">${m.scrap_count}</strong></div>
      <div><span>TARGET</span><strong>${m.target_label}</strong></div>
    </div>
    <div class="target-line">
      <span class="arrow ${m.arrow === '▼' ? 'down' : 'up'}">${m.arrow}</span>
      <span>${escapeHtml(m.reason_alarm || "-")}</span>
      ${m.ack_by && m.ack_by !== "-" ? `<span>Ack: ${escapeHtml(m.ack_by)}</span>` : ""}
    </div>
    <div class="oee-grid">
      <div><span>Availability</span><b>${m.availability}%</b></div>
      <div><span>Productivity</span><b>${m.productivity}%</b></div>
      <div><span>Quality</span><b>${m.quality}%</b></div>
      <div class="oee-total"><span>OEE</span><b>${m.oee}%</b></div>
    </div>
  </div>`;
}
function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
}
