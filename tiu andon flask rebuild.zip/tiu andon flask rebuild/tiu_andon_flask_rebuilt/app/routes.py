from functools import wraps
from flask import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify

from app.config import USERS, REASON_CODES
from app.services.dashboard_service import (
    get_machines, get_machine, save_reason_code, get_saved_reason,
    clear_acknowledgement
)

main_bp = Blueprint("main", __name__)

def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("logged_in"):
            return redirect(url_for("main.login"))
        return view(*args, **kwargs)
    return wrapped

@main_bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if username in USERS and USERS[username]["password"] == password:
            session["logged_in"] = True
            session["username"] = username
            session["role"] = USERS[username]["role"]
            return redirect(url_for("main.index"))
        flash("Invalid Username or Password", "error")
    return render_template("login.html")

@main_bp.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("main.login"))

@main_bp.route("/")
@login_required
def index():
    section = request.args.get("section")
    machining_page = request.args.get("machining_page")
    machining_view = request.args.get("machining_view", "OP30")
    return render_template(
        "index.html",
        section=section,
        machining_page=machining_page,
        machining_view=machining_view,
        username=session.get("username"),
        role=session.get("role"),
        reason_codes=REASON_CODES,
    )

@main_bp.route("/main-menu")
@login_required
def main_menu():
    return redirect(url_for("main.index"))

@main_bp.route("/section/<section>")
@login_required
def section(section):
    section = section.upper()
    if section not in {"PRE_MACHINING", "MACHINING", "POST_MACHINING"}:
        return redirect(url_for("main.index"))
    return redirect(url_for("main.index", section=section))

@main_bp.route("/machining/<page>")
@login_required
def machining_page(page):
    page = page.upper()
    if page not in {"VMC1", "VMC2"}:
        return redirect(url_for("main.index", section="MACHINING"))
    return redirect(url_for("main.index", section="MACHINING", machining_page=page))

@main_bp.route("/machining/operation/<operation>")
@login_required
def machining_operation(operation):
    operation = operation.upper()
    if operation not in {"OP30", "OP40", "OP50"}:
        operation = "OP30"
    return redirect(url_for(
        "main.index",
        section="MACHINING",
        machining_page="VMC2",
        machining_view=operation
    ))

@main_bp.route("/view/<view_mode>")
@login_required
def view_mode(view_mode):
    return redirect(url_for("main.index", section=request.args.get("section")))

@main_bp.route("/auto-rotate")
@login_required
def auto_rotate():
    return redirect(url_for("main.index", section=request.args.get("section")))

@main_bp.route("/machine/<section>/<machine_code>")
@login_required
def machine_detail(section, machine_code):
    machine = get_machine(section.upper(), machine_code)
    if not machine:
        flash("Machine not found", "error")
        return redirect(url_for("main.index", section=section.upper()))
    reason, ack_by = get_saved_reason(machine_code)
    return render_template(
        "machine_detail.html",
        machine=machine,
        reason=reason,
        ack_by=ack_by,
        reason_codes=REASON_CODES,
        section=section.upper(),
    )

@main_bp.post("/acknowledge")
@login_required
def acknowledge():
    machine = request.form.get("machine", "").strip()
    status = request.form.get("status", "Operational")
    reason_code = request.form.get("reason_code", "").strip()
    if not machine or not reason_code:
        flash("Machine and Reason Code are required", "error")
        return redirect(request.referrer or url_for("main.index"))

    save_reason_code(machine, status, reason_code, session.get("username", ""))
    flash("Acknowledged", "success")
    return redirect(request.referrer or url_for("main.index"))

@main_bp.post("/clear-acknowledgement")
@login_required
def clear_ack():
    machine = request.form.get("machine", "").strip()
    if machine:
        clear_acknowledgement(machine)
    return redirect(request.referrer or url_for("main.index"))

@main_bp.get("/api/machines/<section>")
@login_required
def machines_api(section):
    return jsonify({
        "section": section.upper(),
        "machines": get_machines(section.upper()),
    })
