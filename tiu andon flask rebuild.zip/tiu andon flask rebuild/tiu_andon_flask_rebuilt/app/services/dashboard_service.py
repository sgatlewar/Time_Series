from datetime import datetime
from pathlib import Path
import pandas as pd

from app.config import (
    machine_display, machining_display, post_machining_display,
    machine_queries, rework_queries, scrap_queries,
    post_machining_queries, post_machining_nok_queries,
    post_machining_rework_queries, targets, post_targets
)
from app.services.db import get_connection, scalar

BASE_DIR = Path(__file__).resolve().parents[2]
ACK_FILE = BASE_DIR / "andon_ack.csv"

def shift_start_utc():
    return datetime.strptime(datetime.now().strftime("%Y-%m-%d") + " 01:00:00", "%Y-%m-%d %H:%M:%S")

def shift_start_ist():
    return datetime.strptime(datetime.now().strftime("%Y-%m-%d") + " 06:30:00", "%Y-%m-%d %H:%M:%S")

def get_elapsed_time(start_time):
    if start_time is None:
        return "00:00:00"
    seconds = max(0, int((datetime.now() - start_time).total_seconds()))
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    seconds = seconds % 60
    return f"{hours:02}:{minutes:02}:{seconds:02}"

def format_status(status):
    status = str(status).strip().upper()
    if "MES BYPASS" in status:
        return "MES Bypass"
    if "OPERATIONAL_BREAKDOWN" in status:
        return "Operational Breakdown"
    if "BREAKDOWN" in status:
        return "Breakdown"
    return "Operational"

def get_status_details(status):
    status = str(status).upper()
    if "MES BYPASS" in status:
        return "#7B1FA2", "🟣"
    if "OPERATIONAL BREAKDOWN" in status:
        return "#FF8C00", "🟠"
    if "BREAKDOWN" in status:
        return "#D50000", "🔴"
    return "#138A36", "🟢"

def load_downtime_data():
    conn = get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT
                WorkCenter,
                DATEADD(MINUTE, 330, DowntimeStartTime) AS DowntimeStartTime_ist,
                DATEADD(MINUTE, 330, DowntimeEndTime) AS DowntimeEndTime_ist,
                DATEADD(MINUTE, 330, LastUpdateOn) AS LastUpdateOn_ist,
                Type
            FROM AT_DowntimeData
            WHERE DowntimeStartTime >= ?
        """, shift_start_utc())
        rows = cursor.fetchall()
        return pd.DataFrame.from_records(
            rows, columns=[c[0] for c in cursor.description]
        )
    finally:
        conn.close()

def _safe_downtime_frame():
    try:
        return load_downtime_data()
    except Exception:
        return pd.DataFrame(columns=[
            "WorkCenter", "DowntimeStartTime_ist", "DowntimeEndTime_ist",
            "LastUpdateOn_ist", "Type"
        ])

def _latest_downtime_for_machine(downtime_df, machine):
    if downtime_df.empty:
        return None
    work = downtime_df["WorkCenter"].fillna("").astype(str)
    rows = downtime_df[work.str.contains(machine, regex=False, na=False)]
    if rows.empty:
        return None
    return rows.sort_values("DowntimeStartTime_ist", ascending=False).iloc[0]

def _latest_meso_bypass(cursor, machine):
    cursor.execute("""
        SELECT TOP 1
            DATEADD(MINUTE,330,StartTime) AS StartTime_IST,
            DATEADD(MINUTE,330,EndTime) AS EndTime_IST,
            *
        FROM AT_MESBypassData
        WHERE WorkCenter = ?
        ORDER BY ID DESC
    """, machine)
    return cursor.fetchone()

def _count_from_query(cursor, query, start_time):
    return scalar(cursor, query, start_time) if query else 0

def calculate_availability(machine, conn):
    shift_utc = shift_start_utc()
    shift_ist = shift_start_ist()
    planned_minutes = max((datetime.now() - shift_ist).total_seconds() / 60, 0)

    if planned_minutes <= 0:
        return 0.0, 0.0

    cursor = conn.cursor()
    cursor.execute("""
        SELECT
            DATEADD(MINUTE,330,DowntimeStartTime) AS StartTime,
            DATEADD(MINUTE,330,ISNULL(DowntimeEndTime,GETDATE())) AS EndTime
        FROM AT_DowntimeData
        WHERE WorkCenter LIKE ?
          AND type = 'BreakDownTime'
          AND DowntimeStartTime >= ?
    """, f"%{machine}%", shift_utc)

    total_downtime = 0.0
    for row in cursor.fetchall():
        if row.StartTime and row.EndTime:
            total_downtime += max(0, (row.EndTime - row.StartTime).total_seconds() / 60)

    runtime_minutes = max(planned_minutes - total_downtime, 0)
    availability = runtime_minutes / planned_minutes if planned_minutes else 0
    return availability, runtime_minutes

def calculate_productivity(ok_count, runtime_minutes, ideal_time_seconds=33):
    runtime_seconds = runtime_minutes * 60
    if runtime_seconds <= 0:
        return 0.0
    return round((ok_count * ideal_time_seconds) / runtime_seconds, 4)

def calculate_quality(machine_data):
    ok_count = machine_data.get("prod_count", 0)
    rework_count = machine_data.get("rework_count", 0)
    scrap_count = machine_data.get("scrap_count", 0)
    total_count = ok_count + rework_count + scrap_count
    if total_count == 0:
        return 0.0
    return round(ok_count / total_count, 4)

def get_oee(machine_code, prod_count, rework_count, scrap_count, conn):
    availability, runtime_minutes = calculate_availability(machine_code, conn)
    productivity = calculate_productivity(prod_count, runtime_minutes, ideal_time_seconds=33)
    total_count = prod_count + rework_count + scrap_count
    quality = prod_count / total_count if total_count > 0 else 0
    oee = availability * productivity * quality
    return {
        "availability": round(availability * 100, 2),
        "productivity": round(productivity * 100, 2),
        "quality": round(quality * 100, 2),
        "oee": round(oee * 100, 2),
    }

def get_machining_target(machine):
    workcenter = machine.replace("OP_", "OP-")
    if workcenter.startswith(("OP-10", "OP-20")):
        return 20
    if workcenter.startswith("OP-30"):
        return 4
    if workcenter.startswith("OP-40"):
        return 4
    if workcenter.startswith("OP-50"):
        return 30
    return 0

def get_machining_table(machine):
    workcenter = machine.replace("OP_", "OP-")
    if workcenter.startswith(("OP-10", "OP-20")):
        return "AT_VMC1Process"
    if workcenter.startswith(("OP-30", "OP-40", "OP-50")):
        return "AT_VMC2Process"
    return None

def get_machining_production_count(machine, cursor):
    table = get_machining_table(machine)
    if not table:
        return 0
    wc = machine.replace("OP_", "OP-")
    return scalar(cursor, f"""
        SELECT ISNULL(COUNT(*),0)
        FROM {table}
        WHERE CreatedOn BETWEEN ? AND GETDATE()
          AND WorkCenter LIKE ?
          AND OutputScan = 1
          AND Active = 1
          AND IsRejected = 0
    """, datetime.now().strftime("%Y-%m-%d 01:00:00"), f"%{wc}%")

def get_machining_rework_count(machine, cursor):
    table = get_machining_table(machine)
    if not table:
        return 0
    wc = machine.replace("OP_", "OP-")
    return scalar(cursor, f"""
        SELECT ISNULL(COUNT(*),0)
        FROM {table}
        WHERE CreatedOn BETWEEN ? AND GETDATE()
          AND WorkCenter LIKE ?
          AND OutputScan = 1
          AND Active = 1
          AND IsRejected = 1
          AND WipOrderNo LIKE '%R00%'
    """, datetime.now().strftime("%Y-%m-%d 01:00:00"), f"%{wc}%")

def get_machining_nok_count(machine, cursor):
    table = get_machining_table(machine)
    if not table:
        return 0
    wc = machine.replace("OP_", "OP-")
    return scalar(cursor, f"""
        SELECT ISNULL(COUNT(*),0)
        FROM {table}
        WHERE CreatedOn BETWEEN ? AND GETDATE()
          AND WorkCenter LIKE ?
          AND OutputScan = 1
          AND Active = 1
          AND IsRejected = 1
    """, datetime.now().strftime("%Y-%m-%d 01:00:00"), f"%{wc}%")

def calculate_machining_productivity(machine, ok_count, runtime_minutes):
    if runtime_minutes <= 0:
        return 0
    target_per_hour = get_machining_target(machine)
    runtime_hours = runtime_minutes / 60
    target_qty = target_per_hour * runtime_hours
    if target_qty <= 0:
        return 0
    return round(min(ok_count / target_qty, 1.0), 4)

def calculate_machining_quality(ok_count, rework_count, nok_count):
    total = ok_count + nok_count + rework_count
    if total == 0:
        return 0
    return round(ok_count / total, 4)

def get_machining_oee(machine_code, prod_count, rework_count, nok_count, conn):
    availability, runtime_minutes = calculate_availability(machine_code, conn)
    productivity = calculate_machining_productivity(machine_code, prod_count, runtime_minutes)
    quality = calculate_machining_quality(prod_count, rework_count, nok_count)
    oee = availability * productivity * quality
    return {
        "availability": round(availability * 100, 2),
        "productivity": round(productivity * 100, 2),
        "quality": round(quality * 100, 2),
        "oee": round(oee * 100, 2),
    }

def get_post_machining_count(query, cursor):
    return scalar(cursor, query, datetime.now().strftime("%Y-%m-%d 01:00:00"))

def get_post_machining_ok_count(machine, cursor):
    return get_post_machining_count(post_machining_queries[machine], cursor)

def get_post_machining_nok_count(machine, cursor):
    return get_post_machining_count(post_machining_nok_queries[machine], cursor)

def get_post_machining_rework_count(machine, cursor):
    return get_post_machining_count(post_machining_rework_queries[machine], cursor)

def save_reason_code(machine, status, reason_code, username):
    new_row = pd.DataFrame([{
        "Machine": machine,
        "Status": status,
        "ReasonCode": reason_code,
        "AcknowledgedBy": username,
        "AcknowledgedOn": datetime.now(),
    }])
    if ACK_FILE.exists():
        old = pd.read_csv(ACK_FILE)
        old = old[old["Machine"] != machine]
        df = pd.concat([old, new_row], ignore_index=True)
    else:
        df = new_row
    df.to_csv(ACK_FILE, index=False)

def clear_acknowledgement(machine):
    if not ACK_FILE.exists():
        return
    df = pd.read_csv(ACK_FILE)
    df = df[df["Machine"] != machine]
    df.to_csv(ACK_FILE, index=False)

def get_saved_reason(machine):
    if not ACK_FILE.exists():
        return None, None
    df = pd.read_csv(ACK_FILE)
    result = df[df["Machine"] == machine]
    if result.empty:
        return None, None
    row = result.iloc[-1]
    return row.get("ReasonCode"), row.get("AcknowledgedBy")

def _status_for_pre_machine(cursor, downtime_df, machine):
    status = "Operational"
    shift = shift_start_ist()
    since = shift.strftime("%d-%b-%y %H:%M:%S")
    runtime = get_elapsed_time(shift)

    try:
        mes_row = _latest_meso_bypass(cursor, machine)
    except Exception:
        mes_row = None

    row = _latest_downtime_for_machine(downtime_df, machine)

    if mes_row and getattr(mes_row, "StartTime_IST", None) is not None and getattr(mes_row, "EndTime_IST", None) is None:
        status = "MES BYPASS"
        since = mes_row.StartTime_IST.strftime("%d-%b-%y %H:%M:%S")
        runtime = get_elapsed_time(mes_row.StartTime_IST)
    elif row is not None:
        end = row.get("DowntimeEndTime_ist")
        start = row.get("DowntimeStartTime_ist")
        if pd.isna(end):
            dtype = str(row.get("Type", "")).upper()
            status = "BREAKDOWN" if dtype == "BREAKDOWNTIME" else (
                "OPERATIONAL_BREAKDOWN" if dtype == "OPERATIONAL_BREAKDOWN" else "BREAKDOWN"
            )
            since = start.strftime("%d-%b-%y %H:%M:%S") if pd.notna(start) else since
            runtime = get_elapsed_time(start)
        elif pd.notna(end):
            status = "Operational"
            since = end.strftime("%d-%b-%y %H:%M:%S")
            runtime = get_elapsed_time(end)

    if machine == "BRZN_FX":
        since = shift.strftime("%d-%b-%Y %I:%M:%S %p")
        runtime = get_elapsed_time(shift)

    return format_status(status), since, runtime

def load_machine_data(downtime_df=None):
    if downtime_df is None:
        downtime_df = _safe_downtime_frame()
    conn = get_connection()
    try:
        cursor = conn.cursor()
        machines = []
        for machine in machine_display:
            status, since, runtime = _status_for_pre_machine(cursor, downtime_df, machine)
            start = datetime.now().strftime("%Y-%m-%d 01:00:00")
            prod_count = _count_from_query(cursor, machine_queries.get(machine), start)
            rework_count = _count_from_query(cursor, rework_queries.get(machine), start)
            scrap_count = _count_from_query(cursor, scrap_queries.get(machine), start)

            shift = shift_start_ist()
            elapsed_hours = max((datetime.now() - shift).total_seconds() / 3600, 0)
            target_qty = int(targets.get(machine, 0) * elapsed_hours)
            color = "#D50000" if target_qty > prod_count else "#138A36"
            arrow = "▼" if target_qty > prod_count else "▲"
            reason, ack_by = get_saved_reason(machine)
            oee = get_oee(machine, prod_count, rework_count, scrap_count, conn)

            machines.append({
                "machine": machine,
                "display_name": machine_display.get(machine, machine),
                "status": status,
                "since": since,
                "runtime": runtime,
                "prod_count": prod_count,
                "part_count_color": color,
                "target_label": target_qty,
                "reason_alarm": reason or "-",
                "ack_by": ack_by or "-",
                "arrow": arrow,
                "rw_count": rework_count,
                "rework_count": rework_count,
                "scrap_count": scrap_count,
                "availability": oee["availability"],
                "productivity": oee["productivity"],
                "quality": oee["quality"],
                "oee": oee["oee"],
                "matrix_value": 100,
            })
        return machines
    finally:
        conn.close()

def load_machining_data():
    conn = get_connection()
    try:
        cursor = conn.cursor()
        machines = []
        for machine, display_name in machining_display.items():
            prod_count = get_machining_production_count(machine, cursor)
            nok_count = get_machining_nok_count(machine, cursor)
            rework_count = get_machining_rework_count(machine, cursor)
            shift = shift_start_ist()
            elapsed_hours = max((datetime.now() - shift).total_seconds() / 3600, 0)
            target = get_machining_target(machine)
            target_qty = int(target * elapsed_hours)
            color = "#D50000" if prod_count < target_qty else "#138A36"
            arrow = "▼" if prod_count < target_qty else "▲"
            oee = get_machining_oee(machine, prod_count, rework_count, nok_count, conn)
            machines.append({
                "machine": machine,
                "display_name": display_name,
                "prod_count": prod_count,
                "scrap_count": nok_count,
                "status": "Operational",
                "since": datetime.now().strftime("%d-%b-%y 06:30:00"),
                "runtime": get_elapsed_time(shift),
                "reason_alarm": "-",
                "target_label": target_qty,
                "part_count_color": color,
                "ack_by": "-",
                "arrow": arrow,
                "rw_count": rework_count,
                "rework_count": rework_count,
                "availability": oee["availability"],
                "productivity": oee["productivity"],
                "quality": oee["quality"],
                "oee": oee["oee"],
                "matrix_value": target,
            })
        return machines
    finally:
        conn.close()

def load_post_machining_data(downtime_df=None):
    if downtime_df is None:
        downtime_df = _safe_downtime_frame()
    conn = get_connection()
    try:
        cursor = conn.cursor()
        machines = []
        for machine, display_name in post_machining_display.items():
            ok_count = get_post_machining_ok_count(machine, cursor)
            nok_count = get_post_machining_nok_count(machine, cursor)
            rework_count = get_post_machining_rework_count(machine, cursor)
            shift = shift_start_ist()
            status = "Operational"
            since = shift.strftime("%d-%b-%y %H:%M:%S")
            runtime = get_elapsed_time(shift)

            work = downtime_df["WorkCenter"].fillna("").astype(str) if not downtime_df.empty else pd.Series(dtype=str)
            if not downtime_df.empty:
                rows = downtime_df[
                    work.str.contains(machine, regex=False, na=False) &
                    downtime_df["Type"].fillna("").astype(str).str.lower().eq("breakdowntime")
                ]
            else:
                rows = pd.DataFrame()

            if not rows.empty:
                row = rows.sort_values("DowntimeStartTime_ist", ascending=False).iloc[0]
                end = row.get("DowntimeEndTime_ist")
                start = row.get("DowntimeStartTime_ist")
                if pd.isna(end):
                    status = "BREAKDOWN"
                    since = start.strftime("%d-%b-%y %H:%M:%S")
                    runtime = get_elapsed_time(start)
                else:
                    since = end.strftime("%d-%b-%y %H:%M:%S")
                    runtime = get_elapsed_time(end)

            elapsed_hours = max((datetime.now() - shift).total_seconds() / 3600, 0)
            target_qty = int(post_targets.get(machine, 0) * elapsed_hours)
            color = "#D50000" if ok_count < target_qty else "#138A36"
            arrow = "▼" if ok_count < target_qty else "▲"
            oee = get_oee(machine, ok_count, rework_count, nok_count, conn)
            reason, ack_by = get_saved_reason(machine)

            machines.append({
                "machine": machine,
                "display_name": display_name,
                "status": format_status(status),
                "since": since,
                "runtime": runtime,
                "prod_count": ok_count,
                "rw_count": rework_count,
                "rework_count": rework_count,
                "scrap_count": nok_count,
                "reason_alarm": reason or "-",
                "target_label": target_qty,
                "part_count_color": color,
                "ack_by": ack_by or "-",
                "arrow": arrow,
                "availability": oee["availability"],
                "productivity": oee["productivity"],
                "quality": oee["quality"],
                "oee": oee["oee"],
                "matrix_value": 100,
            })
        return machines
    finally:
        conn.close()

def get_machines(section):
    if section == "PRE_MACHINING":
        return load_machine_data()
    if section == "MACHINING":
        return load_machining_data()
    if section == "POST_MACHINING":
        return load_post_machining_data()
    return []

# This is the missing function that caused the reported ImportError.
def get_machine(section, machine_code):
    for machine in get_machines(section):
        if str(machine.get("machine", "")).upper() == str(machine_code).upper():
            return machine
    return None
