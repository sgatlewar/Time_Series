# TIU Andon - Rebuilt Flask Project

This project was rebuilt from the supplied Streamlit source.

## Source-preserved behavior

- PRE-MACHINING, MACHINING, POST-MACHINING sections
- Original machine lists and display names
- Original production/rework/scrap SQL dictionaries
- VMC1 = OP-10 / OP-20
- VMC2 = OP-30 / OP-40 / OP-50
- Machining targets: OP-10/20 = 20/hr, OP-30/40 = 4/hr, OP-50 = 30/hr
- Pre/Post target logic from the source
- Breakdown / Operational Breakdown / MES Bypass status handling
- Shift start at 06:30 IST with UTC query start at 01:00
- Availability calculation from AT_DowntimeData
- General productivity with ideal cycle time = 33 seconds
- General quality = OK / (OK + Rework + Scrap)
- Machining productivity capped at 100%
- Machining quality = OK / (OK + Rework + NOK)
- OEE = Availability × Productivity × Quality
- Acknowledgement persistence using andon_ack.csv
- Original login users/roles

## Important source limitation

The supplied Streamlit source references `templates/index2.html`, but that separate HTML file was not included in the supplied source. The Flask project therefore includes an equivalent Jinja machine card using the same data fields and metrics rather than claiming an exact byte-for-byte conversion of that missing file.

## Run

1. Create venv:
   `python -m venv .venv`
2. Activate it.
3. Install:
   `pip install -r requirements.txt`
4. Copy `.env.example` to `.env` and set the SQL password/secret.
5. Run:
   `python run.py`
6. Open:
   `http://127.0.0.1:5000`

## Original login accounts

The source contains the following usernames/roles and password values. For production, move these to a secure authentication store and change the source credentials.

## ImportError fixed

`routes.py` imports `get_machine` from `app.services.dashboard_service`, and `dashboard_service.py` now defines:

`get_machine(section, machine_code)`

The import was checked together with the route module during the rebuild.

## Database

The app uses the original SQL Server/Apriso table and query names from the supplied source. A working SQL Server ODBC driver is required on the deployment PC.
