import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def test_python_files_compile():
    for p in ROOT.rglob("*.py"):
        ast.parse(p.read_text(encoding="utf-8"), filename=str(p))

def test_dashboard_service_exports_get_machine():
    tree = ast.parse((ROOT / "app/services/dashboard_service.py").read_text(encoding="utf-8"))
    funcs = {n.name for n in tree.body if isinstance(n, ast.FunctionDef)}
    assert "get_machine" in funcs
    assert "get_machines" in funcs

def test_routes_import_targets_exist():
    text = (ROOT / "app/routes.py").read_text(encoding="utf-8")
    assert "get_machine" in text
    assert "get_machines" in text

def test_oee_formula_present():
    text = (ROOT / "app/services/dashboard_service.py").read_text(encoding="utf-8")
    assert "oee = availability * productivity * quality" in text
