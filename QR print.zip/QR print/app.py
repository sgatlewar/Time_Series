from flask import Flask, render_template, request, flash, redirect, url_for
import os
import socket

app = Flask(__name__)
app.secret_key = "your_secret_key_here"  # Replace with a strong key

# Path where PRN file will be saved
BASE_DIR = r"C:\Users\185906\OneDrive - tataautocomp.com\QR print"
LABEL_PRN = os.path.join(BASE_DIR, "label.prn")
FINAL_PRN = os.path.join(BASE_DIR, "final.prn")

PRINTER_IP = "10.103.6.241"   # 🔹 Replace with your Zebra printer IP
PRINTER_PORT = 9100             # 🔹 Default Zebra RAW socket port


@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        text = request.form.get("text", "").strip()

        if not text:
            flash("Please enter text for the QR code.", "error")
            return redirect(url_for("index"))

        try:
            # Split input into two parts around ':'
            if ":" not in text:
                flash("Input must contain ':' to separate two parts.", "error")
                return redirect(url_for("index"))

            sr1, sr2 = text.split(":", 1)

            with open(LABEL_PRN, "r", encoding="utf-8") as f:
                content = f.read()

            # Replace placeholders
            content = (
                content.replace("QR", text)
                       .replace("data1", sr1)
                       .replace("data2", sr2)
            )

            # Save to final.prn`
            os.makedirs(BASE_DIR, exist_ok=True)
            with open(FINAL_PRN, "w", encoding="utf-8") as f:
                f.write(content)
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as printer:
                    printer.connect((PRINTER_IP, PRINTER_PORT))
                    printer.sendall(content.encode('utf-8'))
                flash(f"✅ Label sent to printer ({PRINTER_IP}) successfully!", "success")
                flash(f"✅ final.prn file created successfully at: {FINAL_PRN}", "success")
            except Exception as e:
                flash(f"⚠️ Error sending data to printer: {e}", "error")

        except Exception as e:
            flash(f"❌ Error generating label: {e}", "error")

        return redirect(url_for("index"))

    return render_template("index.html")

            
               


if __name__ == "__main__":
    app.run(host="10.103.4.130", port=5000, debug=True)
