from PIL import Image, ImageDraw, ImageFont
import qrcode
import io
import base64

# Data for QR code
qr_data = "MMJ97IN552525001AA,13G1-1XN1Y25,,,7,2525,,"

# Generate QR code
qr = qrcode.QRCode(
    version=4,  # controls size (adjust as needed)
    error_correction=qrcode.constants.ERROR_CORRECT_H,  # high error correction allows center masking
    box_size=10,
    border=4,
)
qr.add_data(qr_data)
qr.make(fit=True)
img_qr = qr.make_image(fill_color="black", back_color="white").convert('RGBA')

# Size of QR image
width, height = img_qr.size

# Create drawing context
draw = ImageDraw.Draw(img_qr)

# Calculate center circle radius and position for "quiet zone"
circle_radius = width // 12  # adjust as needed for clear center
center_x, center_y = width // 2, height // 2

# Draw white circle in center to clear QR modules underneath
draw.ellipse(
    (center_x - circle_radius, center_y - circle_radius, center_x + circle_radius, center_y + circle_radius),
    fill="white"
)

# Add overlay text "PEGA" centered
font_size = circle_radius // 2  # text font size ~ circle radius
try:
    # Load a TTF font (adjust path or use default)
    font = ImageFont.truetype("arial.ttf", font_size)
except IOError:
    font = ImageFont.load_default()

text = "PEGA"
# Calculate text size using getbbox (Pillow 10+)
bbox = font.getbbox(text)
text_width = bbox[2] - bbox[0]
text_height = bbox[3] - bbox[1]

# Center text over the white circle
text_x = center_x - text_width // 2
text_y = center_y - text_height // 2


# Draw text in black on white circle
draw.text((text_x, text_y), text, fill="black", font=font)

# Save image for preview
img_qr.save("qr_pega_overlay.png")

# Convert image to monochrome (black and white) for ZPL
img_mono = img_qr.convert('1')

# Convert to ZPL ASCII Hex format
def img_to_zpl(img):
    """
    Convert PIL Image to ZPL ASCII Hex format with ^GFA command
    """
    width = img.width
    height = img.height

    # Convert image to bytes (1 bit per pixel)
    img_bytes = img.tobytes()

    # Calculate bytes per row (1 byte = 8 pixels)
    bytes_per_row = (width + 7) // 8

    total_bytes = bytes_per_row * height

    # ZPL requires the data to be ASCII hex encoded
    hexdata = img.tobytes().hex().upper()

    # Format ^GFA command: ^GFA,total_bytes,bytes_per_row,total_bytes,hexdata
    zpl = f"^GFA,{total_bytes},{total_bytes},{bytes_per_row},{hexdata}"

    return zpl

zpl_data = img_to_zpl(img_mono)

# Wrap in ^XA and ^XZ
zpl_label = f"""
^XA
^FO50,50
{zpl_data}^FS
^XZ
"""

# Save ZPL to file
with open("qr_pega_overlay.zpl", "w") as f:
    f.write(zpl_label)

print("ZPL code generated and saved to qr_pega_overlay.zpl")
