import streamlit as st
import pyodbc
from datetime import datetime
import streamlit.components.v1 as components
import base64
import pandas as pd
import os
from streamlit_autorefresh import st_autorefresh
import plotly.graph_objects as go
import time



st.set_page_config(
    page_title="TIU Andon Dashboard",
    layout="wide",
    initial_sidebar_state="collapsed"
)

st.markdown("""
<style>

/* Sidebar expand/collapse button */

button[kind="header"]{

    background: #FFFFFF !important;

    border-radius: 10px !important;

    border: 2px solid #FF8C00 !important;
}

/* Arrow icon */

button[kind="header"] svg{

    color: #FF8C00 !important;

    width: 24px !important;

    height: 24px !important;
}

/* Hover */

button[kind="header"]:hover{

    background: #FFF3E0 !important;
}

</style>
""", unsafe_allow_html=True)

st.markdown("""
<style>

/* Sidebar Selectbox Label */

section[data-testid="stSidebar"] .stSelectbox label p{

    color:white !important;

    font-size:25px !important;

    font-weight:700 !important;
}

/* Selectbox Container */

section[data-testid="stSidebar"] div[data-baseweb="select"]{

    background:#0B2D6B !important;

    border:1px solid rgba(255,255,255,0.20) !important;

    border-radius:12px !important;
}

/* Selected Value */

section[data-testid="stSidebar"] div[data-baseweb="select"] span{

    color:white !important;

    font-size:25px !important;

    font-weight:600 !important;
}

/* Dropdown Box */

section[data-testid="stSidebar"] div[data-baseweb="select"] > div{

    background:#0B2D6B !important;

    border-radius:18px !important;

    min-height:50px !important;
}

/* Dropdown Arrow */

section[data-testid="stSidebar"] div[data-baseweb="select"] svg{

    fill:white !important;
}

/* Checkbox Label */

section[data-testid="stSidebar"] .stCheckbox label p{

    color:white !important;

    font-weight:600 !important;
}

/* Radio Label */

section[data-testid="stSidebar"] .stRadio label{

    color:white !important;

    font-weight:600 !important;
}

</style>
""", unsafe_allow_html=True)

st.markdown("""
<style>

/* Sidebar Background */

section[data-testid="stSidebar"]{
    background: linear-gradient(
        180deg,
        #00133D 0%,
        #002A6B 100%
    ) !important;
}

/* Sidebar Title */

.sidebar-title{
    text-align:center;
    font-size:50px;
    font-weight:800;
    color:white;
    margin-top:10px;
    margin-bottom:20px;
    letter-spacing:1px;
}

/* User Card */

.user-card{

    background: rgba(255,255,255,0.10);

    border:1px solid rgba(255,255,255,0.15);

    border-radius:30px;

    padding:15px;

    margin-bottom:30px;

    color:white;

    font-size:40px;

    box-shadow:0 4px 12px rgba(0,0,0,0.25);
}

/* Sidebar Buttons */

section[data-testid="stSidebar"] .stButton > button{

    background: linear-gradient(
        135deg,
        #0B3FA5,
        #1C6DD0
    ) !important;

    color:white !important;

    height:55px !important;

    border:none !important;

    border-radius:12px !important;

    font-size:18px !important;

    font-weight:700 !important;

    margin-bottom:8px !important;

    box-shadow:0px 4px 10px rgba(0,0,0,0.30) !important;

    transition:all 0.3s ease !important;
}

/* Hover */

section[data-testid="stSidebar"] .stButton > button:hover{

    background: linear-gradient(
        135deg,
        #FF8C00,
        #FFB347
    ) !important;

    transform:translateY(-2px) !important;

    color:white !important;
}

/* Button Text */

section[data-testid="stSidebar"] .stButton > button p{

    font-size:35px !important;

    font-weight:700 !important;

    color:white !important;

    text-align:center !important;
}

/* Radio Labels */

    section[data-testid="stSidebar"] label,
    section[data-testid="stSidebar"] .stRadio label p{

    color:white !important;

    font-size:25px !important;

    font-weight:600 !important;
}

/* Checkbox */

section[data-testid="stSidebar"] .stCheckbox label p{

    color:white !important;

    font-size:25px !important;

    font-weight:600 !important;
}

/* Horizontal Divider */

section[data-testid="stSidebar"] hr{
    border-color:rgba(255,255,255,0.20) !important;
}

</style>
""", unsafe_allow_html=True)

connection_string = (
    "DRIVER={SQL Server};"
    "SERVER=10.105.17.60;"
    "DATABASE=apriso;"
    "UID=FlxReader;"
    "PWD=FlxReader@#123;"
    "Encrypt=no;"
)


rework_queries = {

    "UC01_IP": """
    SELECT ISNULL(SUM(PartQuantity),0)
    FROM AT_Ultrasonic1process
    WHERE CreatedOn BETWEEN ? AND GETDATE()
      AND OutputScan = 1
      AND WipOrderNo LIKE '%R00%'
      AND Parts = 'M4ACN0111M00'
    """,

    "SPFL_IP": """
    SELECT ISNULL(SUM(PartQuantity),0)
    FROM AT_SprayFluxingProcess
    WHERE CreatedOn BETWEEN ? AND GETDATE()
      AND OutputScan = 1
      AND WipOrderNo LIKE '%R00%'
      AND Parts = 'M4ACN0111M00'
    """,

    "LW01": """
    SELECT ISNULL(COUNT(*),0)
    FROM AT_LaserWeldingPLCData
    WHERE CreatedOn BETWEEN ? AND GETDATE()
      AND WipOrderNo LIKE '%R00%'
    """,

    "LW02": """
    SELECT ISNULL(COUNT(*),0)
    FROM AT_LaserWeldingPLCData
    WHERE CreatedOn BETWEEN ? AND GETDATE()
      AND WipOrderNo LIKE '%R00%'
    """,

    "LW03": """
    SELECT ISNULL(COUNT(*),0)
    FROM AT_LaserWeldingPLCData
    WHERE CreatedOn BETWEEN ? AND GETDATE()
      AND WipOrderNo LIKE '%R00%'
    """,

    "CLNC": """
    SELECT ISNULL(SUM(PartQuantity),0)
    FROM AT_Clinchingprocess
    WHERE CreatedOn BETWEEN ? AND GETDATE()
      AND OutputScan = 1
      AND Active = 1
      AND WipOrderNo LIKE '%R00%'
    """,

    "RSHP": """
    SELECT ISNULL(SUM(PartQuantity),0)
    FROM AT_Reshapingprocess
    WHERE CreatedOn BETWEEN ? AND GETDATE()
      AND OutputScan = 1
      AND WipOrderNo LIKE '%R00%'
    """,

    "SHBL": """
    SELECT ISNULL(SUM(PartQuantity),0)
    FROM AT_ShotBlastingprocess
    WHERE CreatedOn BETWEEN ? AND GETDATE()
      AND OutputScan = 1
      AND WipOrderNo LIKE '%R00%'
    """,

    "ALT1_01": """
    SELECT ISNULL(SUM(PartQuantity),0)
    FROM AT_ALT1_Process
    WHERE CreatedOn BETWEEN ? AND GETDATE()
      AND OutputScan = 1
      AND IsRejected = 0
      AND Active = 1
      AND WipOrderNo LIKE '%R00%'
    """,

    "BRZN_FX": """
    SELECT ISNULL(SUM(PartQuantity),0)
    FROM AT_BrazingProcess
    WHERE CreatedOn BETWEEN ? AND GETDATE()
      AND OutputScan = 1
      AND Active = 1
      AND WipOrderNo LIKE '%R00%'
    """,

    "QALT": """
    SELECT ISNULL(COUNT(*),0)
    FROM AT_QUALITY_SAMPLE
    WHERE WorkCenter LIKE 'ALT1%'
      AND Status = 'Rework'
      AND CreatedOn BETWEEN ? AND GETDATE()
    """
}


scrap_queries = {
    "QALT": """
    SELECT ISNULL(COUNT(*),0)
    FROM AT_QUALITY_SAMPLE
    WHERE WorkCenter LIKE 'ALT1%'
      AND Status = 'Scrap'
      AND CreatedOn BETWEEN ? AND GETDATE()
    """
}


hourly_nok_queries = {

    "QALT": """
    SELECT
        DATEPART(HOUR, cp.CreatedOn) AS Hr,
        ISNULL(COUNT(cp.Quantity),0) AS Qty
    FROM AT_QUALITY_SAMPLE cp
    WHERE WorkCenter LIKE 'ALT1%'
      AND Status IN ('Scrap','Rework')
      AND cp.CreatedOn BETWEEN ? AND GETDATE()
    GROUP BY DATEPART(HOUR, cp.CreatedOn)
    ORDER BY Hr
    """
}

hourly_queries = {

    "UC01_IP": """
        SELECT
            DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn)) AS Hr,
            ISNULL(SUM(PartQuantity),0) AS Qty
        FROM AT_Ultrasonic1process
        WHERE CreatedOn BETWEEN ? AND GETDATE()
          AND OutputScan = 1
          AND Parts = 'M4ACN0111M00'
        GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn))
        ORDER BY Hr
    """,

    "SPFL_IP": """
        SELECT
            DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn)) AS Hr,
            ISNULL(SUM(PartQuantity),0) AS Qty
        FROM AT_SprayFluxingProcess
        WHERE CreatedOn BETWEEN ? AND GETDATE()
          AND OutputScan = 1
          AND UndoFlag = 0
          AND Parts = 'M4ACN0111M00'
        GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn))
        ORDER BY Hr
    """,

    "LW01": """
        ;WITH EquipMap AS (
            SELECT W.WorkCenter,
                   UC.Attribute_ AS EquipmentName
            FROM WORK_CENTER W
            JOIN UNIT_CHARACTERISTIC UC
                ON UC.UnitID = W.UnitID
               AND UC.Characteristic = 'OutputStation'
            WHERE W.WorkCenter IN ('LW01')
        )

        SELECT
            DATEPART(HOUR, DATEADD(MINUTE,330,cp.CreatedOn)) AS Hr,
            ISNULL(SUM(1),0) AS Qty
        FROM AT_LaserWeldingPLCData cp
        JOIN EQUIPMENT E
            ON E.ID = cp.EquipmentID
        JOIN EquipMap em
            ON em.WorkCenter = 'LW01'
           AND E.Equipment = em.EquipmentName
        WHERE cp.CreatedOn BETWEEN ? AND GETDATE()
        GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,cp.CreatedOn))
        ORDER BY Hr
    """,
    "QLW01": """
;WITH EquipMap AS (
    SELECT W.WorkCenter,
           UC.Attribute_ AS EquipmentName
    FROM WORK_CENTER W
    JOIN UNIT_CHARACTERISTIC UC
        ON UC.UnitID = W.UnitID
       AND UC.Characteristic = 'OutputStation'
    WHERE W.WorkCenter = 'LW01'
)
SELECT
    DATEPART(HOUR, DATEADD(MINUTE,330,cp.CreatedOn)) AS Hr,
    COUNT(*) AS Qty
FROM AT_LaserWeldingPLCData cp
JOIN EQUIPMENT E
    ON E.ID = cp.EquipmentID
JOIN EquipMap em
    ON em.WorkCenter = 'LW01'
   AND E.Equipment = em.EquipmentName
WHERE cp.CreatedOn BETWEEN ? AND GETDATE()
GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,cp.CreatedOn))
ORDER BY Hr
""",


    "LW02": """
        ;WITH EquipMap AS (
            SELECT W.WorkCenter,
                   UC.Attribute_ AS EquipmentName
            FROM WORK_CENTER W
            JOIN UNIT_CHARACTERISTIC UC
                ON UC.UnitID = W.UnitID
               AND UC.Characteristic = 'OutputStation'
            WHERE W.WorkCenter IN ('LW02')
        )

        SELECT
            DATEPART(HOUR, DATEADD(MINUTE,330,cp.CreatedOn)) AS Hr,
            ISNULL(SUM(1),0) AS Qty
        FROM AT_LaserWeldingPLCData cp
        JOIN EQUIPMENT E
            ON E.ID = cp.EquipmentID
        JOIN EquipMap em
            ON em.WorkCenter = 'LW02'
           AND E.Equipment = em.EquipmentName
        WHERE cp.CreatedOn BETWEEN ? AND GETDATE()
        GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,cp.CreatedOn))
        ORDER BY Hr
    """,
    "QLW02": """
;WITH EquipMap AS (
    SELECT W.WorkCenter,
           UC.Attribute_ AS EquipmentName
    FROM WORK_CENTER W
    JOIN UNIT_CHARACTERISTIC UC
        ON UC.UnitID = W.UnitID
       AND UC.Characteristic = 'OutputStation'
    WHERE W.WorkCenter = 'LW02'
)
SELECT
    DATEPART(HOUR, DATEADD(MINUTE,330,cp.CreatedOn)) AS Hr,
    COUNT(*) AS Qty
FROM AT_LaserWeldingPLCData cp
JOIN EQUIPMENT E
    ON E.ID = cp.EquipmentID
JOIN EquipMap em
    ON em.WorkCenter = 'LW02'
   AND E.Equipment = em.EquipmentName
WHERE cp.CreatedOn BETWEEN ? AND GETDATE()
GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,cp.CreatedOn))
ORDER BY Hr
""",

    

    "LW03": """
        ;WITH EquipMap AS (
            SELECT W.WorkCenter,
                   UC.Attribute_ AS EquipmentName
            FROM WORK_CENTER W
            JOIN UNIT_CHARACTERISTIC UC
                ON UC.UnitID = W.UnitID
               AND UC.Characteristic = 'OutputStation'
            WHERE W.WorkCenter IN ('LW03')
        )

        SELECT
            DATEPART(HOUR, DATEADD(MINUTE,330,cp.CreatedOn)) AS Hr,
            ISNULL(SUM(1),0) AS Qty
        FROM AT_LaserWeldingPLCData cp
        JOIN EQUIPMENT E
            ON E.ID = cp.EquipmentID
        JOIN EquipMap em
            ON em.WorkCenter = 'LW03'
           AND E.Equipment = em.EquipmentName
        WHERE cp.CreatedOn BETWEEN ? AND GETDATE()
        GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,cp.CreatedOn))
        ORDER BY Hr
    """,

    "QLW03": """
SELECT
DATEPART(HOUR, DATEADD(MINUTE,330,D.CreatedOn)) AS Hr,
ISNULL(SUM(D.Quantity),0) AS Qty
FROM DISPOSITION D
WHERE D.OprSequenceNo = 15
AND D.Status IN (14,4)
AND D.CreatedOn BETWEEN ? AND GETDATE()
GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,D.CreatedOn))
ORDER BY Hr
""",
    "CLNC": """
        SELECT
            DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn)) AS Hr,
            ISNULL(SUM(PartQuantity),0) AS Qty
        FROM AT_Clinchingprocess
        WHERE CreatedOn BETWEEN ? AND GETDATE()
          AND OutputScan = 1
          AND Active = 1
        GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn))
        ORDER BY Hr
    """,

    "RSHP": """
        SELECT
            DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn)) AS Hr,
            ISNULL(SUM(PartQuantity),0) AS Qty
        FROM AT_Reshapingprocess
        WHERE CreatedOn BETWEEN ? AND GETDATE()
          AND OutputScan = 1
        GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn))
        ORDER BY Hr
    """,

    "SHBL": """
        SELECT
            DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn)) AS Hr,
            ISNULL(SUM(PartQuantity),0) AS Qty
        FROM AT_ShotBlastingprocess
        WHERE CreatedOn BETWEEN ? AND GETDATE()
          AND OutputScan = 1
        GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn))
        ORDER BY Hr
    """,

    "ALT1_01": """
        SELECT
            DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn)) AS Hr,
            ISNULL(SUM(PartQuantity),0) AS Qty
        FROM AT_ALT1_Process
        WHERE CreatedOn BETWEEN ? AND GETDATE()
          AND OutputScan = 1
          AND IsRejected = 0
          AND Active = 1
        GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn))
        ORDER BY Hr
    """,

    "BRZN_FX": """
        SELECT
            DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn)) AS Hr,
            ISNULL(SUM(PartQuantity),0) AS Qty
        FROM AT_BrazingProcess
        WHERE CreatedOn BETWEEN ? AND GETDATE()
          AND OutputScan = 1
          AND Active = 1
        GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn))
        ORDER BY Hr
    """,
    
    "QALT": """
SELECT
    DATEPART(HOUR, DATEADD(MINUTE,330,cp.CreatedOn)) AS Hr,
    ISNULL(COUNT(cp.Quantity),0) AS Qty
FROM AT_QUALITY_SAMPLE cp
WHERE WorkCenter LIKE 'ALT1%'
  AND Status = 'QAOK'
  AND cp.CreatedOn BETWEEN ? AND GETDATE()
GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,cp.CreatedOn))
ORDER BY Hr
"""
}

machine_display = {
    "UC01_IP": "Ultrasonic Cleaning 01",
    "SPFL_IP": "Spray Fluxing",
    "LW01": "Laser Welding 01",
    "QLW01": "LW01 Q-Gate",
    "CLNC": "Clinching",
    "LW02": "Laser Welding 02",
    "QLW02": "LW02 Q-Gate",
    "LW03": "Laser Welding 03",
    "QLW03": "LW03 Q-Gate",
    "BRZN_FX": "Brazing",
    "SHBL": "Shot Blasting",
    "RSHP": "Restriking",
    "ALT1_01": "Air Leak Testing 01",
    "QALT": "Q-Gate ALT1"

}

machining_display = {

    **{
        f"OP_10_{i:02d}": f"OP-10_{i:02d}"
        for i in range(2, 7)
    },

    **{
        f"OP_20_{i:02d}": f"OP-20_{i:02d}"
        for i in range(2, 7)
    },

    **{
        f"OP_30_{i:02d}": f"OP-30_{i:02d}"
        for i in range(1, 18)
    },

    **{
        f"OP_40_{i:02d}": f"OP-40_{i:02d}"
        for i in range(1, 18)
    },

    **{
        f"OP_50_{i:02d}": f"OP-50_{i:02d}"
        for i in range(1, 4)
    }
    
}

post_machining_queries = {

    "SG": """
    SELECT ISNULL(COUNT(cp.PartQuantity),0)
    FROM AT_ColdPlateLoadingProcess cp
    WHERE cp.Active = 1
      AND cp.OutputScan = 1
      AND LEN(ISNULL(cp.SerialNo,'')) > 0
      AND ISNULL(cp.IsRejected,0) <> 1
      AND cp.CreatedOn BETWEEN ? AND GETDATE()
    """,

    "UC2": """
    SELECT ISNULL(COUNT(cp.PartQuantity),0)
    FROM AT_Ultrasonic2process cp
    WHERE cp.Active = 1
      AND LEN(ISNULL(cp.SerialNo,'')) > 0
      AND ISNULL(cp.IsRejected,0) <> 1
      AND cp.CreatedOn BETWEEN ? AND GETDATE()
    """,

    "EOL": """
    SELECT ISNULL(COUNT(DISTINCT(cp.SerialNumber)),0)
    FROM AT_TestingLineProcess cp
    WHERE cp.Active = 1
      AND LEN(ISNULL(cp.SerialNumber,'')) > 0
      AND LEN(ISNULL(cp.LM2SerialNumber,'')) > 0
      AND LEN(ISNULL(cp.WipOrderNo,'')) > 0
      AND cp.CreatedOn BETWEEN ? AND GETDATE()
    """,

    "PACK": """
    SELECT ISNULL(COUNT(cp.ID),0)
    FROM AT_PackagingProcess cp
    WHERE cp.SerialLabelStatus = 1
      AND cp.Active = 1
      AND cp.CreatedOn BETWEEN ? AND GETDATE()
    """
}

post_machining_nok_queries = {

    "SG": """
    SELECT ISNULL(COUNT(*),0)
    FROM AT_ColdPlateLoadingProcess
    WHERE Active = 1
      AND OutputScan = 1
      AND IsRejected = 1
      AND CreatedOn BETWEEN ? AND GETDATE()
    """,

    "UC2": """
    SELECT ISNULL(COUNT(*),0)
    FROM AT_Ultrasonic2Process
    WHERE Active = 1
      AND IsRejected = 1
      AND CreatedOn BETWEEN ? AND GETDATE()
    """,

    "EOL": """
    SELECT ISNULL(COUNT(*),0)
    FROM AT_TestingLineProcess
    WHERE Active = 1
      AND IsRejection = 1
      AND CreatedOn BETWEEN ? AND GETDATE()
    """,

    "PACK": """
    SELECT ISNULL(COUNT(*),0)
    FROM AT_PackagingProcess
    WHERE Active = 1
      AND IsRejection = 1
      AND CreatedOn BETWEEN ? AND GETDATE()
    """
}

post_machining_wc = {
    "SG": "SG",
    "UC2": "UC02",
    "EOL": "EOL",
    "PACK": "PACK"
}


post_machining_rework_queries = {

    "SG": """
    SELECT ISNULL(COUNT(cp.PartQuantity),0)
    FROM AT_ColdPlateLoadingProcess cp
    WHERE cp.Active = 1
      AND cp.OutputScan = 1
      AND LEN(ISNULL(cp.SerialNo,'')) > 0
      AND cp.WipOrderNo LIKE '%R00%'
      AND cp.CreatedOn BETWEEN ? AND GETDATE()
    """,

    "UC2": """
    SELECT ISNULL(COUNT(cp.PartQuantity),0)
    FROM AT_Ultrasonic2process cp
    WHERE cp.Active = 1
      AND LEN(ISNULL(cp.SerialNo,'')) > 0
      AND cp.WipOrderNo LIKE '%R00%'
      AND cp.CreatedOn BETWEEN ? AND GETDATE()
    """,

    "EOL": """
    SELECT ISNULL(COUNT(DISTINCT(cp.SerialNumber)),0)
    FROM AT_TestingLineProcess cp
    WHERE cp.Active = 1
      AND LEN(ISNULL(cp.SerialNumber,'')) > 0
      AND LEN(ISNULL(cp.LM2SerialNumber,'')) > 0
      AND LEN(ISNULL(cp.WipOrderNo,'')) > 0
      AND cp.WipOrderNo LIKE '%R00%'
      AND cp.CreatedOn BETWEEN ? AND GETDATE()
    """,

    "PACK": """
    SELECT ISNULL(COUNT(cp.ID),0)
    FROM AT_PackagingProcess cp
    WHERE cp.SerialLabelStatus = 1
      AND cp.Active = 1
      AND cp.WipOrderNo LIKE '%R00%'
      AND cp.CreatedOn BETWEEN ? AND GETDATE()
    """
}

post_machining_display = {
    "SG": "Soldering and Glueing",
    "UC2": "Ultrasonic Cleaning 02",
    "EOL": "End of Line Testing",
    "PACK": "Packaging"
}


targets = {
    "UC01_IP": 100,
    "SPFL_IP": 100,
    "LW01": 100,
    "CLNC": 100,
    "LW02": 100,
    "LW03": 100,
    "SHBL": 100,
    "RSHP": 100,
    "ALT1_01":100,
    "BRZN_FX":100,
    "QLW01": 100,
    "QLW02": 100,
    "QLW03": 100,
    "QALT": 100
    
    }
    
post_targets = {
    "SG": 100,
    "UC2": 100,
    "EOL": 100,
    "PACK": 100
}

graph_labels = {
    "UC01_IP": "UC1",
    "SPFL_IP": "SF",
    "LW01": "LW1",
    "CLNC": "CLNC",
    "LW02": "LW2",
    "LW03": "LW3",
    "SHBL": "SB",
    "RSHP": "REST",
    "ALT1_01": "ALT1",
    "BRZN_FX": "BRAZ",
    "QLW01": "QLW1",
    "QLW02": "QLW2",
    "QLW03": "QLW3",
    "QALT": "QALT"
}

machine_queries = {

    "UC01_IP": """
        SELECT ISNULL(SUM(PartQuantity),0)
        FROM AT_Ultrasonic1process
        WHERE CreatedOn BETWEEN ? AND GETDATE()
          AND OutputScan = 1
          AND Parts = 'M4ACN0111M00'
    """,

    "SPFL_IP": """
        SELECT ISNULL(SUM(PartQuantity),0)
        FROM AT_SprayFluxingProcess
        WHERE CreatedOn BETWEEN ? AND GETDATE()
          AND OutputScan = 1
          AND UndoFlag = 0
          AND Parts = 'M4ACN0111M00'
    """,

    "LW01": """
        ;WITH EquipMap AS (
SELECT W.WorkCenter, UC.Attribute_ AS EquipmentName
FROM WORK_CENTER W
JOIN UNIT_CHARACTERISTIC UC
ON UC.UnitID = W.UnitID
AND UC.Characteristic = 'OutputStation'
WHERE W.WorkCenter IN ('LW01')
)

SELECT  isnull(sum(1),0)
FROM AT_LaserWeldingPLCData cp
JOIN EQUIPMENT E ON E.ID = cp.EquipmentID
JOIN EquipMap em ON em.WorkCenter = 'LW01' AND E.Equipment = em.EquipmentName
WHERE cp.CreatedOn BETWEEN ? AND GETDATE()
    """,
    
    "RSHP": """
        SELECT ISNULL(SUM(PartQuantity),0)
            FROM AT_Reshapingprocess
            WHERE CreatedOn BETWEEN ? AND GETDATE()
            AND OutputScan = 1
    """,
    
    "CLNC":"""
        select ISNULL(sum(PartQuantity),0)
            from AT_Clinchingprocess
            where CreatedOn between ? and GETDATE()
            And outputscan = 1 and active = 1
    """,

    "LW03":"""
        ;WITH EquipMap AS (
SELECT W.WorkCenter, UC.Attribute_ AS EquipmentName
FROM WORK_CENTER W
JOIN UNIT_CHARACTERISTIC UC
ON UC.UnitID = W.UnitID
AND UC.Characteristic = 'OutputStation'
WHERE W.WorkCenter IN ('LW03')
)

SELECT  isnull(sum(1),0)
FROM AT_LaserWeldingPLCData cp
JOIN EQUIPMENT E ON E.ID = cp.EquipmentID
JOIN EquipMap em ON em.WorkCenter = 'LW03' AND E.Equipment = em.EquipmentName
WHERE cp.CreatedOn BETWEEN ? AND GETDATE()
    
    """,

    "LW02":"""
        ;WITH EquipMap AS (
SELECT W.WorkCenter, UC.Attribute_ AS EquipmentName
FROM WORK_CENTER W
JOIN UNIT_CHARACTERISTIC UC
ON UC.UnitID = W.UnitID
AND UC.Characteristic = 'OutputStation'
WHERE W.WorkCenter IN ('LW02')
)

SELECT  isnull(sum(1),0)
FROM AT_LaserWeldingPLCData cp
JOIN EQUIPMENT E ON E.ID = cp.EquipmentID
JOIN EquipMap em ON em.WorkCenter = 'LW02' AND E.Equipment = em.EquipmentName
WHERE cp.CreatedOn BETWEEN ? AND GETDATE()
    """,

    "SHBL":"""
        select isnull(sum(partQuantity),0) from AT_ShotBlastingprocess where createdon between ? and GETDATE() and OutputScan = 1
    """,

    "ALT1_01":"""
        select isnull(sum(partQuantity),0) from AT_ALT1_Process where createdon between ? and GETDATE() and OutputScan = 1 and IsRejected = 0 and Active = 1

    """,
    "BRZN_FX":"""
    select isnull(sum(PartQuantity),0) from AT_BrazingProcess where createdon between ? and GETDATE() and OutputScan = 1 and Active = 1
    """,
    
    "QLW01": """
;WITH EquipMap AS (
    SELECT W.WorkCenter,
           UC.Attribute_ AS EquipmentName
    FROM WORK_CENTER W
    JOIN UNIT_CHARACTERISTIC UC
        ON UC.UnitID = W.UnitID
       AND UC.Characteristic = 'OutputStation'
    WHERE W.WorkCenter = 'LW01'
)
SELECT ISNULL((
    SELECT COUNT(*)
    FROM AT_LaserWeldingPLCData cp
    JOIN EQUIPMENT E
        ON E.ID = cp.EquipmentID
    JOIN EquipMap em
        ON em.WorkCenter = 'LW01'
       AND E.Equipment = em.EquipmentName
    WHERE cp.CreatedOn BETWEEN ? AND GETDATE()
),0)
""",
    
    "QLW02": """
    ;WITH EquipMap AS (
        SELECT W.WorkCenter,
               UC.Attribute_ AS EquipmentName
        FROM WORK_CENTER W
        JOIN UNIT_CHARACTERISTIC UC
            ON UC.UnitID = W.UnitID
           AND UC.Characteristic = 'OutputStation'
        WHERE W.WorkCenter = 'LW02'
    )
    SELECT ISNULL((
        SELECT COUNT(*)
        FROM AT_LaserWeldingPLCData cp
        JOIN EQUIPMENT E
            ON E.ID = cp.EquipmentID
        JOIN EquipMap em
            ON em.WorkCenter = 'LW02'
           AND E.Equipment = em.EquipmentName
        WHERE cp.CreatedOn BETWEEN ? AND GETDATE()
    ),0)
    """,
    
    "QLW03": """
    SELECT SUM(D.Quantity)
    FROM DISPOSITION D
    WHERE D.OprSequenceNo = 15
    AND D.Status IN (14,4)
    AND D.CreatedOn BETWEEN ? AND GETDATE()
    """,

    "QALT": """
    SELECT ISNULL(COUNT(cp.Quantity),0)
    FROM AT_QUALITY_SAMPLE cp
    WHERE WorkCenter LIKE 'ALT1%'
      AND Status = 'QAOK'
      AND cp.CreatedOn BETWEEN ? AND GETDATE()
    """

}


if "logged_in" not in st.session_state:
    st.session_state.logged_in = False

if "role" not in st.session_state:
    st.session_state.role = ""

if "username" not in st.session_state:
    st.session_state.username = ""

if "ack_mode" not in st.session_state:
    st.session_state.ack_mode = {}

if "view_mode" not in st.session_state:
    st.session_state.view_mode = "TILES"

if "last_switch" not in st.session_state:
    st.session_state.last_switch = time.time()
    
if "auto_rotate" not in st.session_state:
    st.session_state.auto_rotate = False

if "plant_section" not in st.session_state:
    st.session_state.plant_section = None
    
if "machining_page" not in st.session_state:
    st.session_state.machining_page = None


USERS = {
    "Premachining": {
        "password": "123",
        "role": "L1"
    },
    "Machining": {
        "password": "123",
        "role": "L1"
    },
    "Postmachining": {
        "password": "123",
        "role": "L1"
    },
    "Shubham": {
        "password": "123",
        "role": "L2"
    }
}



@st.cache_data(ttl=30)
def load_downtime_data():
    conn = get_connection()
    cursor = conn.cursor()

    shift_start = datetime.strptime(
        datetime.now().strftime("%Y-%m-%d") + " 01:00:00",
        "%Y-%m-%d %H:%M:%S"
    )

    query = """
    SELECT
        WorkCenter,
        DATEADD(MINUTE, 330, DowntimeStartTime) as DowntimeStartTime_ist,
        DATEADD(MINUTE, 330, DowntimeEndTime) as DowntimeEndTime_ist,
        DATEADD(MINUTE, 330, LastUpdateOn) as LastUpdateOn_ist,
        Type
    FROM AT_DowntimeData
    WHERE DowntimeStartTime >= ?
    """

    cursor.execute(query, shift_start)

    rows = cursor.fetchall()

    df = pd.DataFrame.from_records(
        rows,
        columns=[col[0] for col in cursor.description]
    )

    cursor.close()
    conn.close()

    return df

@st.cache_resource
def get_tile_template():
    with open(
        "templates/index2.html",
        "r",
        encoding="utf-8"
    ) as f:
        return f.read()

def login():

    st.markdown("""
    <style>

    .login-wrapper{
        display:flex;
        justify-content:center;
        margin-top:50px;
    }

    .login-card{
        background:white;
        padding:30px;
        border-radius:20px;
        box-shadow:0px 5px 20px rgba(0,0,0,0.15);
        width:500px;
        text-align:center;
    }

    .login-title{
        font-size:60px;
        font-weight:bold;
        color:#2D3142;
        margin-bottom:10px;
    }

    .login-subtitle{
        font-size:28px;
        color:#18407A;
        margin-bottom:30px;
    }

    </style>
    """, unsafe_allow_html=True)

    left, center, right = st.columns([2, 3, 2])

    with center:

        with st.container(border=True):

            st.image(
                r"C:\Andon\logo.jpg",
                width=300
            )

            st.markdown(
                """
                <div class='login-title'>
                    TIU ANDON
                </div>
                """,
                unsafe_allow_html=True
            )

            st.markdown(
                """
                <div class='login-subtitle'>
                    Please Login
                </div>
                """,
                unsafe_allow_html=True
            )

            username = st.text_input(
                "Username",
                key="login_user"
            )

            password = st.text_input(
                "Password",
                type="password",
                key="login_pwd"
            )

            login_btn = st.button(
                "Login",
                use_container_width=True
            )

            if login_btn:

                if (
                    username in USERS and
                    USERS[username]["password"] == password
                ):

                    st.session_state.logged_in = True
                    st.session_state.username = username
                    st.session_state.role = USERS[username]["role"]
                    #print("logged in")

                    st.rerun()

                else:
                    st.error(
                        "Invalid Username or Password"
                    )


if not st.session_state.get("logged_in", False):
    st.markdown("""
    <style>

    .block-container{
        padding-top: 3rem;
        max-width: 1000px;
    }

    </style>
    """, unsafe_allow_html=True)
    login()
    st.stop()

def get_machining_target(machine):

    workcenter = machine.replace("OP_", "OP-")

    # VMC1
    if workcenter.startswith(("OP-10", "OP-20")):
        return 20
    # VMC2
    elif workcenter.startswith("OP-30"):
        return 4

    elif workcenter.startswith("OP-40"):
        return 4

    elif workcenter.startswith("OP-50"):
        return 30

    return 0

def auto_rotate_controller():

    if not st.session_state.auto_rotate:
        return

    if time.time() - st.session_state.last_switch >= 20:

        views = [
            "TILES"],
            # "PRODUCTION PROGRESS",
            # "HOURLY PRODUCTION"
        # ]

        current_idx = views.index(
            st.session_state.view_mode
        )

        st.session_state.view_mode = views[
            (current_idx + 1) % len(views)
        ]

        st.session_state.last_switch = time.time()

        st.rerun()


#auto_rotate_controller()

def format_status(status):

    status = str(status).strip().upper()

    if "BREAKDOWN" in status:
        return "Breakdown"

    elif "OPERATIONAL_BREAKDOWN" in status:
        return "Operational Breakdown"

    elif "MES BYPASS" in status:
        return "MES Bypass"

    return "Operational"

def save_reason_code(
        machine,
        status,
        reason_code,
        username):

    file_name = "andon_ack.csv"

    new_row = pd.DataFrame([{
        "Machine": machine,
        "Status": status,
        "ReasonCode": reason_code,
        "AcknowledgedBy": username,
        "AcknowledgedOn": datetime.now()
    }])

    if os.path.exists(file_name):

        old_df = pd.read_csv(file_name)

        old_df = old_df[
            old_df["Machine"] != machine
        ]

        df = pd.concat(
            [old_df, new_row],
            ignore_index=True
        )

    else:
        df = new_row

    df.to_csv(
        file_name,
        index=False
    )


def clear_acknowledgement(machine):

    file_name = "andon_ack.csv"

    if not os.path.exists(file_name):
        return

    df = pd.read_csv(file_name)

    df = df[df["Machine"] != machine]

    df.to_csv(file_name, index=False)


def get_connection():
    return pyodbc.connect(connection_string,autocommit=True)

def get_status_details(status):

    status = str(status).upper()

    if "BREAKDOWN" in status:
        return "#D50000", "🔴"

    elif "OPERATIONAL BREAKDOWN" in status:
        return "#FF8C00", "🟠"

    elif "MES BYPASS" in status:
        return "#7B1FA2", "🟣"

    return "#138A36", "🟢"       

def get_elapsed_time(start_time):

    if start_time is None:
        return "00:00:00"

    seconds = int(
        (datetime.now() - start_time).total_seconds()
    )

    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    seconds = seconds % 60

    return f"{hours:02}:{minutes:02}:{seconds:02}"

def get_post_machining_count(query,cursor):



    start_time = datetime.now().strftime(
        "%Y-%m-%d 01:00:00"
    )

    cursor.execute(query, start_time)

    result = cursor.fetchone()

    return int(result[0]) if result and result[0] else 0

def calculate_availability(machine, conn):

    shift_start_utc = datetime.strptime(
        datetime.now().strftime("%Y-%m-%d") + " 01:00:00",
        "%Y-%m-%d %H:%M:%S"
    )

    shift_start_ist = datetime.strptime(
        datetime.now().strftime("%Y-%m-%d") + " 06:30:00",
        "%Y-%m-%d %H:%M:%S"
    )

    planned_minutes = (
        datetime.now() - shift_start_ist
    ).total_seconds() / 60


    query = """
    SELECT
        DATEADD(MINUTE,330,DowntimeStartTime) AS StartTime,
        DATEADD(
            MINUTE,
            330,
            ISNULL(DowntimeEndTime,GETDATE())
        ) AS EndTime
    FROM AT_DowntimeData
    WHERE WorkCenter LIKE ?
    and type = 'BreakDownTime'
      AND DowntimeStartTime >= ?
    """

    cursor = conn.cursor()

    cursor.execute(
        query,
        f"%{machine}%",
        shift_start_utc
    )

    rows = cursor.fetchall()
    #print(rows)

    total_downtime = 0

    for row in rows:

        total_downtime += (
            row.EndTime - row.StartTime
        ).total_seconds() / 60

    runtime_minutes = max(
        planned_minutes - total_downtime,
        0
    )
    
    availability = (runtime_minutes/planned_minutes)
    #print(availability)
    return availability, runtime_minutes

def calculate_productivity(
    ok_count,
    runtime_minutes,
    ideal_time_seconds=33
):

    runtime_seconds = runtime_minutes * 60

    if runtime_seconds <= 0:
        return 0.0

    productivity = (
        ok_count * ideal_time_seconds
    ) / runtime_seconds

    return round(productivity, 4)


def calculate_quality(machine_data):
    """
    Calculate quality percentage.

    Quality = OK / (OK + Rework + Scrap)
    """

    ok_count = machine_data.get("prod_count", 0)
    rework_count = machine_data.get("rework_count", 0)
    scrap_count = machine_data.get("scrap_count", 0)

    total_count = ok_count + rework_count + scrap_count

    if total_count == 0:
        return 0.0

    quality = ok_count / total_count

    return round(quality, 4)


def get_oee(machine_code,prod_count,rework_count,scrap_count,conn):


    availability, runtime_minutes = calculate_availability(
        machine_code,
        conn
    )

    productivity = calculate_productivity(
        prod_count,
        runtime_minutes,
        ideal_time_seconds=33
    )

    total_count = (
        prod_count +
        rework_count +
        scrap_count
    )

    quality = (
        prod_count / total_count
        if total_count > 0
        else 0
    )

    oee = (
        availability *
        productivity *
        quality
    )

    return {
        "availability": round(availability * 100, 2),
        "productivity": round(productivity * 100, 2),
        "quality": round(quality * 100, 2),
        "oee": round(oee * 100, 2)
    }


def get_ok_count(machine_code, machines):
    """
    Return OK count for a machine.
    """

    machine_data = next(
        (m for m in machines if m["machine"] == machine_code),
        None
    )

    return machine_data.get("prod_count", 0) if machine_data else 0


def machine_tile(
    machine,
    status,
    prod_count,
    since,
    runtime,
    reason_alarm,
    target_qty,
    part_count_color,
    ack_by,
    arrow,
    rw_count,
    availability,
    productivity,
    quality,
    oee,
    matrix_value=""
    
):
    ok_color = "#FF0000"      # Red
    nok_color = "#FF0000"     # Red
    rw_color = "#D4A017"      # Dark Yellow
    target_color = "#000000"  # Black
    
    #print(reason_alarm)
    current_datetime = datetime.now().strftime("%d-%b-%Y %H:%M:%S")
    
    color, icon = get_status_details(status)

    if status == "Operational":
        
        count_label = "OK COUNT"
    else:
        #time_label = "DOWN TIME"
        count_label = "OK COUNT"
    
    time_label = "TIME ELAPSED"
    nok_count = 0
    
    html = get_tile_template()

    html = html.replace("{machine}", str(machine))
    html = html.replace("{status}", str(status))
    html = html.replace("{icon}", str(icon))
    html = html.replace("{color}", str(color))
    html = html.replace("{since}", str(since))
    html = html.replace("{runtime}", str(runtime))
    html = html.replace("{prod_count}", str(prod_count))
    html = html.replace("{reason_alarm}", str(reason_alarm))
    html = html.replace("{time_label}", str(time_label))
    html = html.replace("{count_label}", str(count_label))
    html = html.replace("{target_label}", str(target_qty))
    html = html.replace("{current_datetime}",current_datetime)
    html = html.replace("{count_color}",part_count_color)
    html = html.replace("{ack_by}",ack_by)
    html = html.replace("{rw_count}",str(rw_count))
    html = html.replace("{arrow}",arrow)
    html = html.replace("{ok_color}", ok_color)
    html = html.replace("{nok_color}", nok_color)
    html = html.replace("{rw_color}", rw_color)
    html = html.replace("{target_color}", target_color)
    html = html.replace("{nok_count}", str(nok_count))
    html = html.replace("{availability}", str(availability))
    html = html.replace("{productivity}", str(productivity))
    html = html.replace("{quality}", str(quality))
    html = html.replace("{oee}", str(oee))
    html = html.replace("{matrix_value}", str(matrix_value))

            
    

    components.html(
        html,
        height=520,
        scrolling=False
    )


@st.cache_resource
def get_logo():

    with open(
        r"C:\Andon\logo.jpg",
        "rb"
    ) as image_file:

        return base64.b64encode(
            image_file.read()
        ).decode("utf-8")


def get_saved_reason(machine):

    file_name = "andon_ack.csv"

    if not os.path.exists(file_name):
        return None, None

    df = pd.read_csv(file_name)

    result = df[
        df["Machine"] == machine
    ]

    if len(result) > 0:

        reason = result.iloc[-1]["ReasonCode"]

        ack_by = result.iloc[-1]["AcknowledgedBy"]
        

        return reason, ack_by

    return None, None



def color_actual(val, tgt):
    if isinstance(val, (int, float)):

        if val < tgt:
            return "color:red;font-weight:bold;"

        elif val > tgt:
            return "color:green;font-weight:bold;"

    return "color:black;font-weight:bold;"


@st.cache_data(ttl=30)
def get_machining_table(machine):

    workcenter = machine.replace("OP_", "OP-")

    if workcenter.startswith(("OP-10", "OP-20")):
        return "AT_VMC1Process"

    elif workcenter.startswith(("OP-30", "OP-40", "OP-50")):
        return "AT_VMC2Process"

    return None



def get_machining_production_count(machine,cursor):

    workcenter = machine.replace("OP_", "OP-")
    
    table_name = get_machining_table(machine)

    query = f"""
    SELECT ISNULL(COUNT(*),0)
    FROM {table_name}
    WHERE CreatedOn BETWEEN ? AND GETDATE()
      AND WorkCenter LIKE '%{workcenter}%'
      AND OutputScan = 1
      AND Active = 1
      AND IsRejected = 0
    """

    #conn = get_connection()
    #cursor = conn.cursor()

    start_time = datetime.now().strftime(
        "%Y-%m-%d 01:00:00"
    )

    cursor.execute(query, start_time)

    result = cursor.fetchone()

    return result[0] if result and result[0] else 0


def get_machining_rework_count(machine,cursor):

    workcenter = machine.replace("OP_", "OP-")
    
    table_name = get_machining_table(machine)

    query = f"""
    SELECT ISNULL(COUNT(*),0)
    FROM {table_name}
    WHERE CreatedOn BETWEEN ? AND GETDATE()
      AND WorkCenter LIKE '%{workcenter}%'
      AND OutputScan = 1
      AND Active = 1
      AND IsRejected = 1
      AND WipOrderNo LIKE '%R00%'
    """

    

    start_time = datetime.now().strftime(
        "%Y-%m-%d 01:00:00"
    )

    cursor.execute(query, start_time)

    result = cursor.fetchone()

    return result[0] if result and result[0] else 0


def get_machining_nok_count(machine,cursor):

    workcenter = machine.replace("OP_", "OP-")
    
    table_name = get_machining_table(machine)

    query = f"""
    SELECT ISNULL(COUNT(*),0)
    FROM {table_name}
    WHERE CreatedOn BETWEEN ? AND GETDATE()
      AND WorkCenter LIKE '%{workcenter}%'
      AND OutputScan = 1
      AND Active = 1
      AND IsRejected = 1
    """

    start_time = datetime.now().strftime(
        "%Y-%m-%d 01:00:00"
    )

    cursor.execute(query, start_time)

    result = cursor.fetchone()

    return result[0] if result and result[0] else 0

def calculate_machining_productivity(
        machine,
        ok_count,
        runtime_minutes):

    if runtime_minutes <= 0:
        return 0

    target_per_hour = get_machining_target(machine)

    runtime_hours = runtime_minutes / 60

    target_qty = target_per_hour * runtime_hours

    if target_qty <= 0:
        return 0

    productivity = ok_count / target_qty
    
    productivity = min(productivity, 1.0)

    return round(productivity, 4)

def calculate_machining_quality(
        ok_count,
        rework_count,
        nok_count):

    total = ok_count + nok_count+rework_count

    if total == 0:
        return 0

    return round(ok_count / total, 4)



def get_machining_oee(
        machine_code,
        prod_count,
        rework_count,
        nok_count,
        conn):

    availability, runtime_minutes = \
        calculate_availability(
            machine_code,
            conn
        )

    productivity = \
        calculate_machining_productivity(
            machine_code,
            prod_count,
            runtime_minutes
        )

    quality = calculate_machining_quality(
            prod_count,
            rework_count,
            nok_count
        )

    oee = (
        availability *
        productivity *
        quality
    )

    return {
        "availability": round(
            availability * 100, 2
        ),
        "productivity": round(
            productivity * 100, 2
        ),
        "quality": round(
            quality * 100, 2
        ),
        "oee": round(
            oee * 100, 2
        )
    }


def get_post_machining_ok_count(machine,cursor):
    return get_post_machining_count(
        post_machining_queries[machine],cursor
    )



def get_post_machining_nok_count(machine,cursor):
    return get_post_machining_count(
        post_machining_nok_queries[machine],cursor
    )



def get_post_machining_rework_count(machine,cursor):
    return get_post_machining_count(
        post_machining_rework_queries[machine],cursor
    )


def show_title():

    # Dynamic title
    if st.session_state.plant_section == "MACHINING":
        title_text = "TIU Machine Shop"

    elif st.session_state.plant_section == "POST_MACHINING":
        title_text = "TIU POST-MACHINING ANDON"
        
    elif st.session_state.plant_section is None:
        title_text = "TIU Shopfloor Andon"

    else:
        title_text = "TIU PRE-MACHINING ANDON"

    
    logo_base64 = get_logo()
    
    
    header_html = f"""
    <div style="
        width:100%;
        background:#00133D;
        color:white;
        padding:15px 25px;
        border-radius:35px;
        box-sizing:border-box;
        font-family:Arial;

        display:grid;
        grid-template-columns:350px 1fr 300px;
        align-items:center;
    ">

        <!-- Logo -->
        <div>
        <img
                src="data:image/jpeg;base64,{logo_base64}"
                style="
                height:60px;
                width:auto;
                border-radius:5px;
                "
        >
        </div>

        <!-- Dynamic Title -->
        <div style="
            text-align:center;
            font-size:72px;
            font-weight:bold;
            white-space:nowrap;
        ">
            {title_text}
        </div>

        <!-- Clock -->
        <div style="
            text-align:right;
        ">
            <div id="clock"
                 style="
                    font-size:35px;
                    font-weight:bold;
                 ">
            </div>
        </div>

    </div>

    <script>
    function updateClock() {{

        const now = new Date();

        const day = String(now.getDate()).padStart(2,'0');
        const month = now.toLocaleString('en-US', {{month:'short'}});
        const year = now.getFullYear();

        let hours = now.getHours();
        const ampm = hours >= 12 ? "PM" : "AM";

        hours = hours % 12;
        hours = hours ? hours : 12;

        const hh = String(hours).padStart(2,'0');
        const minutes = String(now.getMinutes()).padStart(2,'0');

        document.getElementById("clock").innerHTML =
            `${{day}}-${{month}}-${{year}} ${{hh}}:${{minutes}} ${{ampm}}`;
    }}

    updateClock();
    setInterval(updateClock, 1000);
    </script>
    """

    components.html(
        header_html,
        height=120,
        scrolling=False
    )
    

def show_tiles_dashboard():

    tile_machines = [
        m for m in machines
        if m["machine"] not in ["QLW01", "QLW02", "QLW03", "QALT"]
    ]

    for i in range(0, len(tile_machines), 4):

        cols = st.columns(4)

        for col, data in zip(cols, tile_machines[i:i+4]):

            with col:

                machine_tile(
                    data["display_name"],
                    data["status"],
                    data["prod_count"],
                    data["since"],
                    data["runtime"],
                    data["reason_alarm"],
                    data["target_label"],
                    data["part_count_color"],
                    data["ack_by"],
                    data["arrow"],
                    data["rw_count"],
                    data["availability"],
                    data["productivity"],
                    data["quality"],
                    data["oee"],
                    100
                )
                
        st.markdown("<div style='height:20px'></div>", unsafe_allow_html=True)

def show_production_progress():
    x_labels = [
        graph_labels.get(m["machine"], m["machine"])
        for m in machines
    ]
    
    bar_colors = [
    "#00CC00" if m["prod_count"] >= m["target_label"]
    else "#D50000"
    for m in machines
    ]

    fig = go.Figure()
    
    fig.update_xaxes(
    tickfont=dict(
        size=45,      # X-axis machine names
        color="white"
        )
    )

    fig.update_yaxes(
        tickfont=dict(
            size=40,      # Y-axis values
            color="white"
        ),
        title_font=dict(
            size=70,
            color="white"
        ),
        title_standoff=150
    )

    
    # Actual Count Bars
    
    fig.add_trace(
        go.Bar(
            name="OK",
            x=x_labels,
            y=[m["prod_count"] for m in machines],
            marker_color="#00CC00",
            text=[m["prod_count"] for m in machines],
            textposition="inside"
        )
    )
    
    
    fig.add_trace(
        go.Bar(
            name="Rework",
            x=x_labels,
            y=[m["rework_count"] for m in machines],
            marker_color="#FFD700",
            text=[m["rework_count"] for m in machines],
            textposition="inside"
        )
    )

    fig.add_trace(
        go.Bar(
            name="NOK",
            x=x_labels,
            y=[m["scrap_count"] for m in machines],
            marker_color="#D50000",
            text=[m["scrap_count"] for m in machines],
            textposition="inside"
        )
    )

    
    

    # Target Dotted Line
    fig.add_trace(
        go.Scatter(
            name="Target",
            x=x_labels,
            y=[m["target_label"] for m in machines],
            mode="lines+markers",
            line=dict(
                color="#FFA500",
                width=10,
                dash="dot"
            ),
            marker=dict(
                size=30,
                color="#FFA500"
            ),
            text=[m["target_label"] for m in machines],
            textposition="top center"
        )
    )

    fig.update_layout(
        title={
            "text": "PRODUCTION PROGRESS BY PROCESS",
            "x": 0.41,
            "font": {
            "size":50,
            "color":"white"
            }
        },
        barmode="stack",
        height=1800,
        plot_bgcolor="#162A3D",
        paper_bgcolor="#162A3D",
        font=dict(
            color="white",
            size=50
        ),
        xaxis_title="PROCESS",
        yaxis_title="COUNT",
        
        xaxis_title_font=dict(
        size=35,
        color="white"
        ),

        yaxis_title_font=dict(
        size=35,
        color="white"
        ),
        
        
    )
        
    fig.update_layout(
        legend=dict(
            traceorder="normal",
            orientation="h",
            yanchor="top",
            y=1.12,
            xanchor="right",
            x=1.0,
            font=dict(
                size=34,
                color="white"
            )
        )
    )
    
    fig.update_layout(
        yaxis=dict(
            tickfont=dict(
                color="white",
                size=40
            ),
            title_font=dict(
                color="white",
                size=35
            )
        ),
        xaxis=dict(
            tickfont=dict(
                color="white",
                size=45
            )
        )
    )
    fig.update_layout(
        hoverlabel=dict(
            bgcolor="white",
            font_size=28,     # Increase text size
            font_family="Arial",
            font_color="black"
        )
    )

    fig.add_annotation(
        text=f"Since : {datetime.now().strftime('%d-%b-%Y 06:30 AM')}",
        xref="paper",
        yref="paper",
        x=0.99,
        y=1.08,      # below legend
        showarrow=False,
        font=dict(
            size=34,
            color="white"
        ),
        xanchor="right"
    )
    st.plotly_chart(
        fig,
        use_container_width=True
    )


def show_hourly_production():

    start_time = datetime.now().strftime(
        "%Y-%m-%d 01:00:00"
    )
    
    #print(start_time)

    hour_slots = [
    "06:30-07:30","07:30-08:30","08:30-09:30","09:30-10:30","10:30-11:30","11:30-12:30",
    "12:30-13:30","13:30-14:30","14:30-15:30","15:30-16:30","16:30-17:30","17:30-18:30",
    "18:30-19:30","19:30-20:30","20:30-21:30","21:30-22:30","22:30-23:30","23:30-00:30",
    "00:30-01:30","01:30-02:30","02:30-03:30","03:30-04:30","04:30-05:30","05:30-06:30"  
    ]
    
    slot_map = {
    6: 0,7: 1,8: 2,9: 3,10: 4,11: 5,12: 6,13: 7,14: 8,15: 9,16: 10,17: 11,18: 12,19: 13,
    20: 14,21: 15,22: 16,23: 17,0: 18,1: 19,2: 20,3: 21,4: 22,5: 23
    }
    
    hourly_df = pd.DataFrame(index=hour_slots)

    conn = get_connection()

    for machine in machine_display:

        query = hourly_queries[machine]
        #print(query)

        cursor = conn.cursor()

        cursor.execute(query, start_time)

        rows = cursor.fetchall()
        #print(machine, rows)

        machine_hourly = [0] * len(hour_slots)
        ok_hourly = [0] * len(hour_slots)
        nok_hourly = [0] * len(hour_slots)

        # OK Query Result
        for row in rows:

            hr = int(row.Hr)
            qty = int(row.Qty)

            if hr in slot_map:

                machine_hourly[slot_map[hr]] = qty
                ok_hourly[slot_map[hr]] = qty

        # NOK Query Result
        if machine in hourly_nok_queries:

            cursor.execute(
                hourly_nok_queries[machine],
                start_time
            )

            nok_rows = cursor.fetchall()

            for row in nok_rows:

                hr = int(row.Hr)
                qty = int(row.Qty)

                if hr in slot_map:

                    nok_hourly[slot_map[hr]] = qty

        process_name = graph_labels.get(machine, machine)

        if machine in ["QLW01", "QLW02", "QLW03", "QALT"]:

            hourly_df[(process_name, "OK")] = ok_hourly

            hourly_df[(process_name, "NOK")] = nok_hourly

        else:

            hourly_df[(process_name, "A-JPH")] = machine_hourly

            hourly_df[(process_name, "T-JPH")] = [
                targets.get(machine, 0)
            ] * len(hour_slots)

    hourly_df.columns = pd.MultiIndex.from_tuples(
            hourly_df.columns
    )
    
    
    now = datetime.now()

    current_slot = None

    for slot in hour_slots:

        start_str, end_str = slot.split("-")

        start_time_slot = datetime.strptime(
            now.strftime("%Y-%m-%d") + " " + start_str,
            "%Y-%m-%d %H:%M"
        )

        end_time_slot = datetime.strptime(
            now.strftime("%Y-%m-%d") + " " + end_str,
            "%Y-%m-%d %H:%M"
        )

        if end_time_slot <= start_time_slot:
            end_time_slot += pd.Timedelta(days=1)

        current_check_time = now

        if now.hour < 6:
            current_check_time += pd.Timedelta(days=1)

        if start_time_slot <= current_check_time < end_time_slot:
            current_slot = slot
            break
    

    # Calculate current slot index
    current_idx = (
        hour_slots.index(current_slot)
        if current_slot in hour_slots
        else len(hour_slots) - 1
    )

    total_row = {}

    for col in hourly_df.columns:

        total_val = hourly_df[col].iloc[:current_idx + 1].sum()

        total_row[col] = total_val

        if col[1] == "T-JPH":
            target_per_hr = hourly_df[col].iloc[0]
            total_row[col] = target_per_hr * (current_idx + 1)

    # Add TOTAL row
    hourly_df.loc["Total (Till hr.)"] = pd.Series(total_row)

    # Move TOTAL row to top
    hourly_df = pd.concat([
        hourly_df.loc[["Total (Till hr.)"]],
        hourly_df.drop("Total (Till hr.)")
    ])

    # Styling starts here
    styled_df = hourly_df.style

    for process in graph_labels.values():

        if ((process, "A-JPH") in hourly_df.columns and(process, "T-JPH") in hourly_df.columns):
            
            # TOTAL row color
            actual_total = hourly_df.loc[
                "Total (Till hr.)",
                (process, "A-JPH")
            ]

            target_total = hourly_df.loc[
                "Total (Till hr.)",
                (process, "T-JPH")
            ]

            total_color = (
                "green"
                if actual_total >= target_total
                else "red"
            )

            styled_df = styled_df.set_properties(
                subset=pd.IndexSlice[
                    ["Total (Till hr.)"],
                    [(process, "A-JPH")]
                ],
                **{
                    "color": total_color,
                    "font-weight": "bold",
                    "background-color": "#FFF8DC"
                }
            )

            # HOURLY row colors
            for idx in hourly_df.index:

                if idx == "Total (Till hr.)":
                    continue

                act_val = hourly_df.loc[
                    idx,
                    (process, "A-JPH")
                ]

                tgt_val = hourly_df.loc[
                    idx,
                    (process, "T-JPH")
                ]

                color = (
                    "green"
                    if act_val >= tgt_val
                    else "red"
                )

                styled_df = styled_df.set_properties(
                    subset=pd.IndexSlice[
                        [idx],
                        [(process, "A-JPH")]
                    ],
                    **{
                        "color": color,
                        "font-weight": "bold"
                    }
                )
        if (process, "OK") in hourly_df.columns:

            styled_df = styled_df.set_properties(
                subset=pd.IndexSlice[:, [(process, "OK")]],
                **{
                    "color": "Green",
                    "font-weight": "bold"
                }
            )

        if (process, "NOK") in hourly_df.columns:

            styled_df = styled_df.set_properties(
                subset=pd.IndexSlice[:, [(process, "NOK")]],
                **{
                    "color": "red",
                    "font-weight": "bold"
                }
            )

    styled_df = styled_df.set_table_styles([
        {
            "selector": "table",
            "props": [
                ("width", "100%"),
                ("border-collapse", "collapse"),
                ("table-layout", "fixed")
            ]
        },

        {
            "selector": "th",
            "props": [
                ("background-color", "#00133D"),
                ("color", "white"),
                ("font-size", "40px"),
                ("font-weight", "bold"),
                ("text-align", "center"),
                ("padding", "5px"),
                ("border", "1px solid rgba(255,255,255,0.15)")
            ]
        },

        {
            "selector": "tbody th",
            "props": [
                ("font-size", "32px"),
                ("font-weight", "bold"),
                ("text-align", "center"),
                ("padding", "15px"),
                ("border", "1px solid rgba(255,255,255,0.15)"),
                ("background-color", "#00133D")
            ]
        },

        {
            "selector": "td",
            "props": [
                ("font-size", "32px"),
                ("font-weight", "bold"),
                ("text-align", "center"),
                ("padding", "10px"),
                ("border", "1px solid rgba(255,255,255,0.15)")
            ]
        }
    ])
    
    if current_slot:

        styled_df = styled_df.set_properties(
            subset=pd.IndexSlice[[current_slot], :],
            **{
                "background-color": "#90EE90",
                "font-weight": "bold"
            }
        )
        
    styled_df = styled_df.set_properties(
        subset=pd.IndexSlice[["Total (Till hr.)"], :],
        **{
            "background-color": "#FFFACD",
            "font-weight": "bold",
            "font-size": "34px"
        }
    )
    html_table = styled_df.to_html()
    
    #colspan = len(hourly_df.columns) + 1  # +1 for TIME column

    st.markdown(
    """
    <div style="
        background:#00133D;
        color:white;
        font-size:45px;
        font-weight:bold;
        text-align:center;
        padding:10px;
        margin-bottom:5px;
    ">
        PRODUCTION PROGRESS BY PROCESS (HOURLY)
    </div>
    """,
    unsafe_allow_html=True
    )

    
    st.markdown("""
    <style>
        table {
        border-collapse: collapse !important;
        width: 100% !important;
    }
    
    /* Remove thick borders everywhere */
    table th,
    table td{
        border:1px solid #808080 !important;
    }

    /* Process header border (UC1 | SF | LW1 | ...) */
    thead th[colspan="2"]{
        border-right:4px solid black !important;
    }
    
    /* Make all header cells same width */
    thead th {
        min-width: 90px !important;
    }

    /* Specifically for OK/NOK columns */
    thead th.col_heading {
        min-width: 90px !important;
    }

    td {
        min-width: 90px !important;
    }

    /* Data section */
    tbody td:nth-child(3),
    tbody td:nth-child(5),
    tbody td:nth-child(7),
    tbody td:nth-child(9),
    tbody td:nth-child(11),
    tbody td:nth-child(13),
    tbody td:nth-child(15),
    tbody td:nth-child(17),
    tbody td:nth-child(19),
    tbody td:nth-child(21),
    tbody td:nth-child(23),
    tbody td:nth-child(25),
    tbody td:nth-child(27),
    tbody td:nth-child(29){
        border-right:4px solid black !important;
    }

    /* Top blank cell -> PROCESS */
    thead tr:first-child th.blank:first-child::after{
        content:"PROCESS";
        color:white;
        font-size:40px;
        font-weight:bold;
    }

    /* Second blank cell -> TIME */
    thead tr:nth-child(2) th.blank:first-child::after{
        content:"Time";
        color:white;
        font-size:40px;
        font-weight:bold;
    }

    </style>
    """, unsafe_allow_html=True)

    st.markdown(
        html_table,
        unsafe_allow_html=True
    )



@st.cache_data(ttl=30)
def load_machine_data(downtime_df):
    
    
    conn = get_connection()
    cursor = conn.cursor()

    machines = []

    for machine in machine_display:

        query = f"""
        SELECT TOP 1 
            DATEADD(MINUTE, 330, DowntimeStartTime) as DowntimeStartTime_ist,
            DATEADD(MINUTE, 330, DowntimeEndTime) as DowntimeEndTime_ist,
            DATEADD(MINUTE, 330, LastUpdateOn) as LastUpdateOn_ist,*
        FROM AT_DowntimeData
        WHERE WorkCenter = '{machine}'
        AND DowntimeStartTime >= ?
        ORDER BY ID DESC
        """
        
        mes_query = f"""
        SELECT TOP 1
            DATEADD(MINUTE,330,StartTime) AS StartTime_IST,
            DATEADD(MINUTE,330,EndTime) AS EndTime_IST,
            *
        FROM AT_MESBypassData
        WHERE WorkCenter = '{machine}'
        ORDER BY ID DESC
        """
        cursor.execute(mes_query)
        mes_row = cursor.fetchone()
        
        shift_start_utc = datetime.strptime(
            datetime.now().strftime("%Y-%m-%d") + " 01:00:00",
            "%Y-%m-%d %H:%M:%S"
        )

        machine_dt = downtime_df[
            downtime_df["WorkCenter"].str.contains(
                machine,
                na=False
            )
        ]

        if not machine_dt.empty:
            row = machine_dt.sort_values(
                "DowntimeStartTime_ist",
                ascending=False
            ).iloc[0]
        else:
            row = None

        shift_start = datetime.strptime(
            datetime.now().strftime("%Y-%m-%d") + " 06:30:00",
            "%Y-%m-%d %H:%M:%S"
        )

        status = "Operational"
        since = shift_start.strftime("%d-%b-%y %H:%M:%S")
        runtime = get_elapsed_time(shift_start)
        reason_alarm = "-"

        # MES Bypass Check
        if (
            mes_row
            and mes_row.StartTime_IST is not None
            and mes_row.EndTime_IST is None
        ):

            status = "MES BYPASS"

            since = mes_row.StartTime_IST.strftime(
                "%d-%b-%y %H:%M:%S"
            )

            runtime = get_elapsed_time(
                mes_row.StartTime_IST
            )

        elif row is not None:

            if pd.isna(row["DowntimeEndTime_ist"]):

                if str(row["Type"]).upper() == "BREAKDOWNTIME":
                    status = "BREAKDOWN"

                elif str(row["Type"]).upper() == "OPERATIONAL_BREAKDOWN":
                    status = "OPERATIONAL_BREAKDOWN"

                else:
                    status = "BREAKDOWN"

                since = row["DowntimeStartTime_ist"].strftime(
                    "%d-%b-%y %H:%M:%S"
                )

                runtime = get_elapsed_time(
                    row["DowntimeStartTime_ist"]
                )

            else:

                status = "Operational"

                since = row["DowntimeEndTime_ist"].strftime(
                    "%d-%b-%y %H:%M:%S"
                )

                runtime = get_elapsed_time(
                    row["DowntimeEndTime_ist"]
                )
                

                
        # Special logic for Brazing
        if machine == "BRZN_FX":

            shift_start = datetime.strptime(
                datetime.now().strftime("%Y-%m-%d") + " 06:30:00",
                "%Y-%m-%d %H:%M:%S"
            )

            since = shift_start.strftime(
                "%d-%b-%Y %I:%M:%S %p"
            )

            runtime = get_elapsed_time(
                shift_start
            )
            
            reason_alarm = "-"
        else:
            reason_alarm = "-"
            ack_by = "-"

        # ------------------------------------------
        # Production Count
        # ------------------------------------------

        start_time = datetime.now().strftime(
            "%Y-%m-%d 01:00:00"
        )
        
      
        prod_query = machine_queries.get(machine)

        if prod_query:

            cursor.execute(prod_query, start_time)

            prod_result = cursor.fetchone()

            prod_count = (
                int(prod_result[0])
                if prod_result and prod_result[0] is not None
                else 0
            )
        else:
            prod_count = 0
            
        rework_query = rework_queries.get(machine)

        if rework_query:

            cursor.execute(rework_query, start_time)

            rw_result = cursor.fetchone()

            rework_count = (
                int(rw_result[0])
                if rw_result and rw_result[0] is not None
                else 0
            )
            #print(rework_count)

        else:
            rework_count = 0

        scrap_query = scrap_queries.get(machine)

        if scrap_query:

            cursor.execute(
                scrap_query,
                start_time
            )

            scrap_result = cursor.fetchone()

            scrap_count = (
                int(scrap_result[0])
                if scrap_result and scrap_result[0] is not None
                else 0
            )

        else:
            scrap_count = 0

        
        # Start time (today at 06:30:00)
        start_time = datetime.strptime(
            datetime.now().strftime("%Y-%m-%d") + " 06:30:00",
            "%Y-%m-%d %H:%M:%S"
        )

        current_time = datetime.now()
        elapsed_hours = (current_time - start_time).total_seconds() / 3600

        target_per_day = targets.get(machine, 0)
        target_qty = int((target_per_day) * elapsed_hours)
        
        if target_qty > prod_count:
            part_count_color = "#D50000"
            arrow ="▼"
            
        else:
            part_count_color = "#138A36"
            arrow = "▲"
            
            
        display_name = machine_display.get(machine, machine)
        display_status = format_status(status)
        
        oee_data = get_oee(
            machine_code=machine,
            prod_count=prod_count,
            rework_count=rework_count,
            scrap_count=scrap_count,
            conn=conn
        )
        

        
        machines.append({"machine": machine,"display_name": display_name,"status": display_status,"since": since,"runtime": runtime,"prod_count": prod_count,
        "part_count_color":part_count_color,"target_label": target_qty,"reason_alarm": reason_alarm,"ack_by": ack_by,"arrow":arrow,
        "rw_count": rework_count,"rework_count": rework_count,"scrap_count": scrap_count,"availability": oee_data["availability"],"productivity": oee_data["productivity"],
        "quality": oee_data["quality"],"oee": oee_data["oee"], "matrix_value":100

        })

    conn.close()
    return machines



@st.cache_data(ttl=30)
def load_machining_data():

    machines = []
    conn = get_connection()
    cursor = conn.cursor()
    
    for machine, display_name in machining_display.items():

        prod_count = get_machining_production_count(machine,cursor)
        nok_count = get_machining_nok_count(machine,cursor)
        rework_count = get_machining_rework_count(machine,cursor)

        start_time = datetime.strptime(
            datetime.now().strftime("%Y-%m-%d") + " 06:30:00",
            "%Y-%m-%d %H:%M:%S"
        )

        elapsed_hours = (
            datetime.now() - start_time
        ).total_seconds() / 3600

        target_per_hour = get_machining_target(machine)

        target_qty = int(
            target_per_hour * elapsed_hours
        )

        if prod_count < target_qty:
            part_count_color = "#D50000"   # Red
            arrow = "▼"
        else:
            part_count_color = "#138A36"   # Green
            arrow = "▲"

        oee_data = get_machining_oee(
            machine,
            prod_count,
            rework_count,
            nok_count,
            conn
        )
        matrix_value = get_machining_target(machine)
        machines.append({
            "machine": machine,
            "display_name": display_name,
            "prod_count": prod_count,
            "scrap_count": nok_count,
            "status": "Operational",
            "since": datetime.now().strftime("%d-%b-%y 06:30:00"),
            "runtime": get_elapsed_time(start_time),
            "reason_alarm": "-",
            "target_label": target_qty,
            "part_count_color": part_count_color,
            "ack_by": "-",
            "arrow": arrow,
            "rw_count": rework_count,
            "availability": oee_data["availability"],
            "productivity": oee_data["productivity"],
            "quality": oee_data["quality"],
            "oee": oee_data["oee"],
            "matrix_value":matrix_value
        })
    conn.close()
    return machines

def show_section_selection():
    
    # st.markdown(
    # "<h1 style='color:red'>TEST</h1>",
    # unsafe_allow_html=True
# )

    

    
    
    st.markdown("""
    <style>
    
    
       
    .top-banner{
        height:800px;

        background: transparent;

        border:none;

        box-shadow:none;
    }

    /* Section Selection Tiles */

    div[data-testid="stHorizontalBlock"] .stButton > button {

        background: linear-gradient(
            135deg,
            #00133D,
            #0B2D6B
        ) !important;

        color: white !important;

        height: 550px !important;

        border: none !important;

        border-radius: 50px !important;
        
        margin-top: 550px !important;

        box-shadow: 0px 10px 25px rgba(0,0,0,0.30) !important;

        transition: all 0.3s ease !important;
        display: flex !important;
    }

    /* Button Text */

     div[data-testid="stHorizontalBlock"] .stButton > button p {

        font-size: 80px ;

        font-weight: 700 !important;

        color: white !important;

        line-height: 1.6 !important;

        text-align: center !important;

        margin: 0 !important;
    }

    /* Hover Effect */

     div[data-testid="stHorizontalBlock"] .stButton > button:hover {

        background: linear-gradient(
            135deg,
            #FF8C00,
            #E67700
        ) !important;

        transform: translateY(-6px);

        box-shadow: 0px 15px 35px rgba(0,0,0,0.40) !important;
    }

    

    </style>
    """, unsafe_allow_html=True)
    
    show_title()
    
    st.markdown('<div class="plant-selection">', unsafe_allow_html=True)

    col1, col2, col3 = st.columns(3)

    with col1:
        if st.button(
            "🏭\n\nPre-Machining\n",
            use_container_width=True,
            key="premachining"
        ):
            st.session_state.plant_section = "PRE_MACHINING"
            st.rerun()

    with col2:
        if st.button(
            "🏭\n\nMachining\n",
            use_container_width=True,
            key="machining"
        ):
            st.session_state.plant_section = "MACHINING"
            st.rerun()

    with col3:
        if st.button(
            "🏭\n\nPost-Machining\n",
            use_container_width=True,
            key="postmachining"
        ):
            st.session_state.plant_section = "POST_MACHINING"
            st.rerun()
            
    st.markdown('</div>', unsafe_allow_html=True)
            

def show_machining_dashboard():

    if st.session_state.machining_page is None:

        # ADD HERE
        st.markdown("""
        <style>
        .tile-card{
            background: linear-gradient(135deg,#00133D,#0B2D6B);
            border-radius: 25px 25px 0px 0px;
            padding: 80px;
            text-align: center;
            min-height: 700px;
            color: white;
            box-shadow: 0px 10px 25px rgba(0,0,0,0.3);
            margin-top: 250px;
        }

         
        .stButton > button:hover{
            background: linear-gradient(
                135deg,
                #00133D,
                #0B2D6B
            ) !important;
        }
        
        .tile-title{
            font-size: 130px;
            font-weight: bold;
            margin-top: 100px;
        }

        .tile-sub{
            font-size: 50px;
            opacity: 0.9;
            margin-top: 10px;
        }

        .big-title{
            text-align:center;
            font-size:60px;
            font-weight:700;
            color:#00133D;
            margin-bottom:40px;
        }
        

        /* VMC Buttons */

        div[data-testid="stHorizontalBlock"] .stButton button {

            background: linear-gradient(
                135deg,
                #00133D,
                #0B2D6B
            ) !important;

            color: white !important;

            height: 250px !important;
            

            border: none !important;

            border-radius: 0px 0px 25px 25px !important;

            margin-top: -8px !important;

            box-shadow: 0px 10px 25px rgba(0,0,0,0.30) !important;

            transition: all 0.3s ease !important;
        }

        /* Button Text */

        div[data-testid="stHorizontalBlock"] .stButton button p {

            font-size: 70px !important;

            font-weight: 800 !important;

            color: white !important;

            margin: 0 !important;
        }

        /* Hover */

        div[data-testid="stHorizontalBlock"] .stButton button:hover {

            background: linear-gradient(
                135deg,
                #FF8C00,
                #E67700
            ) !important;

            transform: translateY(-4px);

            box-shadow: 0px 15px 35px rgba(0,0,0,0.40) !important;
        }

        /* Hover Text */

        .stButton button:hover p {

            color: white !important;
        }

        </style>
        """, unsafe_allow_html=True)

        

        # ADD AFTER TITLE
        sp1, col1, col2, sp2 = st.columns([3,2,2,3])

        # VMC1
        with col1:
            #with st.container(border=True):
            st.markdown("""
            <div class="tile-card">
                <div style="font-size:120px;">🏭</div>
                <div class="tile-title">VMC1</div>
                
            </div>
            """, unsafe_allow_html=True)

            
            if st.button(
                "OP-10 / OP-20",
                use_container_width=True,
                key="vmc1_btn"
            ):
                st.session_state.machining_page = "VMC1"
                st.rerun()

        # VMC2
        with col2:
            st.markdown("""
            <div class="tile-card">
                <div style="font-size:120px;">🏭</div>
                <div class="tile-title">VMC2</div>
                
            </div>
            """, unsafe_allow_html=True)

            if st.button(
                "OP-30 / OP-40 / OP-50",
                use_container_width=True,
                key="vmc2_btn"
            ):
                st.session_state.machining_page = "VMC2"
                st.session_state.machining_view = "OP30"
                st.rerun()

        return
    # ----------------------------------
    # Back Button
    # ----------------------------------

    if st.button("⬅ Back", key="back_vmc"):
        st.session_state.machining_page = None
        st.rerun()

    # ----------------------------------
    # VMC1 Dashboard
    # ----------------------------------

    if st.session_state.machining_page == "VMC1":

        vmc1 = [
            m for m in machines
            if m["machine"].startswith(
                ("OP_10", "OP_20")
            )
        ]

        display_machining_section(
            "VMC1",
            vmc1,
            4
        )

    # ----------------------------------
    # VMC2 Dashboard
    # ----------------------------------

    elif st.session_state.machining_page == "VMC2":

        machining_view = st.session_state.get(
            "machining_view",
            "OP30"
        )

        if machining_view == "OP30":

            op30 = [
                m for m in machines
                if m["machine"].startswith("OP_30")
            ]

            display_machining_section(
                "OP-30",
                op30,
                4
            )

        elif machining_view == "OP40":

            op40 = [
                m for m in machines
                if m["machine"].startswith("OP_40")
            ]

            display_machining_section(
                "OP-40",
                op40,
                4
            )

        elif machining_view == "OP50":

            op50 = [
                m for m in machines
                if m["machine"].startswith("OP_50")
            ]

            display_machining_section(
                "OP-50",
                op50,
                3
            )


def show_sidebar(machines):

    with st.sidebar:

        left, center, right = st.columns([1,2,1])

        with center:
            st.image(
                r"C:\Andon\logo.jpg",
                width=350
            )

        st.markdown(
            '<div class="sidebar-title">ANDON CONTROL</div>',
            unsafe_allow_html=True
        )

        st.markdown(
            f"""
            <div class="user-card">
                <b>User</b><br>
                {st.session_state.username}
                <br><br>
                <b>Role</b><br>
                {st.session_state.role}
            </div>
            """,
            unsafe_allow_html=True
        )

        if st.button(
            "Main Menu",
            use_container_width=True,
            key="home_btn"
        ):
            st.session_state.plant_section = None
            st.session_state.machining_page = None
            st.rerun()

        if st.button(
            "Logout",
            use_container_width=True,
            key="logout_btn"
        ):
            st.session_state.logged_in = False
            st.session_state.username = ""
            st.session_state.role = ""
            st.rerun()

        # Auto Rotate
        st.session_state.auto_rotate = st.checkbox(
            "Auto Rotate Views",
            value=st.session_state.auto_rotate
        )

        # View Selection
        view_mode = st.radio(
            "ANDON VIEW",
            ["TILES"],
            index=["TILES"].index(
                st.session_state.view_mode
            )
        )

        if view_mode != st.session_state.view_mode:
            st.session_state.view_mode = view_mode
            st.session_state.last_switch = time.time()

        # VMC2 Operation Selection
        if (
            st.session_state.plant_section == "MACHINING"
            and st.session_state.machining_page == "VMC2"
        ):

            st.radio(
                "Select Operation",
                ["OP30", "OP40", "OP50"],
                key="machining_view"
            )

        # L2 Controls
        if st.session_state.role == "L2":

            st.markdown("---")

            if st.session_state.plant_section == "PRE_MACHINING":
                machine_list = list(machine_display.keys())

            elif st.session_state.plant_section == "MACHINING":
                machine_list = list(machining_display.keys())

            else:
                machine_list = []

            if machine_list:

                selected_machine = st.selectbox(
                    "Select Machine",
                    machine_list,
                    key="selected_machine"
                )

                if machines:

                    selected_data = next(
                        (
                            item
                            for item in machines
                            if item["machine"] == selected_machine
                        ),
                        None
                    )

                    if (
                        selected_data
                        and selected_data["status"] == "Breakdown"
                    ):

                        st.markdown(
                            """
                            <div class="action-card">
                                <h4>🔔 Andon Action</h4>
                            </div>
                            """,
                            unsafe_allow_html=True
                        )

                        reason_code = st.selectbox(
                            "Reason Code",
                            [
                                "Mechanical Failure",
                                "Electrical Failure",
                                "Instrumentation Failure",
                                "Pneumatic Failure",
                                "Hydraulic Failure",
                                "Robot/ Automation Failure",
                                "Controls/ PLC Failure",
                                "Tooling Failure",
                                "Emergency Stop",
                                "Shift/ Machine Startup",
                                "Shift Changeover",
                                "Changeover",
                                "Tooling Change",
                                "Teaching / Trials / Validation",
                                "New Product Introduction",
                                "Bio Break",
                                "Tea Break",
                                "Snack Break",
                                "Lunch/ Dinner Break",
                                "No Production Plan Available",
                                "No Shift/ Operator Planned",
                                "Operator Not Available",
                                "Operator Not at Station",
                                "Training / Meeting",
                                "Child parts unavailable",
                                "No parts from previous station",
                                "No Bins/ Baskets/ Trays/ Fixtures",
                                "Consumable unavailable",
                                "Packaging Material Unavailable",
                                "First Piece Approval",
                                "SPC Check",
                                "Quality Concern",
                                "Rework",
                                "Maintenance",
                                "5S/ Cleaning",
                                "MES Issue",
                                "Others"
                            ],
                            key=f"rc_{selected_machine}"
                        )

                        if st.button(
                            "Acknowledge",
                            use_container_width=True,
                            key=f"ack_{selected_machine}"
                        ):

                            save_reason_code(
                                selected_machine,
                                selected_data["status"],
                                reason_code,
                                st.session_state.username
                            )

                            st.success("Acknowledged")
                            st.rerun()

@st.cache_data(ttl=30)
def display_machining_section(
    title,
    machine_list,
    cols_per_row
):

    st.markdown(
        f"""
        <div style="
            background:#00133D;
            color:white;
            font-size:60px;
            font-weight:bold;
            text-align:center;
            padding:10px;
            border-radius:10px;
            margin-bottom:15px;
        ">
            {title}
        </div>
        """,
        unsafe_allow_html=True
    )

    for i in range(0, len(machine_list), cols_per_row):

        cols = st.columns(cols_per_row)

        for col, data in zip(
            cols,
            machine_list[i:i+cols_per_row]
        ):

            with col:

                machine_tile(
                    data["display_name"],
                    data["status"],
                    data["prod_count"],
                    data["since"],
                    data["runtime"],
                    data["reason_alarm"],
                    data["target_label"],
                    data["part_count_color"],
                    data["ack_by"],
                    data["arrow"],
                    data["rw_count"],
                    data["availability"],
                    data["productivity"],
                    data["quality"],
                    data["oee"],
                    data["matrix_value"]
                )


@st.cache_data(ttl=30)
def load_post_machining_data(downtime_df):
    conn = get_connection()
    cursor = conn.cursor()

    machines = []

    for machine, display_name in post_machining_display.items():
        
        
        ok_count = get_post_machining_ok_count(machine,cursor)

        nok_count = get_post_machining_nok_count(machine,cursor)

        rework_count = get_post_machining_rework_count(machine,cursor)
        
        
        shift_start_utc = datetime.strptime(
            datetime.now().strftime("%Y-%m-%d") + " 01:00:00",
            "%Y-%m-%d %H:%M:%S"
        )

        shift_start = datetime.strptime(
            datetime.now().strftime("%Y-%m-%d") + " 06:30:00",
            "%Y-%m-%d %H:%M:%S"
        )

        status = "Operational"
        since = shift_start.strftime("%d-%b-%y %H:%M:%S")
        runtime = get_elapsed_time(shift_start)
        reason_alarm = "-"
        
        downtime_query = """
            SELECT TOP 1
                   DATEADD(MINUTE,330,DowntimeStartTime) AS DowntimeStartTime_ist,
                   DATEADD(MINUTE,330,DowntimeEndTime) AS DowntimeEndTime_ist
            FROM AT_DowntimeData
            WHERE WorkCenter LIKE ?
              AND Type = 'BreakDownTime'
              AND DowntimeStartTime >= ?
            ORDER BY ID DESC
            """
        
        machine_dt = downtime_df[
            (downtime_df["WorkCenter"].str.contains(machine, na=False)) &
            (downtime_df["Type"] == "BreakDownTime")
        ]

        if not machine_dt.empty:
            row = machine_dt.sort_values(
                "DowntimeStartTime",
                ascending=False
            ).iloc[0]
        else:
            row = None
        
        if row:

            if row.DowntimeEndTime_ist is None:

                status = "BREAKDOWN"

                since = row.DowntimeStartTime_ist.strftime(
                    "%d-%b-%y %H:%M:%S"
                )

                runtime = get_elapsed_time(
                    row.DowntimeStartTime_ist
                )

            else:

                status = "Operational"

                since = row.DowntimeEndTime_ist.strftime(
                    "%d-%b-%y %H:%M:%S"
                )

                runtime = get_elapsed_time(
                    row.DowntimeEndTime_ist
                )


        elapsed_hours = (
            datetime.now() - shift_start
        ).total_seconds() / 3600

        target_per_hour = post_targets.get(machine, 0)

        target_qty = int(
            target_per_hour * elapsed_hours
        )

        if ok_count < target_qty:
            part_count_color = "#D50000"
            arrow = "▼"
        else:
            part_count_color = "#138A36"
            arrow = "▲"

        oee_data = get_oee(
            machine_code=machine,
            prod_count=ok_count,
            rework_count=rework_count,
            scrap_count=nok_count,
            conn=conn
        )

        machines.append({
        "machine": machine,
        "display_name": display_name,
        "status": format_status(status),
        "since": since,
        "runtime": runtime,
        "prod_count": ok_count,
        "rw_count": rework_count,
        "rework_count": rework_count,
        "scrap_count": nok_count,
        "reason_alarm": "-",
        "target_label": target_qty,
        "part_count_color": part_count_color,
        "ack_by": "-",
        "arrow": arrow,
        "availability": oee_data["availability"],
        "productivity": oee_data["productivity"],
        "quality": oee_data["quality"],
        "oee": oee_data["oee"],
        "matrix_value":100

    })

    conn.close()
    return machines


downtime_df = load_downtime_data()

machines = []
if st.session_state.plant_section == "PRE_MACHINING":
    machines = load_machine_data(downtime_df)

elif st.session_state.plant_section == "MACHINING":
    machines = load_machining_data()

elif st.session_state.plant_section == "POST_MACHINING":
    machines = load_post_machining_data(downtime_df)
    
show_sidebar(machines)


def main():

    if st.session_state.plant_section is None:

        show_section_selection()
        return

    show_title()

    if st.session_state.plant_section == "MACHINING":
        show_machining_dashboard()

    elif st.session_state.view_mode == "TILES":
        show_tiles_dashboard()



if __name__ == "__main__":
    main()