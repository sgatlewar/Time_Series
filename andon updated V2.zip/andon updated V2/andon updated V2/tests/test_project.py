import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_python_files_compile():
    for p in ROOT.rglob("*.py"):
        ast.parse(p.read_text(encoding="utf-8"), filename=str(p))


def test_get_machine_and_cache_exports():
    service = (ROOT / "app/services/dashboard_service.py").read_text(encoding="utf-8")
    cache = (ROOT / "app/services/data_cache.py").read_text(encoding="utf-8")
    assert "def get_machine(" in service
    assert "def get_machines(" in service
    assert "def get_snapshot(" in cache
    assert "def refresh_from_sql(" in cache
    assert "os.replace(TMP_FILE, JSON_FILE)" in cache


def test_dashboard_reads_json_cache():
    routes = (ROOT / "app/routes.py").read_text(encoding="utf-8")
    assert "from app.services.data_cache import" in routes
    assert "get_snapshot" in routes


def test_reason_ack_removed():
    for rel in [
        "app/routes.py",
        "app/services/dashboard_service.py",
        "app/templates/machine_card.html",
        "app/templates/machine_detail.html",
    ]:
        text = (ROOT / rel).read_text(encoding="utf-8").lower()
        assert "reason_code" not in text
        assert "acknowledge" not in text


def test_mes_bypass_for_pre_and_post():
    text = (ROOT / "app/services/dashboard_service.py").read_text(encoding="utf-8")
    assert "def load_mes_bypass_data" in text
    assert "post_machining_wc" in text
    assert "EndTime_IST" in text
    assert "MES BYPASS" in text


def test_status_color_used_for_runtime():
    card = (ROOT / "app/templates/machine_card.html").read_text(encoding="utf-8")
    js = (ROOT / "app/static/js/andon.js").read_text(encoding="utf-8")
    assert "machine.status_color" in card
    assert "statusColor" in js
    assert "class=\"runtime\" style=\"color:${escapeHtml(statusColor)}\"" in js
