# TIU Andon Flask Dashboard

## New dashboard views
Each Pre-Machining, Machining and Post-Machining section now has three views:

1. **Tiles** - existing machine/OEE tiles.
2. **Production** - current-day production bar chart up to the current hour with target dotted line.
3. **Hourly** - 24-hour production matrix with the current hour highlighted.

The browser auto-rotates Tiles -> Production -> Hourly. Set `SCREEN_ROTATION_SECONDS` in `.env` if you want to change the rotation interval. The default is 15 seconds.

## Data architecture
SQL is read by the background worker every `DATA_REFRESH_SECONDS` (default 20 seconds). The worker calculates machine status/OEE/MES Bypass and production data, then atomically overwrites `data/andon_data.json`. The browser reads only the JSON/API snapshot.

## MES Bypass
`AT_MESBypassData` is checked by latest ID per WorkCenter. A record is active when `StartTime` is present and `EndTime` is NULL. Post-machining UC2 is mapped to database WorkCenter `UC02`.

## Removed
Reason Code and Acknowledge logic are not part of this Flask project.

## Run
1. Copy `.env.example` to `.env` and set SQL credentials.
2. Install dependencies: `pip install -r requirements.txt`
3. Run: `python run.py`


### Machining VMC production views

- VMC1 production graph/hourly views contain only OP-10, OP-20 and VMC1 Q-Gate.
- VMC2 production graph/hourly views contain only OP-30, OP-40, OP-50 and VMC2 Q-Gate.
- Q-Gate rows are sourced from the matching VMC process table using WorkCenter values containing `Q-Gate`, `QGATE`, or `Q_GATE`.
- Q-Gate target is configurable with `VMC_QGATE_TARGET` (default `0`).
- The `/api/production/MACHINING?page=VMC1` and `page=VMC2` responses are separately scoped, so auto-rotation cannot mix the two VMCs.

## Variant selection rules

The three variant buttons are available independently inside Pre-Machining, Machining and Post-Machining:

- Matrix
- Banana Mini
- Kiwi Mini

Variant identification is based on `WipOrderNo` prefixes:
- Matrix: `P00%` through VMC1/QVMC1, then `Q00%` from SLGL through Packaging.
- Banana Mini: `P01%` through VMC1/QVMC1, then `Q01%` from SLGL through Packaging.
- Kiwi Mini: `P02%` through VMC1/QVMC1, then `Q02%` from SLGL through Packaging.

`AT_ALT1_Process` is used for the LM station for Banana Mini/Kiwi Mini. `AT_RivetingProcess` is used for Kiwi Mini riveting.

The selected variant drives Tiles, Production Progress and Production Hourly views for all three sections.
