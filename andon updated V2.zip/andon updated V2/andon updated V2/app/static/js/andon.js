function updateClock() {
  const el = document.getElementById("clock");
  if (!el) return;
  const now = new Date();
  const day = String(now.getDate()).padStart(2,"0");
  const month = now.toLocaleString("en-US", {month:"short"});
  const year = now.getFullYear();
  let hours = now.getHours();
  const ampm = hours >= 12 ? "PM" : "AM";
  hours = hours % 12 || 12;
  el.textContent = `${day}-${month}-${year} ${String(hours).padStart(2,"0")}:${String(now.getMinutes()).padStart(2,"0")} ${ampm}`;
}

let refreshSeconds=20, refreshTimer=null, rotationTimer=null;
let autoRotate=true, views=["tiles","progress","hourly"], viewIndex=0;

function escapeHtml(value){return String(value??"").replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));}
function section(){return document.getElementById("dashboard")?.dataset.section;}
function selectedVariant(){return document.getElementById("dashboard")?.dataset.variant || localStorage.getItem("tiu_variant") || "Matrix";}
function setVariant(v){const d=document.getElementById("dashboard"); if(!d)return; d.dataset.variant=v; localStorage.setItem("tiu_variant",v); document.querySelectorAll(".variant-btn").forEach(b=>b.classList.toggle("active",b.dataset.variant===v)); loadMachines(); loadProduction();}

function setView(view){
  viewIndex=Math.max(0,views.indexOf(view));
  document.querySelectorAll(".dashboard-view").forEach(x=>x.classList.remove("active"));
  document.getElementById(`${view}-view`)?.classList.add("active");
  document.querySelectorAll(".view-btn[data-view]").forEach(x=>x.classList.toggle("active",x.dataset.view===view));
  if(view==="tiles") loadMachines(); else loadProduction();
}

function scheduleRefresh(){clearTimeout(refreshTimer);refreshTimer=setTimeout(async()=>{await loadMachines();await loadProduction();scheduleRefresh();},Math.max(1,refreshSeconds)*1000);}
function scheduleRotation(){clearTimeout(rotationTimer);if(!autoRotate)return;const sec=Number(document.getElementById("dashboard")?.dataset.rotationSeconds||15);rotationTimer=setTimeout(()=>{viewIndex=(viewIndex+1)%views.length;setView(views[viewIndex]);scheduleRotation();},Math.max(5,sec)*1000);}

async function loadMachines(){
 const grid=document.getElementById("machine-grid"); if(!grid)return;
 const d=document.getElementById("dashboard"), section=d.dataset.section, page=d.dataset.machiningPage, view=d.dataset.machiningView;
 try{let url=`/api/machines/${encodeURIComponent(section)}`;const q=new URLSearchParams();if(page)q.set("page",page);if(view)q.set("view",view);q.set("variant",selectedVariant());if(q.toString())url+=`?${q}`;
 const r=await fetch(url,{cache:"no-store"});if(!r.ok)throw Error(`HTTP ${r.status}`);const p=await r.json();refreshSeconds=Number(p.refresh_seconds||20);const machines=p.machines||[];grid.innerHTML=machines.length?machines.map(renderCard).join(""):`<div class="loading">No machine data available</div>`;
 }catch(e){grid.innerHTML=`<div class="error-box">Unable to load machine data: ${escapeHtml(e.message)}</div>`;}
}
function renderCard(m){const statusColor=m.status_color||"#138A36"; const c=statusColor;const icon=m.status==="Breakdown"?"🔴":m.status==="Operational Breakdown"?"🟠":m.status==="MES Bypass"?"🟣":"🟢";const sec=m.machine_section||section();return `<div class="andon-card" onclick="location.href='/machine/${encodeURIComponent(sec)}/${encodeURIComponent(m.machine)}'"><div class="card-header" style="background:${c}"><div class="machine-name">${escapeHtml(m.display_name)}</div><div class="status">${icon} ${escapeHtml(m.status)}</div><div class="since">Since: ${escapeHtml(m.since)}</div></div><div class="runtime" style="color:${escapeHtml(statusColor)}">${escapeHtml(m.runtime)}</div><div class="count-row"><div><span>OK</span><strong style="color:${m.part_count_color}">${m.prod_count}</strong></div><div><span>RW</span><strong class="rw">${m.rw_count}</strong></div><div><span>NOK</span><strong class="nok">${m.scrap_count}</strong></div><div><span>TARGET</span><strong>${m.target_label}</strong></div></div><div class="target-line"><span class="arrow ${m.arrow==='▼'?'down':'up'}">${m.arrow}</span></div><div class="oee-grid"><div><span>Availability</span><b>${m.availability}%</b></div><div><span>Productivity</span><b>${m.productivity}%</b></div><div><span>Quality</span><b>${m.quality}%</b></div><div class="oee-total"><span>OEE</span><b>${m.oee}%</b></div></div></div>`;}

async function loadProduction(){
 const d=document.getElementById("dashboard");
 const sec=section();
 const page=d?.dataset.machiningPage||"";
 let url=`/api/production/${encodeURIComponent(sec)}`;
 const q=new URLSearchParams({variant:selectedVariant()}); if(sec==="MACHINING" && page) q.set("page",page); url+=`?${q}`;
 const r=await fetch(url,{cache:"no-store"});
 if(!r.ok)return;
 const p=await r.json();
 refreshSeconds=Number(p.refresh_seconds||20);
 const prod=p.production||{};
 renderChart(prod);
 renderHourly(prod);
}
function renderChart(prod){const el=document.getElementById("production-chart");if(!el||!prod.items)return;const vmc=document.getElementById("dashboard")?.dataset.machiningPage||"";const titleScope=vmc==="VMC2"?"OP30 / OP40 / OP50 / VMC2":vmc; const variant=selectedVariant();const labels=prod.items.map(x=>x.label), actual=prod.items.map(x=>x.actual_till_hour), target=prod.items.map(x=>x.target_till_hour), ok=prod.items.map(x=>x.actual_till_hour);const data=[{name:"OK",x:labels,y:ok,type:"bar",marker:{color:"#00CC00"},text:ok,textposition:"inside"},{name:"Target",x:labels,y:target,type:"scatter",mode:"lines+markers",line:{color:"#FFA500",width:4,dash:"dot"},marker:{size:8,color:"#FFA500"},text:target,textposition:"top center"}];Plotly.react(el,data,{title:{text:`${titleScope?titleScope+" - ":""}${variant} - PRODUCTION PROGRESS BY PROCESS`,font:{size:28,color:"white"}},barmode:"stack",paper_bgcolor:"#162A3D",plot_bgcolor:"#162A3D",font:{color:"white"},height:Math.max(520,el.clientHeight||600),margin:{l:70,r:30,t:70,b:70},xaxis:{title:"PROCESS",tickfont:{size:14,color:"white"}},yaxis:{title:"COUNT",tickfont:{size:13,color:"white"}},legend:{orientation:"h"}},{responsive:true,displayModeBar:false});}
function renderHourly(prod){const table=document.getElementById("hourly-table");if(!table||!prod.items)return;const vmc=document.getElementById("dashboard")?.dataset.machiningPage||"";const titleScope=vmc==="VMC2"?"OP30 / OP40 / OP50 / VMC2":vmc; const variant=selectedVariant();const slots=prod.hour_slots||[];let h=`<thead><tr><th colspan="${prod.items.length*2+1}" class="vmc-hourly-heading">${titleScope?escapeHtml(titleScope)+" - ":""}PRODUCTION PROGRESS BY PROCESS (HOURLY)</th></tr><tr><th rowspan="2">TIME</th>`;prod.items.forEach(x=>{h+=`<th colspan="2">${escapeHtml(x.label)}</th>`});h+='</tr><tr>';prod.items.forEach(x=>{h+=`<th>${x.kind==="OK"?"OK":"A-JPH"}</th><th>${x.kind==="OK"?"NOK":"T-JPH"}</th>`});h+='</tr></thead><tbody>';
 h+='<tr class="total-row"><th>Total (Till hr.)</th>';prod.items.forEach(x=>{if(x.kind==="OK"){const nok=(x.hourly_nok||[]).slice(0,Number(prod.current_index)+1).reduce((a,b)=>a+(b||0),0);h+=`<td class="ok">${x.actual_till_hour}</td><td class="nok">${nok}</td>`;}else h+=`<td class="${x.actual_till_hour>=x.target_till_hour?'actual-good':'actual-bad'}">${x.actual_till_hour}</td><td>${x.target_till_hour}</td>`});h+='</tr>';
 slots.forEach((slot,i)=>{const current=i===Number(prod.current_index);h+=`<tr class="${current?'current-row':''}"><th>${slot}</th>`;prod.items.forEach(x=>{const v=x.hourly?.[i]||0;if(x.kind==="OK")h+=`<td class="ok">${v}</td><td class="nok">${x.hourly_nok?.[i]||0}</td>`;else h+=`<td class="${v>=(x.target_per_hour||0)?'actual-good':'actual-bad'}">${v}</td><td>${x.target_per_hour||0}</td>`});h+='</tr>';});h+='</tbody>';table.innerHTML=h;}

document.addEventListener("DOMContentLoaded",async()=>{updateClock();setInterval(updateClock,1000);document.querySelectorAll(".view-btn[data-view]").forEach(b=>b.addEventListener("click",()=>{setView(b.dataset.view);scheduleRotation();}));document.querySelectorAll(".variant-btn").forEach(b=>b.addEventListener("click",()=>setVariant(b.dataset.variant)));document.querySelectorAll(".variant-btn").forEach(b=>b.classList.toggle("active",b.dataset.variant===selectedVariant()));const rt=document.getElementById("rotate-toggle");rt?.addEventListener("click",()=>{autoRotate=!autoRotate;rt.textContent=`Auto Rotate: ${autoRotate?'ON':'OFF'}`;scheduleRotation();});await loadMachines();await loadProduction();scheduleRefresh();scheduleRotation();});
