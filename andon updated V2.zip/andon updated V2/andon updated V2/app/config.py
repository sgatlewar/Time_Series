"""Configuration extracted from the original TIU Streamlit Andon source.

The SQL/query dictionaries below are kept from the source rather than replaced
with guessed logic. Database credentials are intentionally read from .env.
"""

import os
from dotenv import load_dotenv

load_dotenv()

SQL_SERVER = os.getenv("SQL_SERVER", "10.105.17.60")
SQL_DATABASE = os.getenv("SQL_DATABASE", "apriso")
SQL_USER = os.getenv("SQL_USER", "FlxReader")
SQL_PASSWORD = os.getenv("SQL_PASSWORD", "FlxReader@#123")
SQL_DRIVER = os.getenv("SQL_DRIVER", "SQL Server")
SECRET_KEY = os.getenv("SECRET_KEY", "shubh")
DATA_REFRESH_SECONDS = int(os.getenv("DATA_REFRESH_SECONDS", "20"))

CONNECTION_STRING = (
    f"DRIVER=SQL Server;"
    f"SERVER={SQL_SERVER};"
    f"DATABASE={SQL_DATABASE};"
    f"UID={SQL_USER};"
    f"PWD={SQL_PASSWORD};"
    "Encrypt=no;"
)

#machine_queries = {'UC01_IP': "\n        SELECT ISNULL(SUM(PartQuantity),0)\n        FROM AT_Ultrasonic1process\n        WHERE CreatedOn BETWEEN ? AND GETDATE()\n          AND OutputScan = 1\n          AND Parts = 'M4ACN0111M00'\n    ", 'SPFL_IP': "\n        SELECT ISNULL(SUM(PartQuantity),0)\n        FROM AT_SprayFluxingProcess\n        WHERE CreatedOn BETWEEN ? AND GETDATE()\n          AND OutputScan = 1\n          AND UndoFlag = 0\n          AND Parts = 'M4ACN0111M00'\n    ", 'LW01': "\n        ;WITH EquipMap AS (\nSELECT W.WorkCenter, UC.Attribute_ AS EquipmentName\nFROM WORK_CENTER W\nJOIN UNIT_CHARACTERISTIC UC\nON UC.UnitID = W.UnitID\nAND UC.Characteristic = 'OutputStation'\nWHERE W.WorkCenter IN ('LW01')\n)\n\nSELECT  isnull(sum(1),0)\nFROM AT_LaserWeldingPLCData cp\nJOIN EQUIPMENT E ON E.ID = cp.EquipmentID\nJOIN EquipMap em ON em.WorkCenter = 'LW01' AND E.Equipment = em.EquipmentName\nWHERE cp.CreatedOn BETWEEN ? AND GETDATE()\n    ", 'RSHP': '\n        SELECT ISNULL(SUM(PartQuantity),0)\n            FROM AT_Reshapingprocess\n            WHERE CreatedOn BETWEEN ? AND GETDATE()\n            AND OutputScan = 1\n    ', 'CLNC': '\n        select ISNULL(sum(PartQuantity),0)\n            from AT_Clinchingprocess\n            where CreatedOn between ? and GETDATE()\n            And outputscan = 1 and active = 1\n    ', 'LW03': "\n        ;WITH EquipMap AS (\nSELECT W.WorkCenter, UC.Attribute_ AS EquipmentName\nFROM WORK_CENTER W\nJOIN UNIT_CHARACTERISTIC UC\nON UC.UnitID = W.UnitID\nAND UC.Characteristic = 'OutputStation'\nWHERE W.WorkCenter IN ('LW03')\n)\n\nSELECT  isnull(sum(1),0)\nFROM AT_LaserWeldingPLCData cp\nJOIN EQUIPMENT E ON E.ID = cp.EquipmentID\nJOIN EquipMap em ON em.WorkCenter = 'LW03' AND E.Equipment = em.EquipmentName\nWHERE cp.CreatedOn BETWEEN ? AND GETDATE()\n    \n    ", 'LW02': "\n        ;WITH EquipMap AS (\nSELECT W.WorkCenter, UC.Attribute_ AS EquipmentName\nFROM WORK_CENTER W\nJOIN UNIT_CHARACTERISTIC UC\nON UC.UnitID = W.UnitID\nAND UC.Characteristic = 'OutputStation'\nWHERE W.WorkCenter IN ('LW02')\n)\n\nSELECT  isnull(sum(1),0)\nFROM AT_LaserWeldingPLCData cp\nJOIN EQUIPMENT E ON E.ID = cp.EquipmentID\nJOIN EquipMap em ON em.WorkCenter = 'LW02' AND E.Equipment = em.EquipmentName\nWHERE cp.CreatedOn BETWEEN ? AND GETDATE()\n    ", 'SHBL': '\n        select isnull(sum(partQuantity),0) from AT_ShotBlastingprocess where createdon between ? and GETDATE() and OutputScan = 1\n    ', 'ALT1_01': '\n        select isnull(sum(partQuantity),0) from AT_ALT1_Process where createdon between ? and GETDATE() and OutputScan = 1 and IsRejected = 0 and Active = 1\n\n    ', 'BRZN_FX': '\n    select isnull(sum(PartQuantity),0) from AT_BrazingProcess where createdon between ? and GETDATE() and OutputScan = 1 and Active = 1\n    ', 'QLW01': "\n;WITH EquipMap AS (\n    SELECT W.WorkCenter,\n           UC.Attribute_ AS EquipmentName\n    FROM WORK_CENTER W\n    JOIN UNIT_CHARACTERISTIC UC\n        ON UC.UnitID = W.UnitID\n       AND UC.Characteristic = 'OutputStation'\n    WHERE W.WorkCenter = 'LW01'\n)\nSELECT ISNULL((\n    SELECT COUNT(*)\n    FROM AT_LaserWeldingPLCData cp\n    JOIN EQUIPMENT E\n        ON E.ID = cp.EquipmentID\n    JOIN EquipMap em\n        ON em.WorkCenter = 'LW01'\n       AND E.Equipment = em.EquipmentName\n    WHERE cp.CreatedOn BETWEEN ? AND GETDATE()\n),0)\n", 'QLW02': "\n    ;WITH EquipMap AS (\n        SELECT W.WorkCenter,\n               UC.Attribute_ AS EquipmentName\n        FROM WORK_CENTER W\n        JOIN UNIT_CHARACTERISTIC UC\n            ON UC.UnitID = W.UnitID\n           AND UC.Characteristic = 'OutputStation'\n        WHERE W.WorkCenter = 'LW02'\n    )\n    SELECT ISNULL((\n        SELECT COUNT(*)\n        FROM AT_LaserWeldingPLCData cp\n        JOIN EQUIPMENT E\n            ON E.ID = cp.EquipmentID\n        JOIN EquipMap em\n            ON em.WorkCenter = 'LW02'\n           AND E.Equipment = em.EquipmentName\n        WHERE cp.CreatedOn BETWEEN ? AND GETDATE()\n    ),0)\n    ", 'QLW03': '\n    SELECT SUM(D.Quantity)\n    FROM DISPOSITION D\n    WHERE D.OprSequenceNo = 15\n    AND D.Status IN (14,4)\n    AND D.CreatedOn BETWEEN ? AND GETDATE()\n    ', 'QALT': "\n    SELECT ISNULL(COUNT(cp.Quantity),0)\n    FROM AT_QUALITY_SAMPLE cp\n    WHERE WorkCenter LIKE 'ALT1%'\n      AND Status = 'QAOK'\n      AND cp.CreatedOn BETWEEN ? AND GETDATE()\n    "}


machine_queries = {

    # ==========================================================
    # INPUT / PRODUCTION COUNTS
    # ==========================================================

    "UC01_IP": """
        SELECT ISNULL(SUM(PartQuantity), 0)
        FROM AT_Ultrasonic1process
        WHERE CreatedOn BETWEEN ? AND GETDATE()
          AND OutputScan = 1
          AND partsdesc like '%TOP COVER (AP)%'
    """,

    "SPFL_IP": """
        SELECT ISNULL(SUM(PartQuantity), 0)
        FROM AT_SprayFluxingProcess
        WHERE CreatedOn BETWEEN ? AND GETDATE()
          AND OutputScan = 1
          AND UndoFlag = 0
          AND partsdesc like '%TOP COVER (AP)%'
    """,

    "RSHP": """
        SELECT ISNULL(SUM(PartQuantity), 0)
        FROM AT_ReshapingProcess
        WHERE CreatedOn BETWEEN ? AND GETDATE()
          AND OutputScan = 1
    """,

    "CLNC": """
        SELECT ISNULL(SUM(PartQuantity), 0)
        FROM AT_ClinchingProcess
        WHERE CreatedOn BETWEEN ? AND GETDATE()
          AND OutputScan = 1
          AND Active = 1
    """,

    "SHBL": """
        SELECT ISNULL(SUM(PartQuantity), 0)
        FROM AT_ShotBlastingProcess
        WHERE CreatedOn BETWEEN ? AND GETDATE()
          AND OutputScan = 1
    """,

    "ALT1_01": """
        SELECT ISNULL(SUM(PartQuantity), 0)
        FROM AT_ALT1_Process
        WHERE CreatedOn BETWEEN ? AND GETDATE()
          AND OutputScan = 1
          AND IsRejected = 0
          AND Active = 1
    """,

    "BRZN_FX": """
        SELECT ISNULL(SUM(PartQuantity), 0)
        FROM AT_BrazingProcess
        WHERE CreatedOn BETWEEN ? AND GETDATE()
          AND OutputScan = 1
          AND Active = 1
    """,

    # ==========================================================
    # LASER WELDING PRODUCTION COUNTS
    # ==========================================================

    "LW01": """
        ;WITH EquipMap AS (
            SELECT W.WorkCenter,
                   UC.Attribute_ AS EquipmentName
            FROM WORK_CENTER W
            JOIN UNIT_CHARACTERISTIC UC
                ON UC.UnitID = W.UnitID
               AND UC.Characteristic = 'OutputStation'
            WHERE W.WorkCenter = 'LW01'
        )

        SELECT ISNULL(COUNT(*), 0)
        FROM AT_LaserWeldingPLCData CP
        JOIN EQUIPMENT E
            ON E.ID = CP.EquipmentID
        JOIN EquipMap EM
            ON EM.WorkCenter = 'LW01'
           AND E.Equipment = EM.EquipmentName
        WHERE CP.CreatedOn BETWEEN ? AND GETDATE()
    """,

    "LW02": """
        ;WITH EquipMap AS (
            SELECT W.WorkCenter,
                   UC.Attribute_ AS EquipmentName
            FROM WORK_CENTER W
            JOIN UNIT_CHARACTERISTIC UC
                ON UC.UnitID = W.UnitID
               AND UC.Characteristic = 'OutputStation'
            WHERE W.WorkCenter = 'LW02'
        )

        SELECT ISNULL(COUNT(*), 0)
        FROM AT_LaserWeldingPLCData CP
        JOIN EQUIPMENT E
            ON E.ID = CP.EquipmentID
        JOIN EquipMap EM
            ON EM.WorkCenter = 'LW02'
           AND E.Equipment = EM.EquipmentName
        WHERE CP.CreatedOn BETWEEN ? AND GETDATE()
    """,

    "LW03": """
        ;WITH EquipMap AS (
            SELECT W.WorkCenter,
                   UC.Attribute_ AS EquipmentName
            FROM WORK_CENTER W
            JOIN UNIT_CHARACTERISTIC UC
                ON UC.UnitID = W.UnitID
               AND UC.Characteristic = 'OutputStation'
            WHERE W.WorkCenter = 'LW03'
        )

        SELECT ISNULL(COUNT(*), 0)
        FROM AT_LaserWeldingPLCData CP
        JOIN EQUIPMENT E
            ON E.ID = CP.EquipmentID
        JOIN EquipMap EM
            ON EM.WorkCenter = 'LW03'
           AND E.Equipment = EM.EquipmentName
        WHERE CP.CreatedOn BETWEEN ? AND GETDATE()
    """,

    # ==========================================================
    # QUALITY COUNTS
    # ==========================================================

    "QLW01": """
        ;WITH EquipMap AS (
            SELECT W.WorkCenter,
                   UC.Attribute_ AS EquipmentName
            FROM WORK_CENTER W
            JOIN UNIT_CHARACTERISTIC UC
                ON UC.UnitID = W.UnitID
               AND UC.Characteristic = 'OutputStation'
            WHERE W.WorkCenter = 'LW01'
        )

        SELECT ISNULL(COUNT(*), 0)
        FROM AT_LaserWeldingPLCData CP
        JOIN EQUIPMENT E
            ON E.ID = CP.EquipmentID
        JOIN EquipMap EM
            ON EM.WorkCenter = 'LW01'
           AND E.Equipment = EM.EquipmentName
        WHERE CP.CreatedOn BETWEEN ? AND GETDATE()
    """,

    "QLW02": """
        ;WITH EquipMap AS (
            SELECT W.WorkCenter,
                   UC.Attribute_ AS EquipmentName
            FROM WORK_CENTER W
            JOIN UNIT_CHARACTERISTIC UC
                ON UC.UnitID = W.UnitID
               AND UC.Characteristic = 'OutputStation'
            WHERE W.WorkCenter = 'LW02'
        )

        SELECT ISNULL(COUNT(*), 0)
        FROM AT_LaserWeldingPLCData CP
        JOIN EQUIPMENT E
            ON E.ID = CP.EquipmentID
        JOIN EquipMap EM
            ON EM.WorkCenter = 'LW02'
           AND E.Equipment = EM.EquipmentName
        WHERE CP.CreatedOn BETWEEN ? AND GETDATE()
    """,

    "QLW03": """
        SELECT ISNULL(SUM(D.Quantity), 0)
        FROM DISPOSITION D
        WHERE D.OprSequenceNo = 15
          AND D.Status IN (14, 4)
          AND D.CreatedOn BETWEEN ? AND GETDATE()
    """,

    "QALT": """
        SELECT ISNULL(COUNT(CP.Quantity), 0)
        FROM AT_QUALITY_SAMPLE CP
        WHERE CP.WorkCenter LIKE 'ALT1%'
          AND CP.Status = 'QAOK'
          AND CP.CreatedOn BETWEEN ? AND GETDATE()
    """
}



rework_queries = {'UC01_IP': "\n    SELECT ISNULL(SUM(PartQuantity),0)\n    FROM AT_Ultrasonic1process\n    WHERE CreatedOn BETWEEN ? AND GETDATE()\n      AND OutputScan = 1\n      AND WipOrderNo LIKE '%R00%'\n      AND Parts = 'M4ACN0111M00'\n    ", 'SPFL_IP': "\n    SELECT ISNULL(SUM(PartQuantity),0)\n    FROM AT_SprayFluxingProcess\n    WHERE CreatedOn BETWEEN ? AND GETDATE()\n      AND OutputScan = 1\n      AND WipOrderNo LIKE '%R00%'\n      AND Parts = 'M4ACN0111M00'\n    ", 'LW01': "\n    SELECT ISNULL(COUNT(*),0)\n    FROM AT_LaserWeldingPLCData\n    WHERE CreatedOn BETWEEN ? AND GETDATE()\n      AND WipOrderNo LIKE '%R00%'\n    ", 'LW02': "\n    SELECT ISNULL(COUNT(*),0)\n    FROM AT_LaserWeldingPLCData\n    WHERE CreatedOn BETWEEN ? AND GETDATE()\n      AND WipOrderNo LIKE '%R00%'\n    ", 'LW03': "\n    SELECT ISNULL(COUNT(*),0)\n    FROM AT_LaserWeldingPLCData\n    WHERE CreatedOn BETWEEN ? AND GETDATE()\n      AND WipOrderNo LIKE '%R00%'\n    ", 'CLNC': "\n    SELECT ISNULL(SUM(PartQuantity),0)\n    FROM AT_Clinchingprocess\n    WHERE CreatedOn BETWEEN ? AND GETDATE()\n      AND OutputScan = 1\n      AND Active = 1\n      AND WipOrderNo LIKE '%R00%'\n    ", 'RSHP': "\n    SELECT ISNULL(SUM(PartQuantity),0)\n    FROM AT_Reshapingprocess\n    WHERE CreatedOn BETWEEN ? AND GETDATE()\n      AND OutputScan = 1\n      AND WipOrderNo LIKE '%R00%'\n    ", 'SHBL': "\n    SELECT ISNULL(SUM(PartQuantity),0)\n    FROM AT_ShotBlastingprocess\n    WHERE CreatedOn BETWEEN ? AND GETDATE()\n      AND OutputScan = 1\n      AND WipOrderNo LIKE '%R00%'\n    ", 'ALT1_01': "\n    SELECT ISNULL(SUM(PartQuantity),0)\n    FROM AT_ALT1_Process\n    WHERE CreatedOn BETWEEN ? AND GETDATE()\n      AND OutputScan = 1\n      AND IsRejected = 0\n      AND Active = 1\n      AND WipOrderNo LIKE '%R00%'\n    ", 'BRZN_FX': "\n    SELECT ISNULL(SUM(PartQuantity),0)\n    FROM AT_BrazingProcess\n    WHERE CreatedOn BETWEEN ? AND GETDATE()\n      AND OutputScan = 1\n      AND Active = 1\n      AND WipOrderNo LIKE '%R00%'\n    ", 'QALT': "\n    SELECT ISNULL(COUNT(*),0)\n    FROM AT_QUALITY_SAMPLE\n    WHERE WorkCenter LIKE 'ALT1%'\n      AND Status = 'Rework'\n      AND CreatedOn BETWEEN ? AND GETDATE()\n    "}

scrap_queries = {'QALT': "\n    SELECT ISNULL(COUNT(*),0)\n    FROM AT_QUALITY_SAMPLE\n    WHERE WorkCenter LIKE 'ALT1%'\n      AND Status = 'Scrap'\n      AND CreatedOn BETWEEN ? AND GETDATE()\n    "}

machine_display = {'UC01_IP': 'Ultrasonic Cleaning 01', 'SPFL_IP': 'Spray Fluxing', 'LW01': 'Laser Welding 01', 'QLW01': 'LW01 Q-Gate', 'CLNC': 'Clinching', 'LW02': 'Laser Welding 02', 'QLW02': 'LW02 Q-Gate', 'LW03': 'Laser Welding 03', 'QLW03': 'LW03 Q-Gate', 'BRZN_FX': 'Brazing', 'SHBL': 'Shot Blasting', 'RSHP': 'Restriking','QRSHP':'Q-Gate RSHP', 'ALT1_01': 'Air Leak Testing 01', 'QALT': 'Q-Gate ALT1'}

machining_display = {**{f'OP_10_{i:02d}': f'OP-10_{i:02d}' for i in range(1, 9)}, **{f'OP_20_{i:02d}': f'OP-20_{i:02d}' for i in range(1, 9)}, **{f'OP_30_{i:02d}': f'OP-30_{i:02d}' for i in range(1, 20)}, **{f'OP_40_{i:02d}': f'OP-40_{i:02d}' for i in range(1, 21)}, **{f'OP_50_{i:02d}': f'OP-50_{i:02d}' for i in range(1, 4)}}
machining_display['REVT'] = 'Riveting'


machine_queries['REVT'] = """
        SELECT ISNULL(COUNT(*),0)
        FROM AT_RivetingProcess
        WHERE CreatedOn BETWEEN ? AND GETDATE()
          AND OutputScan = 1
          AND Active = 1
          AND WipOrderNo LIKE '%R00%'
    """





rework_queries['REVT'] = """
        SELECT ISNULL(COUNT(*),0)
        FROM AT_RivetingProcess
        WHERE CreatedOn BETWEEN ? AND GETDATE()
          AND OutputScan = 1 AND Active = 1 AND IsRejected = 1
          AND WipOrderNo LIKE '%R00%'
    """
scrap_queries['REVT'] = """
        SELECT ISNULL(COUNT(*),0)
        FROM AT_RivetingProcess
        WHERE CreatedOn BETWEEN ? AND GETDATE()
          AND OutputScan = 1
          AND Active = 1
          AND IsRejected = 1
    """

post_machining_queries = {'SG': "\n    SELECT ISNULL(COUNT(cp.PartQuantity),0)\n    FROM AT_ColdPlateLoadingProcess cp\n    WHERE cp.Active = 1\n      AND cp.OutputScan = 1\n      AND LEN(ISNULL(cp.SerialNo,'')) > 0\n      AND ISNULL(cp.IsRejected,0) <> 1\n      AND cp.CreatedOn BETWEEN ? AND GETDATE()\n    ", 'UC2': "\n    SELECT ISNULL(COUNT(cp.PartQuantity),0)\n    FROM AT_Ultrasonic2process cp\n    WHERE cp.Active = 1\n      AND LEN(ISNULL(cp.SerialNo,'')) > 0\n      AND ISNULL(cp.IsRejected,0) <> 1\n      AND cp.CreatedOn BETWEEN ? AND GETDATE()\n    ", 'EOL': "\n    SELECT ISNULL(COUNT(DISTINCT(cp.SerialNumber)),0)\n    FROM AT_TestingLineProcess cp\n    WHERE cp.Active = 1\n      AND LEN(ISNULL(cp.SerialNumber,'')) > 0\n      AND LEN(ISNULL(cp.LM2SerialNumber,'')) > 0\n      AND LEN(ISNULL(cp.WipOrderNo,'')) > 0\n      AND cp.CreatedOn BETWEEN ? AND GETDATE()\n    ", 'PACK': '\n    SELECT ISNULL(COUNT(cp.ID),0)\n    FROM AT_PackagingProcess cp\n    WHERE cp.SerialLabelStatus = 1\n      AND cp.Active = 1\n      AND cp.CreatedOn BETWEEN ? AND GETDATE()\n    '}

post_machining_nok_queries = {'SG': '\n    SELECT ISNULL(COUNT(*),0)\n    FROM AT_ColdPlateLoadingProcess\n    WHERE Active = 1\n      AND OutputScan = 1\n      AND IsRejected = 1\n      AND CreatedOn BETWEEN ? AND GETDATE()\n    ', 'UC2': '\n    SELECT ISNULL(COUNT(*),0)\n    FROM AT_Ultrasonic2Process\n    WHERE Active = 1\n      AND IsRejected = 1\n      AND CreatedOn BETWEEN ? AND GETDATE()\n    ', 'EOL': '\n    SELECT ISNULL(COUNT(*),0)\n    FROM AT_TestingLineProcess\n    WHERE Active = 1\n      AND IsRejection = 1\n      AND CreatedOn BETWEEN ? AND GETDATE()\n    ', 'PACK': '\n    SELECT ISNULL(COUNT(*),0)\n    FROM AT_PackagingProcess\n    WHERE Active = 1\n      AND IsRejection = 1\n      AND CreatedOn BETWEEN ? AND GETDATE()\n    '}

post_machining_wc = {'SG': 'SG', 'UC2': 'UC02', 'EOL': 'EOL', 'PACK': 'PACK'}

post_machining_rework_queries = {'SG': "\n    SELECT ISNULL(COUNT(cp.PartQuantity),0)\n    FROM AT_ColdPlateLoadingProcess cp\n    WHERE cp.Active = 1\n      AND cp.OutputScan = 1\n      AND LEN(ISNULL(cp.SerialNo,'')) > 0\n      AND cp.WipOrderNo LIKE '%R00%'\n      AND cp.CreatedOn BETWEEN ? AND GETDATE()\n    ", 'UC2': "\n    SELECT ISNULL(COUNT(cp.PartQuantity),0)\n    FROM AT_Ultrasonic2process cp\n    WHERE cp.Active = 1\n      AND LEN(ISNULL(cp.SerialNo,'')) > 0\n      AND cp.WipOrderNo LIKE '%R00%'\n      AND cp.CreatedOn BETWEEN ? AND GETDATE()\n    ", 'EOL': "\n    SELECT ISNULL(COUNT(DISTINCT(cp.SerialNumber)),0)\n    FROM AT_TestingLineProcess cp\n    WHERE cp.Active = 1\n      AND LEN(ISNULL(cp.SerialNumber,'')) > 0\n      AND LEN(ISNULL(cp.LM2SerialNumber,'')) > 0\n      AND LEN(ISNULL(cp.WipOrderNo,'')) > 0\n      AND cp.WipOrderNo LIKE '%R00%'\n      AND cp.CreatedOn BETWEEN ? AND GETDATE()\n    ", 'PACK': "\n    SELECT ISNULL(COUNT(cp.ID),0)\n    FROM AT_PackagingProcess cp\n    WHERE cp.SerialLabelStatus = 1\n      AND cp.Active = 1\n      AND cp.WipOrderNo LIKE '%R00%'\n      AND cp.CreatedOn BETWEEN ? AND GETDATE()\n    "}

post_machining_display = {'SG': 'Soldering and Glueing', 'UC2': 'Ultrasonic Cleaning 02', 'EOL': 'End of Line Testing', 'PACK': 'Packaging'}

VMC_QGATE_TARGET = int(os.getenv("VMC_QGATE_TARGET", "0"))

# Product variants. Variant is determined from WipOrderNo prefixes.
# P-prefix applies from the beginning of the line through VMC1/QVMC1.
# Q-prefix applies from SLGL through packaging.
SUPPORTED_VARIANTS = ("Matrix", "Banana Mini", "Kiwi Mini")
VARIANT_P_PREFIX = {"Matrix": "P00", "Banana Mini": "P01", "Kiwi Mini": "P02"}
VARIANT_Q_PREFIX = {"Matrix": "Q00", "Banana Mini": "Q01", "Kiwi Mini": "Q02"}

# Station membership used by tiles/reports.
VARIANT_STATIONS = {
    "Matrix": {
        "PRE_MACHINING": ["UC01_IP","SPFL_IP","LW01","QLW01","CLNC","LW02","QLW02","LW03","QLW03","BRZN_FX","SHBL","RSHP","ALT1_01","QALT"],
        "MACHINING": ["OP_10_02","OP_10_03","OP_10_04","OP_10_05","OP_10_06","OP_20_02","OP_20_03","OP_20_04","OP_20_05","OP_20_06","OP_30_01","OP_30_02","OP_30_03","OP_30_04","OP_30_05","OP_30_06","OP_30_07","OP_30_08","OP_30_09","OP_30_10","OP_30_11","OP_30_12","OP_30_13","OP_30_14","OP_30_15","OP_30_16","OP_30_17","OP_40_01","OP_40_02","OP_40_03","OP_40_04","OP_40_05","OP_40_06","OP_40_07","OP_40_08","OP_40_09","OP_40_10","OP_40_11","OP_40_12","OP_40_13","OP_40_14","OP_40_15","OP_40_16","OP_40_17","OP_50_01","OP_50_02","OP_50_03"],
        "POST_MACHINING": ["SG","UC2","EOL","PACK"],
    },
    "Banana Mini": {
        "PRE_MACHINING": ["UC01_IP","SPFL_IP","LW01","QLW01","CLNC","LW02","QLW02","LW03","QLW03","BRZN_FX","SHBL","LM","RSHP","QRSHP"],
        "MACHINING": ["OP_10_08","OP_20_08","OP_30_18","OP_30_19","OP_40_18","OP_40_19","OP_40_20","OP_50/60_01","OP_50/60_02","OP_50/60_03"],
        "POST_MACHINING": ["SG","UC2","EOL","PACK"],
    },
    "Kiwi Mini": {
        "PRE_MACHINING": ["UC01_IP","SPFL_IP","LW01","QLW01","CLNC","LW02","QLW02","LW03","QLW03","BRZN_FX","SHBL","LM","RSHP","QRSHP"],
        "MACHINING": ["OP_10_08","OP_20_08","OP_30_18","OP_30_19","OP_40_18","OP_40_19","OP_40_20","OP_50/60_01","OP_50/60_02","OP_50/60_03","REVT"],
        "POST_MACHINING": ["SG","UC2","EOL","PACK"],
    },
}


targets = {'UC01_IP': 100, 'SPFL_IP': 100, 'LW01': 100, 'CLNC': 100, 'LW02': 100, 'LW03': 100, 'SHBL': 100, 'RSHP': 100, 'ALT1_01': 100, 'BRZN_FX': 100, 'QLW01': 100, 'QLW02': 100, 'QLW03': 100, 'QALT': 100}

post_targets = {'SG': 100, 'UC2': 100, 'EOL': 100, 'PACK': 100}
targets['REVT'] = 100

graph_labels = {'UC01_IP': 'UC1', 'SPFL_IP': 'SF', 'LW01': 'LW1', 'CLNC': 'CLNC', 'LW02': 'LW2', 'LW03': 'LW3', 'SHBL': 'SB', 'RSHP': 'REST', 'ALT1_01': 'ALT1','LM':'LM01', 'BRZN_FX': 'BRAZ', 'QLW01': 'QLW1', 'QLW02': 'QLW2', 'QLW03': 'QLW3', 'QALT': 'QALT'}


USERS = {'Premachining': {'password': '123', 'role': 'L1'}, 'Machining': {'password': '123', 'role': 'L1'}, 'Postmachining': {'password': '123', 'role': 'L1'}, 'Shubham': {'password': '123', 'role': 'L2'}}

