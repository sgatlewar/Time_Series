import pyodbc
from app.config import CONNECTION_STRING

def get_connection():
    return pyodbc.connect(CONNECTION_STRING, autocommit=True)

def scalar(cursor, query, *params):
    cursor.execute(query, *params)
    row = cursor.fetchone()
    return int(row[0]) if row and row[0] is not None else 0
