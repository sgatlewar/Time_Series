from __future__ import annotations

import json
import os
import threading
from datetime import datetime
from pathlib import Path

from app.config import DATA_REFRESH_SECONDS
from app.services.db import get_connection
from app.services.dashboard_service import (
    load_downtime_data,
    load_mes_bypass_data,
    load_machine_data,
    load_machining_data,
    load_post_machining_data,
    _variant_machine_rows,
    load_production_data,
)

BASE_DIR = Path(__file__).resolve().parents[2]
DATA_DIR = BASE_DIR / "data"
JSON_FILE = DATA_DIR / "andon_data.json"
TMP_FILE = DATA_DIR / "andon_data.json.tmp"

_THREAD = None
_STOP = threading.Event()


def _empty_snapshot():
    return {
        "version": 1,
        "updated_at": None,
        "refresh_seconds": DATA_REFRESH_SECONDS,
        "status": "NOT_INITIALIZED",
        "sections": {
            "PRE_MACHINING": [],
            "MACHINING": [],
            "POST_MACHINING": [],
        },
        "production": {
            "PRE_MACHINING": {},
            "MACHINING": {},
            "POST_MACHINING": {},
        },
        "errors": {},
    }


def read_snapshot():
    if not JSON_FILE.exists():
        return _empty_snapshot()
    try:
        with JSON_FILE.open("r", encoding="utf-8") as fh:
            value = json.load(fh)
        return value if isinstance(value, dict) else _empty_snapshot()
    except (OSError, json.JSONDecodeError):
        return _empty_snapshot()


def _write_snapshot(payload):
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    with TMP_FILE.open("w", encoding="utf-8") as fh:
        json.dump(payload, fh, ensure_ascii=False, separators=(",", ":"))
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(TMP_FILE, JSON_FILE)


def refresh_from_sql():
    """Fetch SQL data, calculate all dashboard values, then overwrite JSON."""
    conn = None
    sections = {
        "PRE_MACHINING": [],
        "MACHINING": [],
        "POST_MACHINING": [],
    }
    errors = {}
    success = 0
    production = {}

    try:
        conn = get_connection()
        # These are shared by all sections so we do not repeat the same SQL.
        downtime = load_downtime_data(conn)
        mes_bypass = load_mes_bypass_data(conn)

        for section, loader in (
            ("PRE_MACHINING", load_machine_data),
            ("MACHINING", load_machining_data),
            ("POST_MACHINING", load_post_machining_data),
        ):
            try:
                if section in {"PRE_MACHINING", "POST_MACHINING"}:
                    sections[section] = _variant_machine_rows(loader, section, conn, downtime, mes_bypass)
                else:
                    sections[section] = loader(
                        conn=conn,
                        downtime_df=downtime,
                        mes_map=mes_bypass,
                    )
                success += 1
            except Exception as exc:
                errors[section] = f"{type(exc).__name__}: {exc}"

        try:
            production = load_production_data(conn)
        except Exception as exc:
            errors["PRODUCTION"] = f"{type(exc).__name__}: {exc}"
    except Exception as exc:
        errors["DATABASE"] = f"{type(exc).__name__}: {exc}"
    finally:
        if conn is not None:
            conn.close()

    status = "OK" if success == 3 else "PARTIAL" if success else "ERROR"
    payload = {
        "version": 1,
        "updated_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "refresh_seconds": DATA_REFRESH_SECONDS,
        "status": status,
        "sections": sections,
        "production": production,
        "errors": errors,
    }
    _write_snapshot(payload)
    return payload


def _worker():
    while not _STOP.is_set():
        try:
            refresh_from_sql()
        except Exception:
            pass
        _STOP.wait(max(1, DATA_REFRESH_SECONDS))


def start_refresh_worker():
    global _THREAD
    if _THREAD is not None and _THREAD.is_alive():
        return
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    _STOP.clear()
    _THREAD = threading.Thread(
        target=_worker,
        name="TIU-Andon-JSON-Refresh",
        daemon=True,
    )
    _THREAD.start()


def stop_refresh_worker():
    _STOP.set()


def get_snapshot():
    # Dashboard reads only this local JSON file.
    return read_snapshot()


def get_machines(section):
    return get_snapshot().get("sections", {}).get(section.upper(), [])


def get_machine(section, machine_code):
    code = str(machine_code).upper()
    for row in get_machines(section):
        if str(row.get("machine", "")).upper() == code:
            return row
    return None
