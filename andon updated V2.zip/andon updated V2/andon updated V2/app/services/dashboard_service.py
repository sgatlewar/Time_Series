from datetime import datetime
from pathlib import Path
import pandas as pd

from app.config import (
    machine_display, machining_display, post_machining_display,
    machine_queries, rework_queries, scrap_queries,
    post_machining_queries, post_machining_nok_queries,
    post_machining_rework_queries, targets, post_targets, VMC_QGATE_TARGET,
    graph_labels, DATA_REFRESH_SECONDS, SUPPORTED_VARIANTS, VARIANT_STATIONS, VARIANT_P_PREFIX, VARIANT_Q_PREFIX,
)
from app.services.db import get_connection, scalar


def shift_start_utc():
    return datetime.strptime(
        datetime.now().strftime("%Y-%m-%d") + " 01:00:00",
        "%Y-%m-%d %H:%M:%S",
    )


def shift_start_ist():
    return datetime.strptime(
        datetime.now().strftime("%Y-%m-%d") + " 06:30:00",
        "%Y-%m-%d %H:%M:%S",
    )


def get_elapsed_time(start_time):
    if start_time is None or pd.isna(start_time):
        return "00:00:00"
    seconds = max(0, int((datetime.now() - start_time).total_seconds()))
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    seconds %= 60
    return f"{hours:02}:{minutes:02}:{seconds:02}"


def format_status(status):
    status = str(status or "").strip().upper()
    if "MES BYPASS" in status:
        return "MES Bypass"
    if "OPERATIONAL_BREAKDOWN" in status:
        return "Operational Breakdown"
    if "BREAKDOWN" in status:
        return "Breakdown"
    return "Operational"


def get_status_color(status):
    status = format_status(status)
    return {
        "MES Bypass": "#7B1FA2",
        "Operational Breakdown": "#FF8C00",
        "Breakdown": "#D50000",
        "Operational": "#138A36",
    }.get(status, "#138A36")


def _empty_downtime_frame():
    return pd.DataFrame(columns=[
        "WorkCenter", "DowntimeStartTime_ist", "DowntimeEndTime_ist",
        "LastUpdateOn_ist", "Type",
    ])


def load_downtime_data(conn):
    cursor = conn.cursor()
    cursor.execute("""
        SELECT
            WorkCenter,
            DATEADD(MINUTE,330,DowntimeStartTime) AS DowntimeStartTime_ist,
            DATEADD(MINUTE,330,DowntimeEndTime) AS DowntimeEndTime_ist,
            DATEADD(MINUTE,330,LastUpdateOn) AS LastUpdateOn_ist,
            Type
        FROM AT_DowntimeData
        WHERE DowntimeStartTime >= ?
    """, shift_start_utc())
    rows = cursor.fetchall()
    return pd.DataFrame.from_records(
        rows, columns=[c[0] for c in cursor.description]
    ) if rows else _empty_downtime_frame()


def _latest_downtime_for_machine(downtime_df, machine):
    if downtime_df is None or downtime_df.empty:
        return None
    work = downtime_df["WorkCenter"].fillna("").astype(str)
    rows = downtime_df[work.str.contains(str(machine), regex=False, na=False)]
    if rows.empty:
        return None
    return rows.sort_values("DowntimeStartTime_ist", ascending=False).iloc[0]


def load_mes_bypass_data(conn):
    """Load the latest MES bypass record for PRE and POST machines in one SQL call.

    A bypass is active when StartTime is present and EndTime is NULL.
    Post-machine UC2 is stored as UC02 in AT_MESBypassData, so the configured
    post_machining_wc mapping is used.
    """
    from app.config import post_machining_wc

    mapping = {}
    for machine in machine_display:
        mapping[machine] = machine
    for machine, wc in post_machining_wc.items():
        mapping[machine] = wc

    workcenters = list(dict.fromkeys(mapping.values()))
    if not workcenters:
        return {}

    placeholders = ",".join("?" for _ in workcenters)
    cursor = conn.cursor()
    cursor.execute(f"""
        WITH Latest AS (
            SELECT
                WorkCenter,
                DATEADD(MINUTE,330,StartTime) AS StartTime_IST,
                DATEADD(MINUTE,330,EndTime) AS EndTime_IST,
                ID,
                ROW_NUMBER() OVER (
                    PARTITION BY WorkCenter
                    ORDER BY ID DESC
                ) AS rn
            FROM AT_MESBypassData
            WHERE WorkCenter IN ({placeholders})
        )
        SELECT WorkCenter, StartTime_IST, EndTime_IST, ID
        FROM Latest
        WHERE rn = 1
    """, *workcenters)

    by_wc = {}
    for row in cursor.fetchall():
        by_wc[str(row.WorkCenter).strip()] = row

    result = {}
    for machine, wc in mapping.items():
        row = by_wc.get(str(wc).strip())
        if row is not None:
            result[machine] = row
    return result


def _active_bypass(mes_row):
    if mes_row is None:
        return False
    start = getattr(mes_row, "StartTime_IST", None)
    end = getattr(mes_row, "EndTime_IST", None)
    return start is not None and not pd.isna(start) and (end is None or pd.isna(end))


def _status_for_machine(downtime_df, mes_map, machine, force_shift=False):
    #print(machine)
    shift = shift_start_ist()
    status = "Operational"
    since = shift.strftime("%d-%b-%y %H:%M:%S")
    runtime = get_elapsed_time(shift)

    # MES bypass has priority over downtime, matching the intended Andon state.
    mes_row = mes_map.get(machine)
    if _active_bypass(mes_row):
        status = "MES BYPASS"
        since = mes_row.StartTime_IST.strftime("%d-%b-%y %H:%M:%S")
        runtime = get_elapsed_time(mes_row.StartTime_IST)
    elif not force_shift:
        row = _latest_downtime_for_machine(downtime_df, machine)
        if row is not None:
            end = row.get("DowntimeEndTime_ist")
            start = row.get("DowntimeStartTime_ist")
            if pd.isna(end):
                dtype = str(row.get("Type", "")).upper()
                status = (
                    "BREAKDOWN"
                    if dtype == "BREAKDOWNTIME"
                    else "OPERATIONAL_BREAKDOWN"
                )
                if pd.notna(start):
                    since = start.strftime("%d-%b-%y %H:%M:%S")
                    runtime = get_elapsed_time(start)
            else:
                since = end.strftime("%d-%b-%y %H:%M:%S")
                runtime = get_elapsed_time(end)

    if machine == "BRZN_FX" and not _active_bypass(mes_row):
        since = shift.strftime("%d-%b-%Y %I:%M:%S %p")
        runtime = get_elapsed_time(shift)

    return format_status(status), since, runtime, get_status_color(status)


def calculate_availability(machine, conn=None, downtime_df=None):
    shift_ist = shift_start_ist()
    planned_minutes = max((datetime.now() - shift_ist).total_seconds() / 60, 0)
    if planned_minutes <= 0:
        return 0.0, 0.0

    if downtime_df is None:
        if conn is None:
            conn = get_connection()
            try:
                downtime_df = load_downtime_data(conn)
            finally:
                conn.close()
        else:
            downtime_df = load_downtime_data(conn)

    total_downtime = 0.0
    if downtime_df is not None and not downtime_df.empty:
        work = downtime_df["WorkCenter"].fillna("").astype(str)
        rows = downtime_df[
            work.str.contains(str(machine), regex=False, na=False)
            & downtime_df["Type"].fillna("").astype(str).str.lower().eq("breakdowntime")
        ]
        for _, row in rows.iterrows():
            start = row.get("DowntimeStartTime_ist")
            end = row.get("DowntimeEndTime_ist")
            if pd.notna(start):
                if pd.isna(end):
                    end = datetime.now()
                total_downtime += max(0, (end - start).total_seconds() / 60)

    runtime_minutes = max(planned_minutes - total_downtime, 0)
    availability = runtime_minutes / planned_minutes if planned_minutes else 0
    return availability, runtime_minutes


def calculate_productivity(ok_count, runtime_minutes, ideal_time_seconds=33):
    runtime_seconds = runtime_minutes * 60
    if runtime_seconds <= 0:
        return 0.0
    return round((ok_count * ideal_time_seconds) / runtime_seconds, 4)


def get_oee(machine_code, prod_count, rework_count, scrap_count, conn, downtime_df):
    availability, runtime_minutes = calculate_availability(
        machine_code, conn, downtime_df
    )
    productivity = calculate_productivity(prod_count, runtime_minutes, 33)
    total_count = prod_count + rework_count + scrap_count
    quality = prod_count / total_count if total_count else 0
    oee = availability * productivity * quality
    return {
        "availability": round(availability * 100, 2),
        "productivity": round(productivity * 100, 2),
        "quality": round(quality * 100, 2),
        "oee": round(oee * 100, 2),
    }


def get_machining_target(machine):
    workcenter = machine.replace("OP_", "OP-")
    if workcenter.startswith(("OP-10", "OP-20")):
        return 20
    if workcenter.startswith("OP-30") or workcenter.startswith("OP-40"):
        return 4
    if workcenter.startswith("OP-50"):
        return 30
    return 0


def get_machining_table(machine):
    wc = machine.replace("OP_", "OP-")
    if wc.startswith(("OP-10", "OP-20")):
        return "AT_VMC1Process"
    if wc.startswith(("OP-30", "OP-40", "OP-50")):
        return "AT_VMC2Process"
    return None


def _variant_prefix(variant, phase="P"):
    mapping = VARIANT_Q_PREFIX if phase.upper() == "Q" else VARIANT_P_PREFIX
    return mapping.get(variant, VARIANT_P_PREFIX["Matrix"])


def _variant_like(variant, quality=False, phase=None):
    if phase is None:
        phase = "Q" if quality else "P"
    return _variant_prefix(variant, phase) + "%"


def _variant_station_name(section, machine, variant):
    #print(variant)
    if machine == "ALT1_01" and variant in ("Banana Mini", "Kiwi Mini"):
        #print("condition is True")
        return "LM"
    return machine


def _display_for_variant(machine, display_name, variant):
    #print(variant)
    if machine == "ALT1_01" and variant in ("Banana Mini", "Kiwi Mini"):
        #print("condition is true")
        return "LM"
    #print(display_name)
    return display_name


def _station_variant_phase(section, machine):
    """Return the WIP prefix phase for a station.

    P00/P01/P02 are used through VMC1/QVMC1. Q00/Q01/Q02 are used
    from SLGL through packaging.
    """
    m = str(machine).upper()
    if section == "PRE_MACHINING":
        return "P"
    if section == "MACHINING":
        return "Q" if m.startswith(("OP_30", "OP_40", "OP_50", "REVT", "QVMC2")) else "P"
    if section == "POST_MACHINING":
        return "Q"
    return "P"




def get_machining_variant_counts(machine, cursor, start, variant):
    """Return OK/RW/NOK for one VMC operation and one product variant."""
    table = get_machining_table(machine)
    if machine == "REVT":
        phase = "Q"
        variant_like = _variant_like(variant, phase=phase)
        cursor.execute("""
            SELECT
                ISNULL(SUM(CASE WHEN OutputScan=1 AND Active=1 AND IsRejected=0 THEN 1 ELSE 0 END),0),
                ISNULL(SUM(CASE WHEN OutputScan=1 AND Active=1 AND IsRejected=1 AND WipOrderNo LIKE '%R00%' THEN 1 ELSE 0 END),0),
                ISNULL(SUM(CASE WHEN OutputScan=1 AND Active=1 AND IsRejected=1 THEN 1 ELSE 0 END),0)
            FROM AT_RivetingProcess
            WHERE CreatedOn BETWEEN ? AND GETDATE() AND WipOrderNo LIKE ?
        """, start, variant_like)
        row = cursor.fetchone()
        return (int(row[0] or 0), int(row[1] or 0), int(row[2] or 0)) if row else (0,0,0)
    if not table:
        return 0, 0, 0
    wc = machine.replace("OP_", "OP-")
    # OP-30/40/50 are treated as Q-processes in the source logic; OP-10/20
    # use the production variant map.
    phase = "Q" if wc.startswith(("OP-30", "OP-40", "OP-50", "REVT")) else "P"
    variant_like = _variant_like(variant, phase=phase)
    #print(variant)
    
    cursor.execute(f"""
        SELECT
            ISNULL(SUM(CASE WHEN OutputScan=1 AND Active=1 AND IsRejected=0 THEN 1 ELSE 0 END),0) AS OK_Count,
            ISNULL(SUM(CASE WHEN OutputScan=1 AND Active=1 AND IsRejected=1 AND WipOrderNo LIKE '%R00%' THEN 1 ELSE 0 END),0) AS Rework_Count,
            ISNULL(SUM(CASE WHEN OutputScan=1 AND Active=1 AND IsRejected=1 THEN 1 ELSE 0 END),0) AS NOK_Count
        FROM {table}
        WHERE CreatedOn BETWEEN ? AND GETDATE()
          AND WorkCenter LIKE ?
          AND WipOrderNo LIKE ?
    """, start, f"%{wc}%", variant_like)
    row = cursor.fetchone()
    if not row:
        return 0, 0, 0
    return int(row.OK_Count or 0), int(row.Rework_Count or 0), int(row.NOK_Count or 0)


def get_machining_counts(machine, cursor, start):
    return get_machining_variant_counts(machine, cursor, start, "Matrix")

def get_machining_oee(machine, prod_count, rework_count, nok_count, conn, downtime_df):
    availability, runtime_minutes = calculate_availability(machine, conn, downtime_df)
    target_per_hour = get_machining_target(machine)
    target_qty_runtime = target_per_hour * (runtime_minutes / 60)
    productivity = min(prod_count / target_qty_runtime, 1.0) if target_qty_runtime > 0 else 0
    total = prod_count + rework_count + nok_count
    quality = prod_count / total if total else 0
    oee = availability * productivity * quality
    return {
        "availability": round(availability * 100, 2),
        "productivity": round(productivity * 100, 2),
        "quality": round(quality * 100, 2),
        "oee": round(oee * 100, 2),
    }


def _scalar_count(cursor, query, start):
    return scalar(cursor, query, start) if query else 0


def _variant_query(query, variant, quality=False, phase=None):
    """Add an exact WipOrderNo prefix filter while preserving existing R00 filters."""
    if not query:
        return query, ()
    value = _variant_like(variant, quality=quality, phase=phase)
    if "WipOrderNo LIKE ?" in query:
        # Existing parameterized WIP filter is already present.
        return query, (value,)
    if "WipOrderNo" not in query and "CreatedOn BETWEEN ? AND GETDATE()" not in query:
        return query, ()
    if "cp.CreatedOn BETWEEN ? AND GETDATE()" in query:
        return query.replace("cp.CreatedOn BETWEEN ? AND GETDATE()", "cp.CreatedOn BETWEEN ? AND GETDATE() AND cp.WipOrderNo LIKE ?", 1), (value,)
    if "CreatedOn BETWEEN ? AND GETDATE()" in query:
        data = query.replace("CreatedOn BETWEEN ? AND GETDATE()", "CreatedOn BETWEEN ? AND GETDATE() AND WipOrderNo LIKE ?", 1), (value,)
        #print(data)
        return data
    return query, ()


def _variant_scalar_count(cursor, query, start, variant, quality=False, phase=None):
    q, extra = _variant_query(query, variant, quality, phase=phase)
    if not q:
        return 0
    cursor.execute(q, start, *extra)
    row = cursor.fetchone()
    return int(row[0] or 0) if row else 0


def _variant_machine_rows(base_loader, section, conn, downtime_df, mes_map):
    """Build variant-aware tiles for PRE/POST using the same source queries."""
    cursor = conn.cursor()
    start = shift_start_utc()
    shift = shift_start_ist()
    elapsed_hours = max((datetime.now() - shift).total_seconds() / 3600, 0)
    if section == "PRE_MACHINING":
        display, okq, rwq, nokq, tgts = machine_display, machine_queries, rework_queries, scrap_queries, targets
    else:
        display, okq, rwq, nokq, tgts = post_machining_display, post_machining_queries, post_machining_rework_queries, post_machining_nok_queries, post_targets
    out=[]
    for machine, name in display.items():
        status, since, runtime, status_color = _status_for_machine(downtime_df, mes_map, machine)
        variants={}
        for variant in SUPPORTED_VARIANTS:
            allowed = _variant_station_name(section, machine, variant) in VARIANT_STATIONS.get(variant, {}).get(section, [])
            if not allowed:
                variants[variant] = {"prod_count":0,"rw_count":0,"rework_count":0,"scrap_count":0,"target_label":0,"part_count_color":"#138A36","arrow":"▲","availability":0,"productivity":0,"quality":0,"oee":0,"available":False}
                continue
            if section == "PRE_MACHINING":
                phase = _station_variant_phase(section, machine)
                prod=_variant_scalar_count(cursor, okq.get(machine), start, variant, phase=phase)
                rw=_variant_scalar_count(cursor, rwq.get(machine), start, variant, phase=phase)
                nok=_variant_scalar_count(cursor, nokq.get(machine), start, variant, phase=phase)
            else:
                phase = _station_variant_phase(section, machine)
                prod=_variant_scalar_count(cursor, okq.get(machine), start, variant, phase=phase)
                nok=_variant_scalar_count(cursor, nokq.get(machine), start, variant, phase=phase)
                rw=_variant_scalar_count(cursor, rwq.get(machine), start, variant, phase=phase)
            target=int(tgts.get(machine,0)*elapsed_hours)
            oee=get_oee(machine,prod,rw,nok,conn,downtime_df)
            variants[variant]={"prod_count":prod,"rw_count":rw,"rework_count":rw,"scrap_count":nok,"target_label":target,"part_count_color":"#D50000" if prod<target else "#138A36","arrow":"▼" if prod<target else "▲",**oee,"available":True}
        selected=variants["Matrix"]
        out.append({"machine":machine,"machine_section":section,"display_name":_display_for_variant(machine, name, "Matrix"),"status":status,"status_color":status_color,"since":since,"runtime":runtime,"variants":variants,**selected})
    return out


def load_machine_data(conn=None, downtime_df=None, mes_map=None):
    own = conn is None
    if own:
        conn = get_connection()
    try:
        if downtime_df is None:
            downtime_df = load_downtime_data(conn)
        if mes_map is None:
            mes_map = load_mes_bypass_data(conn)

        cursor = conn.cursor()
        start = shift_start_utc()
        shift = shift_start_ist()
        elapsed_hours = max((datetime.now() - shift).total_seconds() / 3600, 0)
        machines = []

        for machine in machine_display:
            status, since, runtime, status_color = _status_for_machine(
                downtime_df, mes_map, machine
            )
            #print(machine)
            prod = _scalar_count(cursor, machine_queries.get(machine), start)
            rw = _scalar_count(cursor, rework_queries.get(machine), start)
            nok = _scalar_count(cursor, scrap_queries.get(machine), start)
            target_qty = int(targets.get(machine, 0) * elapsed_hours)
            count_color = "#D50000" if prod < target_qty else "#138A36"
            oee = get_oee(machine, prod, rw, nok, conn, downtime_df)
            machines.append({
                "machine": machine,
                "machine_section": "PRE_MACHINING",
                "display_name": machine_display.get(machine, machine),
                "status": status,
                "status_color": status_color,
                "since": since,
                "runtime": runtime,
                "prod_count": prod,
                "part_count_color": count_color,
                "target_label": target_qty,
                "arrow": "▼" if prod < target_qty else "▲",
                "rw_count": rw,
                "rework_count": rw,
                "scrap_count": nok,
                "availability": oee["availability"],
                "productivity": oee["productivity"],
                "quality": oee["quality"],
                "oee": oee["oee"],
                "matrix_value": 100,
            })
        return machines
    finally:
        if own:
            conn.close()


def load_machining_data(conn=None, downtime_df=None, mes_map=None):
    own = conn is None
    if own:
        conn = get_connection()
    try:
        if downtime_df is None:
            downtime_df = load_downtime_data(conn)
        if mes_map is None:
            mes_map = load_mes_bypass_data(conn)

        cursor = conn.cursor()
        start = shift_start_utc()
        shift = shift_start_ist()
        elapsed_hours = max((datetime.now() - shift).total_seconds() / 3600, 0)
        machines = []

        for machine, display_name in machining_display.items():
            status, since, runtime, status_color = _status_for_machine(
                downtime_df, mes_map, machine, force_shift=True
            )
            variants = {}
            for variant in SUPPORTED_VARIANTS:
                allowed = _variant_station_name("MACHINING", machine, variant) in VARIANT_STATIONS.get(variant, {}).get("MACHINING", [])
                if not allowed:
                    variants[variant] = {"prod_count":0,"rw_count":0,"rework_count":0,"scrap_count":0,"target_label":0,"part_count_color":"#138A36","arrow":"▲","availability":0,"productivity":0,"quality":0,"oee":0,"available":False}
                    continue
                print(variant)
                prod, rw, nok = get_machining_variant_counts(machine, cursor, start, variant)
                target = get_machining_target(machine)
                target_qty = int(target * elapsed_hours)
                oee = get_machining_oee(machine, prod, rw, nok, conn, downtime_df)
                variants[variant] = {
                    "prod_count": prod, "rw_count": rw, "rework_count": rw,
                    "scrap_count": nok, "target_label": target_qty,
                    "part_count_color": "#D50000" if prod < target_qty else "#138A36",
                    "arrow": "▼" if prod < target_qty else "▲",
                    "available": True,
                    **oee,
                }

            selected = variants[variant]
            machines.append({
                "machine": machine,
                "machine_section": "MACHINING",
                "display_name": display_name,
                "status": status,
                "status_color": status_color,
                "since": since,
                "runtime": runtime,
                "matrix_value": get_machining_target(machine),
                "variants": variants,
                **selected,
            })

        # Q-Gate tiles are part of the VMC section and use Q00/Q01/Q02 WIP prefixes.
        for vmc_group, workcenter in (("VMC1", "VMC1"), ("VMC2", "VMC2")):
            qgate_variants = {}
            for variant in SUPPORTED_VARIANTS:
                ok, nok, rw = _quality_totals(cursor, workcenter, start, variant)
                qgate_variants[variant] = {
                    "prod_count": ok, "rw_count": rw, "rework_count": rw, "scrap_count": nok,
                    "target_label": VMC_QGATE_TARGET, "part_count_color": "#138A36", "arrow": "▲",
                    "availability": 0, "productivity": 0,
                    "quality": round(ok/(ok+nok+rw)*100,2) if (ok+nok+rw) else 0,
                    "oee": 0, "available": True,
                }
            machines.append({
                "machine": f"{vmc_group}_QGATE", "machine_section": "MACHINING",
                "display_name": f"{vmc_group} Q-Gate", "status": "Operational", "status_color": "#138A36",
                "since": shift.strftime("%d-%b-%y %H:%M:%S"), "runtime": get_elapsed_time(shift),
                "matrix_value": VMC_QGATE_TARGET, "variants": qgate_variants, **qgate_variants["Matrix"],
            })
        return machines
    finally:
        if own:
            conn.close()

def load_post_machining_data(conn=None, downtime_df=None, mes_map=None):
    own = conn is None
    if own:
        conn = get_connection()
    try:
        if downtime_df is None:
            downtime_df = load_downtime_data(conn)
        if mes_map is None:
            mes_map = load_mes_bypass_data(conn)

        cursor = conn.cursor()
        start = shift_start_utc()
        shift = shift_start_ist()
        elapsed_hours = max((datetime.now() - shift).total_seconds() / 3600, 0)
        machines = []

        for machine, display_name in post_machining_display.items():
            ok = _scalar_count(cursor, post_machining_queries.get(machine), start)
            nok = _scalar_count(cursor, post_machining_nok_queries.get(machine), start)
            rw = _scalar_count(cursor, post_machining_rework_queries.get(machine), start)
            status, since, runtime, status_color = _status_for_machine(
                downtime_df, mes_map, machine
            )
            target_qty = int(post_targets.get(machine, 0) * elapsed_hours)
            color = "#D50000" if ok < target_qty else "#138A36"
            oee = get_oee(machine, ok, rw, nok, conn, downtime_df)
            machines.append({
                "machine": machine,
                "machine_section": "POST_MACHINING",
                "display_name": display_name,
                "status": status,
                "status_color": status_color,
                "since": since,
                "runtime": runtime,
                "prod_count": ok,
                "rw_count": rw,
                "rework_count": rw,
                "scrap_count": nok,
                "target_label": target_qty,
                "part_count_color": color,
                "arrow": "▼" if ok < target_qty else "▲",
                "availability": oee["availability"],
                "productivity": oee["productivity"],
                "quality": oee["quality"],
                "oee": oee["oee"],
                "matrix_value": 100,
            })
        return machines
    finally:
        if own:
            conn.close()



HOUR_SLOTS = [
    "06:30-07:30","07:30-08:30","08:30-09:30","09:30-10:30",
    "10:30-11:30","11:30-12:30","12:30-13:30","13:30-14:30",
    "14:30-15:30","15:30-16:30","16:30-17:30","17:30-18:30",
    "18:30-19:30","19:30-20:30","20:30-21:30","21:30-22:30",
    "22:30-23:30","23:30-00:30","00:30-01:30","01:30-02:30",
    "02:30-03:30","03:30-04:30","04:30-05:30","05:30-06:30",
]
SLOT_HOURS = [6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,0,1,2,3,4,5]


def _current_slot():
    now = datetime.now()
    hour = now.hour
    idx = SLOT_HOURS.index(hour)
    return HOUR_SLOTS[idx]


def _group_query(table, where):
    return f"""
        SELECT DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn)) AS Hr,
               ISNULL(SUM(PartQuantity),0) AS Qty
        FROM {table}
        WHERE CreatedOn BETWEEN ? AND GETDATE()
          AND {where}
        GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn))
        ORDER BY Hr
    """


def _pre_hourly_queries():
    # Same source tables/filters as machine_queries, but grouped by hour.
    return {
        "UC01_IP": _group_query("AT_Ultrasonic1process", "OutputScan=1 AND Parts='M4ACN0111M00'"),
        "SPFL_IP": _group_query("AT_SprayFluxingProcess", "OutputScan=1 AND UndoFlag=0 AND Parts='M4ACN0111M00'"),
        "CLNC": _group_query("AT_Clinchingprocess", "OutputScan=1 AND Active=1"),
        "RSHP": _group_query("AT_Reshapingprocess", "OutputScan=1"),
        "SHBL": _group_query("AT_ShotBlastingprocess", "OutputScan=1"),
        "ALT1_01": _group_query("AT_ALT1_Process", "OutputScan=1 AND IsRejected=0 AND Active=1"),
        "BRZN_FX": _group_query("AT_BrazingProcess", "OutputScan=1 AND Active=1"),
        "QALT": """
            SELECT DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn)) AS Hr,
                   ISNULL(COUNT(Quantity),0) AS Qty
            FROM AT_QUALITY_SAMPLE
            WHERE WorkCenter LIKE 'ALT1%' AND Status='QAOK'
              AND CreatedOn BETWEEN ? AND GETDATE()
            GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn))
            ORDER BY Hr
        """,
        "REVT": _group_query("AT_RivetingProcess", "OutputScan=1 AND Active=1 AND IsRejected=0"),
    }


def _laser_hourly_query(wc):
    return f"""
        ;WITH EquipMap AS (
            SELECT W.WorkCenter, UC.Attribute_ AS EquipmentName
            FROM WORK_CENTER W
            JOIN UNIT_CHARACTERISTIC UC ON UC.UnitID=W.UnitID
              AND UC.Characteristic='OutputStation'
            WHERE W.WorkCenter='{wc}'
        )
        SELECT DATEPART(HOUR, DATEADD(MINUTE,330,cp.CreatedOn)) AS Hr,
               COUNT(*) AS Qty
        FROM AT_LaserWeldingPLCData cp
        JOIN EQUIPMENT E ON E.ID=cp.EquipmentID
        JOIN EquipMap em ON em.WorkCenter='{wc}' AND E.Equipment=em.EquipmentName
        WHERE cp.CreatedOn BETWEEN ? AND GETDATE()
        GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,cp.CreatedOn))
        ORDER BY Hr
    """


def _disposition_hourly_query():
    return """
        SELECT DATEPART(HOUR, DATEADD(MINUTE,330,D.CreatedOn)) AS Hr,
               ISNULL(SUM(D.Quantity),0) AS Qty
        FROM DISPOSITION D
        WHERE D.OprSequenceNo=15 AND D.Status IN (14,4)
          AND D.CreatedOn BETWEEN ? AND GETDATE()
        GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,D.CreatedOn))
        ORDER BY Hr
    """


def _post_hourly_queries():
    return {
        "SG": _group_query("AT_ColdPlateLoadingProcess", "Active=1 AND OutputScan=1 AND LEN(ISNULL(SerialNo,''))>0 AND ISNULL(IsRejected,0)<>1"),
        "UC2": _group_query("AT_Ultrasonic2process", "Active=1 AND LEN(ISNULL(SerialNo,''))>0 AND ISNULL(IsRejected,0)<>1"),
        "EOL": """
            SELECT DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn)) AS Hr,
                   COUNT(DISTINCT SerialNumber) AS Qty
            FROM AT_TestingLineProcess
            WHERE Active=1 AND LEN(ISNULL(SerialNumber,''))>0
              AND LEN(ISNULL(LM2SerialNumber,''))>0 AND LEN(ISNULL(WipOrderNo,''))>0
              AND CreatedOn BETWEEN ? AND GETDATE()
            GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn)) ORDER BY Hr
        """,
        "PACK": """
            SELECT DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn)) AS Hr,
                   COUNT(ID) AS Qty
            FROM AT_PackagingProcess
            WHERE SerialLabelStatus=1 AND Active=1
              AND CreatedOn BETWEEN ? AND GETDATE()
            GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn)) ORDER BY Hr
        """,
    }


def _machining_hourly_for_variant(cursor, table, wc, start, variant):
    phase = "Q" if wc.startswith(("OP-30", "OP-40", "OP-50", "REVT")) else "P"
    variant_like = _variant_like(variant, phase=phase)
    query = f"""
        SELECT DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn)) AS Hr,
               ISNULL(SUM(CASE WHEN OutputScan=1 AND Active=1 AND IsRejected=0 THEN 1 ELSE 0 END),0) AS Qty
        FROM {table}
        WHERE CreatedOn BETWEEN ? AND GETDATE()
          AND WorkCenter LIKE ?
          AND WipOrderNo LIKE ?
        GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn)) ORDER BY Hr
    """
    return _hourly_query(cursor, query, start, extra=(f"%{wc}%", variant_like))


def _quality_hourly(cursor, workcenter, start, variant):
    variant_like = _variant_like(variant, quality=True)
    query = """
        SELECT DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn)) AS Hr,
               ISNULL(SUM(CASE WHEN Status='QAOK' THEN Quantity ELSE 0 END),0) AS OKQty,
               ISNULL(SUM(CASE WHEN Status='Scrap' THEN Quantity ELSE 0 END),0) AS NOKQty,
               ISNULL(SUM(CASE WHEN Status='Rework' THEN Quantity ELSE 0 END),0) AS RWQty
        FROM AT_QUALITY_SAMPLE
        WHERE WorkCenter=? AND CreatedOn BETWEEN ? AND GETDATE() AND WipOrderNo LIKE ?
        GROUP BY DATEPART(HOUR, DATEADD(MINUTE,330,CreatedOn)) ORDER BY Hr
    """
    cursor.execute(query, workcenter, start, variant_like)
    out = {h: {"ok": 0, "nok": 0, "rw": 0} for h in SLOT_HOURS}
    for row in cursor.fetchall():
        hr = int(getattr(row, "Hr", 0))
        if hr in out:
            out[hr] = {
                "ok": int(getattr(row, "OKQty", 0) or 0),
                "nok": int(getattr(row, "NOKQty", 0) or 0),
                "rw": int(getattr(row, "RWQty", 0) or 0),
            }
    return out


def _quality_totals(cursor, workcenter, start, variant):
    variant_like = _variant_like(variant, quality=True)
    query = """
        SELECT
            ISNULL(SUM(CASE WHEN Status='QAOK' THEN Quantity ELSE 0 END),0) AS OKQty,
            ISNULL(SUM(CASE WHEN Status='Scrap' THEN Quantity ELSE 0 END),0) AS NOKQty,
            ISNULL(SUM(CASE WHEN Status='Rework' THEN Quantity ELSE 0 END),0) AS RWQty
        FROM AT_QUALITY_SAMPLE
        WHERE WorkCenter=? AND CreatedOn BETWEEN ? AND GETDATE() AND WipOrderNo LIKE ?
    """
    cursor.execute(query, workcenter, start, variant_like)
    row = cursor.fetchone()
    if not row:
        return 0, 0, 0
    return int(row.OKQty or 0), int(row.NOKQty or 0), int(row.RWQty or 0)


def _hourly_query(cursor, query, start, extra=()):
    if not query:
        return {h: 0 for h in SLOT_HOURS}
    cursor.execute(query, start, *extra)
    out = {h: 0 for h in SLOT_HOURS}
    for row in cursor.fetchall():
        hr = int(getattr(row, "Hr", 0))
        qty = int(getattr(row, "Qty", 0) or 0)
        if hr in out:
            out[hr] = qty
    return out


def load_production_data(conn):
    """Load variant-aware production data for every dashboard section."""
    start = shift_start_utc()
    cursor = conn.cursor()
    sections = {}

    def build_section(variant, section_name, definitions):
        items=[]
        for machine, label, query, target, kind in definitions:
            if _variant_station_name(section_name, machine, variant) not in VARIANT_STATIONS.get(variant, {}).get(section_name, []):
                continue
            if query:
                phase = _station_variant_phase(section_name, machine)
                q, extra = _variant_query(query, variant, quality=False, phase=phase)
                hourly = _hourly_query(cursor, q, start, extra=extra)
            else:
                hourly={h:0 for h in SLOT_HOURS}
            items.append({"machine":machine,"label":label,"actual":sum(hourly.values()),"target_per_hour":target,"target_till_hour":target,"hourly":[hourly[h] for h in SLOT_HOURS],"kind":kind})
        return _production_section(items)

    pre_defs=[]
    pre_queries=_pre_hourly_queries()
    for machine in machine_display:
        label=graph_labels.get(machine,machine)
        if machine in ("LW01","LW02","LW03"):
            query=_laser_hourly_query(machine)
        elif machine=="QLW01": query=_laser_hourly_query("LW01")
        elif machine=="QLW02": query=_laser_hourly_query("LW02")
        elif machine=="QLW03": query=_disposition_hourly_query()
        else: query=pre_queries.get(machine)
        pre_defs.append((machine,label,query,targets.get(machine,0),"OK" if machine.startswith("QLW") or machine=="QALT" else "A-JPH"))

    post_defs=[(m,post_machining_display.get(m,m),q,post_targets.get(m,0),"A-JPH") for m,q in _post_hourly_queries().items()]
    variant_sections={}
    for variant in SUPPORTED_VARIANTS:
        variant_sections[variant]={
            "PRE_MACHINING":build_section(variant,"PRE_MACHINING",pre_defs),
            "POST_MACHINING":build_section(variant,"POST_MACHINING",post_defs),
        }

    machining_variants={}
    for variant in SUPPORTED_VARIANTS:
        items=[]
        for machine,display in machining_display.items():
            if machine not in VARIANT_STATIONS[variant]["MACHINING"]: continue
            table=get_machining_table(machine)
            wc=machine.replace("OP_","OP-")
            if machine == "REVT":
                q = _group_query("AT_RivetingProcess", "OutputScan=1 AND Active=1 AND IsRejected=0")
                q, extra = _variant_query(q, variant, phase="Q")
                hourly = _hourly_query(cursor, q, start, extra=extra)
            else:
                hourly=_machining_hourly_for_variant(cursor,table,wc,start,variant)
            target=get_machining_target(machine)
            items.append({"machine":machine,"label":display,"actual":sum(hourly.values()),"target_per_hour":target,"target_till_hour":target,"hourly":[hourly[h] for h in SLOT_HOURS],"kind":"A-JPH","vmc_group":"VMC1" if wc.startswith(("OP-10","OP-20")) else "VMC2","is_qgate":False})
        for vmc_group,workcenter in (("VMC1","VMC1"),("VMC2","VMC2")):
            qhourly=_quality_hourly(cursor,workcenter,start,variant)
            items.append({"machine":f"{vmc_group}_QGATE","label":f"{vmc_group} Q-Gate","actual":sum(v["ok"] for v in qhourly.values()),"target_per_hour":VMC_QGATE_TARGET,"target_till_hour":VMC_QGATE_TARGET,"hourly":[qhourly[h]["ok"] for h in SLOT_HOURS],"hourly_nok":[qhourly[h]["nok"] for h in SLOT_HOURS],"hourly_rw":[qhourly[h]["rw"] for h in SLOT_HOURS],"kind":"OK","vmc_group":vmc_group,"is_qgate":True})
        machining_variants[variant]=_production_section(items)

    return {
        "PRE_MACHINING":{v:variant_sections[v]["PRE_MACHINING"] for v in SUPPORTED_VARIANTS},
        "MACHINING":{"variants":machining_variants, **machining_variants.get("Matrix",_production_section([]))},
        "POST_MACHINING":{v:variant_sections[v]["POST_MACHINING"] for v in SUPPORTED_VARIANTS},
    }

def _production_section(items):
    now_hour = datetime.now().hour
    current_index = SLOT_HOURS.index(now_hour)
    for item in items:
        item["actual_till_hour"] = sum(item["hourly"][:current_index+1])
        item["target_till_hour"] = item["target_per_hour"] * (current_index+1)
    return {
        "hour_slots": HOUR_SLOTS,
        "current_slot": HOUR_SLOTS[current_index],
        "current_index": current_index,
        "items": items,
        "updated_at": datetime.now().astimezone().isoformat(timespec="seconds"),
    }


def get_machines(section):
    # Compatibility helper. Normal dashboard routes use the JSON cache.
    conn = get_connection()
    try:
        downtime = load_downtime_data(conn)
        mes = load_mes_bypass_data(conn)
        section = section.upper()
        if section == "PRE_MACHINING":
            return load_machine_data(conn, downtime, mes)
        if section == "MACHINING":
            return load_machining_data(conn, downtime, mes)
        if section == "POST_MACHINING":
            return load_post_machining_data(conn, downtime, mes)
        return []
    finally:
        conn.close()


def get_machine(section, machine_code):
    code = str(machine_code).upper()
    for machine in get_machines(section):
        if str(machine.get("machine", "")).upper() == code:
            return machine
    return None
